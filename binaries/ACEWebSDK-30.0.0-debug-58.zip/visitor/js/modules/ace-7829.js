/*! For license information please see ace-7829.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[7829],{17829:(e,a,t)=>{t.r(a),t.d(a,{default:()=>l});var n=t(31085),r=t(79867),i=t(15428),s=t(3468),p=t(93922),c=t(27389),m=t(14041),o=t(41676);t(33296);const d=e=>{const a=(0,r.Py)(),t=(0,m.useMemo)((()=>Object.entries(e.areas).map((([e,t])=>{const n=a.find((a=>a.name===e));return(0,o.i)(t)?{name:e,componentDef:n,context:t.context,areaSettings:t.areaSettings,template:t.template,areas:t.areas,gap:t.gap}:{name:e,componentDef:n,areaSettings:t.areaSettings,child:t.child,context:t.context}}))),[e,a]);return(0,n.jsx)(g,{"data-grid-area":e.gridArea,gridArea:e.gridArea,gap:e.gap,template:e.template,className:(0,c.JS)(e.className,"humany-grid"),children:t.map((e=>e.componentDef?(0,n.jsx)(p.uA,{id:e.componentDef.id,branch:"default",context:{}},e.componentDef.id):null))})},g=s.A.div`
  display: grid;
  ${e=>e.gridArea&&i.AH`
      grid-area: ${e.gridArea};
    `}
  ${e=>(e=>{const a=e.map((e=>"min-content")).join(" "),t=e[0].split(" ").map((e=>"1fr")).join(" "),n=e.map((e=>`'${e}'`)).join(" ");return i.AH`
    grid-template-columns: ${t};
    grid-template-rows: ${a};
    grid-template-areas: ${n};
  `})(e.template)}
  ${e=>e.gap&&i.AH`
      grid-gap: ${e.gap}rem;
    `}
`,l=({className:e})=>{const a=(0,r.Bi)();return(0,n.jsx)(d,{template:a.template,areas:a.areas,gap:a.gap,areaSettings:a.areaSettings,context:a.context})}}}]);
//# sourceMappingURL=ace-7829.js.map