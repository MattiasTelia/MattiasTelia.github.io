/*! For license information please see ace-484.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[484],{28103:(e,t,r)=>{r.r(t),r.d(t,{default:()=>m});var n=r(31085),i=r(3468),l=r(87744),o=r(27389);const a=(0,i.A)(l.B8)`
  ${l.p_}
  display: flex;
  justify-content: flex-start;
  min-width: 0;
  > li {
    margin-bottom: 0;
  }
  li {
    display: inline;
    font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
    line-height: 1.5em;
  }
  li:before {
    padding: ${e=>{var t;return`0 ${2*(null==(t=e.theme.sizes)?void 0:t.cardinal)}px`}};
    color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
    content: '/';
    font-weight: 300;
  }
  li:first-child:before {
    content: '';
    padding: 0;
  }

  li:first-child {
    a,
    span {
      padding-left: 0;
    }
  }
  border-width: 2px;
`,s=i.A.li`
  color: ${e=>{var t,r;return e.isLink?null==(t=e.theme.colors)?void 0:t.primary:null==(r=e.theme.colors)?void 0:r.text}};
  flex: 0 ${e=>e.shrink?1:0} auto;
  ${e=>e.shrink&&"min-width: 8ch;"};
  font-weight: 300;
  text-overflow: ellipsis;
  overflow: hidden;
`,c=(0,i.A)(l.N_)`
  text-align: center;
  text-decoration: none;
  font-weight: 300;
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
  &:focus-visible {
    ${l.bn}
  }
`,d=(0,i.A)(l.EY)`
  text-align: center;
  text-decoration: none;
  font-weight: 300;
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
`,h=i.A.div`
  text-overflow: ellipsis;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
  line-height: 1.5em;

  a {
    display: flex;
    align-items: center;

    svg {
      margin-right: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};

      line {
        vector-effect: non-scaling-stroke;
        stroke: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
      }
    }
  }
`,m=({className:e,...t})=>{const r=(0,l.NF)(),{mode:i="list",items:m=[],loading:u=!1,truncationThreshold:v=30}=(0,l.Bi)();return!m||m.length<=1?(0,l.Xn)(r,{...t,className:(0,o.JS)(e,"humany-breadcrumbs")}):"list"===i?(0,n.jsx)(a,{...t,"data-loading":u,className:(0,o.JS)(e,"humany-breadcrumbs"),items:m,"data-vertical":!1,renderItem:({title:e,routeName:t,routeParams:r},i)=>{const l=i!==m.length-1;return(0,n.jsx)(s,{shrink:e.length>=v,isLink:l,children:l?(0,n.jsx)(c,{routeName:t,params:r,title:e,"aria-label":e,children:e}):(0,n.jsx)(d,{children:e})},`${e}.[${i}].[${t}]`)}}):(e=>{if(m&&m.length>1){const{title:t,routeName:r,routeParams:i}=m[m.length-2];return(0,n.jsx)(h,{className:e,children:(0,n.jsxs)(c,{routeName:r,params:i,children:[(0,n.jsx)(l.s$,{size:14,symbol:{type:"Svg",content:"back"}}),t]})})}return null})((0,o.JS)(e,"humany-breadcrumbs"))}}}]);
//# sourceMappingURL=ace-484.js.map