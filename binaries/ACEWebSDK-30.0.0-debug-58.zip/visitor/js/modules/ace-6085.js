/*! For license information please see ace-6085.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[6085],{66085:(e,t,i)=>{i.r(t),i.d(t,{default:()=>b});var o=i(31085),r=i(87744),n=i(27389),a=i(14041),l=i(75866),s=i(15428),d=i(3468);const m=d.A.div`
  ${r.MH}
  ${r.jo}
  overflow: hidden;
  min-height: 50px;
  ${e=>e["data-toggler-in-focus"]&&e.isTabbing&&s.AH`
      && {
        ${(0,r.ns)(e)}
      }
    `};
`,c=d.A.button`
  background: none;
  border: 0;
  outline: 0;
  display: block;
  cursor: pointer;
  padding: 0;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
  text-align: end;
  flex: 1 0 auto;
  svg {
    path,
    line {
      stroke: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
    }
  }
`,u=e=>{var t,i,o,r,n,a,l,d;return s.AH`
  font-size: ${null==(t=e.theme.fonts)?void 0:t.normal};
  text-align: left;
  text-align: left;
  text-decoration: none;
  font-weight: 300;
  display: flex;
  align-items: center;
  padding: ${null==(i=e.theme.sizes)?void 0:i.small};
  padding-left: ${null==(o=e.theme.sizes)?void 0:o.large};
  cursor: pointer;
  overflow: hidden;
  ${e.selected?s.AH`
        border-left: 2px solid ${null==(r=e.theme.colors)?void 0:r.primary};
        color: ${null==(n=e.theme.colors)?void 0:n.primary};
      `:s.AH`
        color: ${null==(a=e.theme.colors)?void 0:a.text};
      `};

  span {
    overflow: hidden;
    text-overflow: ellipsis;
  }

  i {
    margin-right: ${null==(l=e.theme.sizes)?void 0:l.normal};
    font-size: ${null==(d=e.theme.fonts)?void 0:d.medium};
    min-height: 1em;
    min-width: 1em;
  }
`},g=d.A.div`
  ${u}
`,h=(0,d.A)(r.N_)`
  ${u}
  &:focus {
    outline: none;
  }
  &:focus-visible {
    span {
      ${r.bn};
    }
  }
`,p=d.A.div`
  display: flex;
  justify-content: space-between;
  padding-right: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.large}};
  min-height: 52px;
  white-space: nowrap;

  && {
    font-weight: normal;

    a {
      font-weight: normal;
    }
  }
  .humany-guide-category-dropdown-item {
    font-weight: normal;
  }
`,y={Wrapper:m,Toggler:c,List:(0,d.A)(r.B8)`
  ${r.p_}
  display: flex;
  justify-content: center;
  flex-direction: column;
  margin-right: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}};
  margin-left: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.large}};
  margin-bottom: 22px;
  border-left: ${e=>e.theme.border};
  li {
    margin: 0 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}} -2px;
  }
  li:last-child {
    margin: 0 0 0 -2px;
  }
  flex-basis: 100%;
  border-width: 2px;
`,Item:g,Link:h,TopItem:p,MatchCount:(0,d.A)(r.EY)`
  margin: 0 0 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
`},x=({matches:e})=>{const{showMatchCount:t=!1}=(0,r.Bi)();return!t||typeof e>"u"?null:(0,o.jsxs)(y.MatchCount,{children:["(",e,")"]})},f=({item:e,guideCategory:t})=>{const{route:i="browse",categoryAriaLabel:n="",activeCategoryAriaLabel:a="",fallbackOnInitialRoute:s=!1}=(0,r.Bi)(),[d,m]=(0,r.tZ)(),{id:c,title:u,symbol:g,activeSymbol:h}=e,p=t===c;return(0,o.jsx)("li",{ref:m,children:(0,o.jsxs)(y.Link,{...(0,l.Cr)(e,i,s,"category"),"aria-pressed":p,"aria-label":(p?a:n).replace("{{category}}",u),className:"humany-guide-category-dropdown-link","aria-current":p,selected:p,children:[(p||d)&&h?(0,o.jsx)(r.s$,{symbol:h}):g&&(0,o.jsx)(r.s$,{symbol:g}),(0,o.jsx)(r.EY,{children:u}),(0,o.jsx)(x,{...e})]})})},b=({className:e,...t})=>{const i=(0,r.PR)(),[l,s]=(0,a.useState)(!1),{parent:d,route:m="browse",categories:c=[],loading:u=!1}=(0,r.Bi)(),g=(0,r.NF)(),[h,p]=(0,a.useState)(!1),{params:b}=i,v=(0,r.jf)(),{guideCategory:w,tag:$,phrase:j,sorting:k}=b;if((0,a.useEffect)((()=>{h&&p(!1)}),[w]),u||!d||!c.length)return(0,r.Xn)(g,{...t,className:(0,n.JS)(e,"humany-guide-category-dropdown")});const N=c.find((e=>e.id===w))||d;return N.activeSymbol||N.symbol,(0,o.jsx)(y.Wrapper,{...t,"data-loading":!1,"data-toggler-in-focus":l,"aria-expanded":h,isTabbing:v,className:(0,n.JS)(e,"humany-guide-category-dropdown"),children:h?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsxs)(y.TopItem,{className:"humany-guide-category-dropdown-top-item",children:[(0,o.jsxs)(y.Link,{className:"humany-guide-category-dropdown-link",routeName:m,params:(0,n.$6)({tag:$,phrase:j,sorting:k,guideCategory:d.id,uriName:(0,n.J1)(d.title)}),selected:!1,children:[d.symbol?(0,o.jsx)(r.s$,{symbol:d.symbol}):null,(0,o.jsx)(r.EY,{children:d.title}),(0,o.jsx)(x,{...d})]}),(0,o.jsx)(y.Toggler,{onBlur:()=>s(!1),onFocus:()=>s(!0),className:"humany-guide-category-dropdown-toggler",onClick:()=>{p(!h)},"aria-expanded":"true","aria-label":d.title,children:(0,o.jsx)(r.s$,{size:18,symbol:{type:"Svg",content:"caret-up"}})})]}),(0,o.jsx)(y.List,{className:"humany-guide-category-dropdown-open",items:c,renderItem:e=>(0,o.jsx)(f,{item:e,guideCategory:w},e.id)})]}):(0,o.jsxs)(y.TopItem,{className:"humany-guide-category-dropdown-top-item",children:[(0,o.jsxs)(y.Item,{className:"humany-guide-category-dropdown-item",onClick:()=>{p(!h)},selected:!1,children:[d.symbol?(0,o.jsx)(r.s$,{symbol:d.symbol}):null,(0,o.jsx)(r.EY,{children:d.title}),(0,o.jsx)(x,{...N})]}),(0,o.jsx)(y.Toggler,{onBlur:()=>s(!1),onFocus:()=>s(!0),className:"humany-guide-category-dropdown-toggler",onClick:()=>{p(!h)},"aria-expanded":"false","aria-label":N.title,children:(0,o.jsx)(r.s$,{size:18,symbol:{type:"Svg",content:"caret-down"}})})]})})}}}]);
//# sourceMappingURL=ace-6085.js.map