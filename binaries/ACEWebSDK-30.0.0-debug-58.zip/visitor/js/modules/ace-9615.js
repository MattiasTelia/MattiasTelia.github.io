/*! For license information please see ace-9615.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[9615],{39615:(e,t,s)=>{s.r(t),s.d(t,{default:()=>o});var a=s(31085),l=s(3468),r=s(87744),i=s(27389);const n=(e,t,s)=>e&&s?(0,a.jsx)(d,{symbol:s,size:18}):t?(0,a.jsx)(d,{symbol:t,size:18}):null,o=({className:e,embedded:t=!1,...s})=>{const l=(0,r.NF)(),{route:o="search",header:d,items:c=[],showIcons:h}=(0,r.Bi)(),{params:p}=(0,r.PR)();return c.length?(0,a.jsx)(m,{embedded:t?"true":"false",...s,className:(0,i.JS)(e,"humany-tag-list","humany-related-tag-list"),header:d,items:c,renderItem:e=>{const{id:t,title:s,defaultIcon:l,activeIcon:r}=e,d=p.tag===e.id||!p.tag&&"0"===e.id;return(0,a.jsx)("li",{"data-tag":t,children:(0,a.jsx)(u,{routeName:o,selected:d,params:(0,i.$6)({tag:t}),text:s,children:h&&n(d,l,r)})},t)}}):(0,r.Xn)(l,{...s,className:(0,i.JS)(e,"humany-tag-list","humany-related-tag-list")})},d=(0,l.A)(r.s$)`
  margin-right: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
  ${e=>"Uri"===e.symbol.type?`\n        width: ${e.size}px;\n        height: ${e.size}px;\n      `:"FontAwesome"===e.symbol.type?`\n        font-size: ${e.size}px;\n      `:void 0}
`,m=(0,l.A)(r.kk)`
  ${r._R}
  ${e=>"false"===e.embedded&&r.jo}
  ${e=>{var t;return`padding: ${null==(t=e.theme.sizes)?void 0:t.large};`}}
  justify-content: flex-start;

  ul {
    display: flex;
    flex-wrap: wrap;
    li {
      margin: 0 ${e=>{var t,s;return`${null==(t=e.theme.sizes)?void 0:t.small} ${null==(s=e.theme.sizes)?void 0:s.small}`}} 0;

      a {
        color: #fff;
      }
    }
  }
`,u=(0,l.A)(r.Yq)`
  padding: 8px 15px;
  background-color: ${e=>{var t,s;return e.selected?null==(t=e.theme.colors)?void 0:t.text:null==(s=e.theme.colors)?void 0:s.primary}};
  font-weight: 300;
  border-radius: ${e=>e.theme.borderRadius};
  display: block;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};

  &:focus-visible {
    ${r.ns}
    padding: 6px 15px;
    background-color: transparent;
  }

  @media (hover: hover) {
    &:hover {
      background-color: ${e=>{var t,s;return e.selected?null==(t=e.theme.colors)?void 0:t.primary:null==(s=e.theme.colors)?void 0:s.text}};
    }
  }
`}}]);
//# sourceMappingURL=ace-9615.js.map