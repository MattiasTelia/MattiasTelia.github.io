/*! For license information please see ace-3045.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[3045],{83045:(e,i,t)=>{t.r(i),t.d(i,{default:()=>b});var n=t(31085),s=t(15428),o=t(3468),r=t(79867),l=t(27389),a=t(15240);t(33296);const c=({node:e})=>{if(!e.symbol)return null;let i;const t="Svg"===e.symbol.type;if("Svg"===e.symbol.type){const t=parseInt(e.size,10);isNaN(t)||(i=t)}return(0,n.jsx)(d,{symbol:e.symbol,svg:t,size:i,backgroundSize:"cover"})},d=(0,o.A)((({svg:e,...i})=>(0,n.jsx)(r.s$,{...i})))`
  color: ${e=>{var i;return null==(i=e.theme.colors)?void 0:i.text}};
  ${e=>!e.svg&&s.AH`
      border-radius: 50%;
      overflow: hidden;
    `}
`,m=({node:e})=>{const i=e.symbol||{type:"Svg",content:"back"};return(0,n.jsx)(r.s$,{size:20,symbol:i})},u=({node:e})=>{const i=e.symbol||{type:"Svg",content:"close"},t=parseInt(null==e?void 0:e.size,10)||14;return(0,n.jsx)(r.s$,{size:t,symbol:i})},x=({node:e})=>{const i=e.symbol||{type:"Svg",content:"minimize"},t=parseInt(null==e?void 0:e.size,10)||20;return(0,n.jsx)(r.s$,{size:t,symbol:i})},h=({className:e="",...i})=>{const t=(0,r.wA)(),{size:s,padding:o,type:l,tooltip:a,show:d=!0}=i;return"back"===l?(0,n.jsx)(g,{size:s||"64px",padding:o||"10px",children:(0,n.jsx)(r.zF,{in:d,timeout:300,transitions:{enter:{type:"scale",easing:"cubic-bezier(.08,.84,.74,1.84)"},exit:{type:"scale",easing:"ease-out"}},children:(e,s)=>(0,n.jsx)(v,{"data-testid":"back-button",title:a,"aria-label":a,animationCss:s,onClick:()=>{t("back")},children:(0,n.jsx)(m,{node:i})})})}):d?(0,n.jsxs)(g,{size:s||"64px",padding:o||"10px",squareRatio:"avatar"===l,children:["avatar"===l&&(0,n.jsx)(c,{node:i}),"close"===l&&(0,n.jsx)(v,{title:a,"aria-label":a,onClick:()=>{t("close")},children:(0,n.jsx)(u,{node:i})}),"minimize"===l&&(0,n.jsx)(v,{title:a,"aria-label":a,onClick:()=>{t("minimize")},children:(0,n.jsx)(x,{node:i})})]}):null},g=o.A.div`
  flex: 1;
  max-width: ${e=>e.size};
  ${e=>e.squareRatio&&`max-height: ${e.size};`}
  text-align: center;
  padding: 0 ${e=>e.padding};
  && {
    box-sizing: content-box;
  }

  svg {
    vertical-align: middle;
  }

  i {
    color: ${e=>{var i;return null==(i=e.theme.colors)?void 0:i.text}};
    font-size: ${e=>e.size};
    min-width: 1em;
    min-height: 1em;
    display: inline-block;
  }
`,v=o.A.button`
  ${e=>!!e.animationCss&&e.animationCss};
  background: none;
  border: none;
  cursor: pointer;
  padding: 0;
  &:focus-visible {
    ${r.ns};
    border-color: ${e=>{var i,t;return null==(t=null==(i=e.theme.accessibility)?void 0:i.colors)?void 0:t.inactiveText}};
  }
`,b=({className:e,...i})=>{const{header:t,tagline:s,route:o,tooltip:c="",actions:d={},textAlign:m="center"}=(0,r.Bi)(),[u,x]=(0,a.c)(d);return u.sort(((e,i)=>(e.order||0)-(i.order||0))),x.sort(((e,i)=>(e.order||0)-(i.order||0))),(0,n.jsxs)(p,{...i,className:(0,l.JS)(e,"humany-widget-header"),children:[u.map(((e,i)=>(0,n.jsx)(h,{...e},`${e.type}+_${i}`))),(0,n.jsxs)(y,{textAlign:m,margin:(0,a.a)(u,x,m),children:[o?(0,n.jsx)(j,{routeName:o,title:c,"aria-label":c,children:(0,n.jsx)(r.o5,{variant:"h1",children:t})}):(0,n.jsx)(r.o5,{variant:"h1",children:t}),s&&(0,n.jsx)($,{children:s})]}),x.map(((e,i)=>(0,n.jsx)(h,{...e},`${e.type}+_${i}`)))]})},p=o.A.div`
  display: flex;
  flex-direction: row;
  align-items: center;

  ${e=>{var i,t;return(0,r.jc)(e)("h1",s.AH`
        font-size: ${null==(i=e.theme.fonts)?void 0:i.huge};
        margin: 0;
        font-weight: 300;
        color: ${null==(t=e.theme.colors)?void 0:t.text};
      `)}}

  p {
    color: ${e=>{var i;return null==(i=e.theme.colors)?void 0:i.text}};
    margin: 0;
  }

  svg {
    line,
    path,
    circle {
      stroke: ${e=>{var i;return null==(i=e.theme.colors)?void 0:i.text}};
    }
  }
`,$=o.A.p`
  font-size: ${e=>{var i;return null==(i=e.theme.fonts)?void 0:i.normal}};
  font-weight: 300;
`,y=o.A.div`
  flex: 1;
  text-align: ${e=>e.textAlign};
  overflow: auto;
  max-height: 100%;
  margin-right: ${e=>e.margin.right||0};
  margin-left: ${e=>e.margin.left||0};
`,j=(0,o.A)(r.N_)`
  text-decoration: none;
  &:focus-visible {
    ${e=>(0,r.jc)(e)("h1",s.AH`
          ${(0,r.bn)(e)}
          display: inline-block;
        `)}
  }
`}}]);
//# sourceMappingURL=ace-3045.js.map