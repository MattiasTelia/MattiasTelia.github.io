/*! For license information please see ace-3278.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[3278],{93278:(e,t,s)=>{s.r(t),s.d(t,{default:()=>h});var a=s(31085),c=s(3468),l=s(87744),n=s(27389),r=s(77783);s(91872),s(14041),s(27811);const h=({className:e,description:t,body:{freetext:s},htmlParseInstruction:c})=>s?(0,a.jsxs)("div",{className:(0,n.JS)(e,"humany-contact-method-free-text"),children:[(0,a.jsx)(d,{html:s,htmlParseInstruction:c}),t&&(0,a.jsx)(r.D,{html:t,htmlParseInstruction:c})]}):null,d=(0,c.A)(l.Ed)`
  ${l.Bh};
`}}]);
//# sourceMappingURL=ace-3278.js.map