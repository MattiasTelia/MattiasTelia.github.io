/*! For license information please see ace-741.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[741],{10741:(a,e,s)=>{s.r(e),s.d(e,{default:()=>t});var l=s(31085),i=s(3468),c=s(79867),r=s(27389);const t=({className:a,...e})=>{const{route:s,image:i,ariaLabel:t,altLabel:m}=(0,c.Bi)();return(0,l.jsx)(b,{...e,className:(0,r.JS)(a,"humany-image-link"),children:s?(0,l.jsx)(c.N_,{routeName:s,"aria-label":t,children:(0,l.jsx)("img",{src:i,alt:m})}):(0,l.jsx)("img",{src:i,alt:m,"aria-label":t})})},b=i.A.div`
  a {
    display: block;
    &:focus-visible {
      ${c.ns};
    }
  }
  img {
    max-width: 100%;
  }
`}}]);
//# sourceMappingURL=ace-741.js.map