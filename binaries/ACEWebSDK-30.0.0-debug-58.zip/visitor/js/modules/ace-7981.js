/*! For license information please see ace-7981.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[7981],{27981:(e,a,t)=>{t.r(a),t.d(a,{default:()=>d});var i=t(31085),o=t(3468),r=t(87744),l=t(27389);const d=({className:e,...a})=>{const{name:t,params:o}=(0,r.PR)(),d=(0,r.NF)(),{showFavoriteToggle:s=!1,items:v,header:b,metadata:n,tags:u,addFavoriteTooltip:c,removeFavoriteCancelLabel:F,removeFavoriteConfirmLabel:g,removeFavoriteHeader:h,removeFavoriteLabel:p,removeFavoriteTooltip:L,metadataByLabel:_,metadataModifiedLabel:f,metadataPublishedLabel:w}=(0,r.Bi)();return v&&v.length?(0,i.jsx)(m,{...a,className:(0,l.JS)(e,"humany-related-guide-list"),header:b,items:v,paramMappers:{guide:({id:e,title:a})=>(0,l.$6)({...o,guide:e,uriName:(0,l.J1)(a),connection:void 0})},showTags:u,showFavoriteToggle:s,addFavoriteTooltip:c,removeFavoriteCancelLabel:F,removeFavoriteConfirmLabel:g,removeFavoriteHeader:h,removeFavoriteLabel:p,removeFavoriteTooltip:L,metadata:{...n,modifiedLabel:f,publishedLabel:w,byLabel:_},routing:{guide:t}}):(0,r.Xn)(d,{...a,className:(0,l.JS)(e,"humany-related-guide-list")})},m=(0,o.A)(r.tz)`
  ${r.jo}
  li:last-child {
    margin: 0;
  }
`}}]);
//# sourceMappingURL=ace-7981.js.map