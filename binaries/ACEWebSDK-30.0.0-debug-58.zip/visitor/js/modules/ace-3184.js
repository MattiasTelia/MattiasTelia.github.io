/*! For license information please see ace-3184.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[3184],{13184:(e,l,n)=>{n.r(l),n.d(l,{default:()=>c});var s=n(31085),i=n(3468),r=n(79867),t=n(27389);const a=i.A.div`
  font-weight: 300;
  button {
    color: ${e=>{var l;return null==(l=e.theme.colors)?void 0:l.primary}};
    text-decoration: underline;
    font-size: ${e=>{var l;return null==(l=e.theme.fonts)?void 0:l.normal}};
    span {
      font-weight: 300;
    }
    &:focus-visible {
      ${r.bn}
      padding: ${e=>{var l,n;return`calc(${null==(l=e.theme.sizes)?void 0:l.small} / 2) ${null==(n=e.theme.sizes)?void 0:n.small}`}};
    }
  }
`,o=i.A.svg`
  margin-right: ${e=>{var l;return null==(l=e.theme.sizes)?void 0:l.small}};
  line {
    stroke: ${e=>{var l;return null==(l=e.theme.colors)?void 0:l.primary}};
  }
`,c=({className:e,...l})=>{const n=(0,r.wA)(),{params:i}=(0,r.PR)(),c=(0,r.NF)(),{conditions:h=[],label:m=""}=(0,r.Bi)();return h&&h.length&&!h.reduce(((e,l)=>!!i[l]||e),!1)?(0,r.Xn)(c,{...l,className:(0,t.JS)(e,"humany-back-link")}):m?(0,s.jsx)(a,{...l,className:(0,t.JS)(e,"humany-back-link"),children:(0,s.jsxs)(r.$n,{"aria-label":m,onClick:()=>{n("click")},children:[(0,s.jsxs)(o,{width:"7",height:"13",viewBox:"0 0 7 13",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[(0,s.jsx)("line",{x1:"6.64645",y1:"12.5513",x2:"0.648357",y2:"6.55319"}),(0,s.jsx)("line",{x1:"0.646447",y1:"6.64455",x2:"6.64454",y2:"0.646465"})]}),m&&(0,s.jsx)("span",{children:m})]})}):(0,s.jsx)(a,{...l,className:(0,t.JS)(e,"humany-back-link"),children:(0,s.jsxs)("svg",{width:"8",height:"16",viewBox:"0 0 8 16",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[(0,s.jsx)("line",{y1:"-0.5",x2:"10.2585",y2:"-0.5",transform:"matrix(-0.682358 -0.731018 0.682358 -0.731018 8 14.9999)",stroke:"white"}),(0,s.jsx)("line",{y1:"-0.5",x2:"10.2585",y2:"-0.5",transform:"matrix(0.682359 -0.731018 0.682358 0.731018 1 8.49915)",stroke:"white"})]})})}}}]);
//# sourceMappingURL=ace-3184.js.map