/*! For license information please see ace-2616.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[2616],{72616:(e,n,a)=>{a.r(n),a.d(n,{default:()=>s});var i=a(31085),r=a(3468),t=a(87744),l=a(82694);const s=({title:e,messageId:n,actions:a})=>{const r=(0,t.NF)(),{events:l}=r.get("$widget"),s=(0,t.wA)(),c=document.createElement("div");return c.innerHTML=e,e=c.innerText,(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)("p",{id:n,children:e}),(0,i.jsx)(o,{className:"humany-bot-feedback-list",role:"group","aria-labelledby":n,items:a,"data-direction":"vertical",renderItem:e=>(0,i.jsx)("li",{children:(0,i.jsxs)(d,{className:"humany-feedback-button",disabled:!1,"data-selected":!0,onClick:()=>{s("action",e.actionKey),l.dispatch("tracking:feedback-given-bot",{feedbackResponse:e.actionKey})},children:[(0,i.jsx)(t.In,{faIcon:"yes"===e.actionKey?"smile-o":"frown-o"}),(0,i.jsx)("span",{children:e.label})]})},e.actionKey)})]})},o=(0,r.A)(t.B8)`
  ${e=>(0,t.p_)(e)}
  ${l.m}
    display: flex;
  gap: ${e=>{var n;return null==(n=e.theme.sizes)?void 0:n.normal}};
  flex-direction: ${e=>"horizontal"===e["data-direction"]?"row":"column"};
  > li {
    flex: 1;
    margin: 0;
  }
`,d=(0,r.A)(t.$n)`
  ${t.gX}
  font-size: ${e=>{var n;return null==(n=e.theme.fonts)?void 0:n.normal}};
  border-color: ${e=>{var n;return null==(n=e.theme.colors)?void 0:n.primary}};
  font-weight: 300;
  display: block;
  width: 100%;

  ${e=>{var n;return(0,t.kI)({primaryColor:`${null==(n=e.theme.colors)?void 0:n.primary}`,secondaryColor:"#FFFFFF",theme:e.theme})}}
  i {
    margin: 0 ${e=>{var n;return null==(n=e.theme.sizes)?void 0:n.small}} 0 0;
  }
  span {
  }
`},82694:(e,n,a)=>{a.d(n,{m:()=>r});var i=a(15428);const r=e=>{var n,a;return i.AH`
  margin: ${null==(n=e.theme.sizes)?void 0:n.medium} 0;
  padding: 0 ${null==(a=e.theme.sizes)?void 0:a.medium};
`}}}]);
//# sourceMappingURL=ace-2616.js.map