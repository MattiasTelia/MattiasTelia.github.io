/*! For license information please see ace-9817.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[9817],{99817:(e,t,a)=>{a.r(t),a.d(t,{default:()=>d});var n=a(31085),r=a(3468),i=a(79867),l=a(27389);const d=({className:e,...t})=>{const{header:a,tooltip:r,maxHeaderWidth:d="100%"}=(0,i.Bi)(),h=(0,i.rd)();if(!h)return null;const u=h.getInitialRoute();if(!u)return null;const{name:m}=u;return(0,n.jsx)(s,{...t,className:(0,l.JS)(e,"humany-header"),children:(0,n.jsx)(o,{routeName:m,"aria-label":r,title:r,children:(0,n.jsx)(c,{variant:"h1","data-header-max-width":d,children:a})})})},s=r.A.div`
  display: flex;
  justify-content: center;
`,o=(0,r.A)(i.N_)`
  text-decoration: none;
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
`,c=(0,r.A)(i.o5)`
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.huge}};
  text-align: center;
  margin: 0;
  font-weight: 400;
  max-width: ${e=>e["data-header-max-width"]};
`}}]);
//# sourceMappingURL=ace-9817.js.map