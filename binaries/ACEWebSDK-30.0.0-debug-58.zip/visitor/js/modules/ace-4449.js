/*! For license information please see ace-4449.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[4449],{94449:(e,a,o)=>{o.r(a),o.d(a,{default:()=>i});var n=o(31085),t=o(3468),d=o(11330),l=o(87744),s=o(27389);const r=t.A.div`
  ${l.MH}
  ${l.jo}
  padding: ${e=>{var a;return null==(a=e.theme.sizes)?void 0:a.large}};
  overflow: hidden;

  .humany-file-error {
    color: ${e=>{var a;return null==(a=e.theme.colors)?void 0:a.warning}};
    padding-bottom: ${e=>{var a;return null==(a=e.theme.sizes)?void 0:a.normal}};
  }
`,i=({className:e,...a})=>{const o=(0,l.wA)(),t=(0,l.NF)(),{loading:i=!1,contactMethod:c,autoFocus:u=!1}=(0,l.Bi)();return c||i?(0,n.jsxs)(r,{...a,"data-loading":i,className:(0,s.JS)(e,"humany-contact-method"),children:[typeof(null==c?void 0:c.id)<"u"&&(0,n.jsx)(d.ContactMethod,{...c,expanded:c.expanded||!!c.body.form,inline:!0,autoFocus:u,dispatch:o}),(0,n.jsx)(l.aH,{loading:i})]}):(0,l.Xn)(t,{...a,className:(0,s.JS)(e,"humany-contact-method")})}}}]);
//# sourceMappingURL=ace-4449.js.map