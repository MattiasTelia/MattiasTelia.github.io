/*! For license information please see ace-6906.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[6906],{66906:(e,s,n)=>{n.r(s),n.d(s,{default:()=>r});var i=n(31085),t=n(3468),l=n(87744),a=n(82694);const r=({body:e})=>{const s=(0,l.wA)();return(0,i.jsx)(o,{className:"humany-bot-no-good-alternative",children:(0,i.jsxs)(c,{onClick:()=>{s("action","help")},"aria-label":e,title:e,children:[(0,i.jsx)(l.s$,{size:14,symbol:{type:"FontAwesome",content:"meh-o"}}),(0,i.jsx)("span",{children:e})]})})},o=t.A.div`
  display: flex;
  align-items: center;
  justify-content: center;
  ${a.m}
`,c=(0,t.A)(l.$n)`
  > i,
  svg {
    margin-right: ${e=>{var s;return null==(s=e.theme.sizes)?void 0:s.small}};
  }

  &:focus-visible {
    ${l.ns}
  }
`},82694:(e,s,n)=>{n.d(s,{m:()=>t});var i=n(15428);const t=e=>{var s,n;return i.AH`
  margin: ${null==(s=e.theme.sizes)?void 0:s.medium} 0;
  padding: 0 ${null==(n=e.theme.sizes)?void 0:n.medium};
`}}}]);
//# sourceMappingURL=ace-6906.js.map