/*! For license information please see ace-6405.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[6405],{36405:(e,a,t)=>{t.r(a),t.d(a,{default:()=>u});var n=t(31085),i=t(15428),l=t(3468),o=t(87744),r=t(94701),s=t(27389),d=t(14041);const c="closed-notifications",p={transform:{a:({children:e,...a})=>(0,n.jsx)("a",{...a,tabIndex:-1,children:e})}},u=({className:e,...a})=>{const{types:t=[],allowPaging:i=!0,notifications:l=[],expandable:u=!1,closeAriaLabel:v="",pageNextAriaLabel:y="",pagePreviousAriaLabel:w="",expandAriaLabel:$=""}=(0,o.Bi)(),[k,S]=(0,d.useState)(!1),[A,j]=(0,d.useState)([]),[z,_]=(0,d.useState)(0),C=(0,o.NF)(),[N,E]=(0,d.useState)();(0,d.useEffect)((()=>{C&&((0,r.readStorage)(C,c,r.StorageMedium.Session).then(((e=[])=>j(e))),(0,r.createStorageWriter)(C,c,r.StorageCategory.Functional).then((e=>E((()=>e)))))}),[C]),(0,d.useEffect)((()=>{C&&(0,r.readStorage)(C,c,r.StorageMedium.Session).then(((e=[])=>{A.forEach((a=>-1===e.indexOf(a)&&e.push(a))),N&&N(e)}))}),[A,C,N]);const H=l.filter((({id:e})=>-1===A.indexOf(e))),{length:O}=H;if(!H.length)return(0,o.Xn)(C,{...a,className:(0,s.JS)(e,"humany-notification-row")});if(i){const l=H[z]||H[z+1]||H[z-1];if(!l)return(0,o.Xn)(C,{...a,className:(0,s.JS)(e,"humany-notification-row")});const{id:r,body:d}=l||{},c=()=>S(!k);return(0,n.jsxs)(h,{...a,...u?{"aria-expanded":k,role:"button"}:{},...$?{"aria-label":$}:{},tabIndex:u?0:-1,className:(0,s.JS)(e,"humany-notification-row"),"data-pageable":O>1,"data-types":t,"data-allow-paging":i,"data-expandable":u,onKeyDown:e=>{"Enter"===e.key&&c()},onClick:c,children:[(0,n.jsx)(x,{"aria-label":v,onClick:()=>{_(H.indexOf(l)),j([...A,r])},children:(0,n.jsx)(o.s$,{symbol:{type:"Svg",content:"close"}})}),(0,n.jsx)(f,{htmlParseInstruction:!u||k?void 0:p,"data-pageable":O>1,"data-notification":r,"data-expandable":u,"data-expanded":k,html:d}),O>1&&(0,n.jsxs)(m,{children:[(0,n.jsx)(g,{"data-testid":"page-left-button","aria-label":w,"data-disabled":0===z,onClick:e=>{e.stopPropagation(),z>0&&_(z-1)},children:(0,n.jsx)(b,{size:10,symbol:{type:"Svg",content:"caret-left"}})}),(0,n.jsxs)("span",{children:[z+1,"/",O]}),(0,n.jsx)(g,{"data-testid":"page-right-button","aria-label":y,"data-disabled":z+1>=O,onClick:e=>{e.stopPropagation(),z<O-1&&_(z+1)},children:(0,n.jsx)(b,{size:10,symbol:{type:"Svg",content:"caret-right"}})})]})]})}return(0,n.jsx)(h,{...a,className:(0,s.JS)(e,"humany-notification-row"),"data-pageable":!1,"data-types":t,"data-allow-paging":!1,children:H.map((e=>{if(!e)return null;const{id:a,body:t}=e;return(0,n.jsx)(f,{"data-pageable":!1,"data-expandable":u,"data-expanded":k,"data-notification":a,html:t},a)}))})},h=l.A.div`
  ${o.Bh}
  padding: ${e=>{var a;return null==(a=e.theme.sizes)?void 0:a.normal}} ${e=>{var a;return 12*(null==(a=e.theme.sizes)?void 0:a.cardinal)}}px;
  background-color: ${e=>{var a,t,n;return e["data-types"].length?e["data-types"].indexOf("top")>-1?null==(a=e.theme.colors)?void 0:a.warning:e["data-types"].indexOf("bottom")>-1?"transparent":null==(t=e.theme.colors)?void 0:t.primary:null==(n=e.theme.colors)?void 0:n.warning}};
  color: ${e=>{var a;return null==(a=e.theme.colors)?void 0:a.text}};
  border-radius: ${e=>e.theme.borderRadius};
  text-align: center;
  display: flex;
  flex-direction: column;
  position: relative;
  cursor: ${e=>e["data-expandable"]?"pointer":"default"};
  overflow: hidden;

  i {
    color: ${e=>{var a;return null==(a=e.theme.colors)?void 0:a.text}};
  }

  a {
    color: ${e=>{var a;return null==(a=e.theme.colors)?void 0:a.link}};
    &:focus-visible {
      ${o.bn}
    }
  }

  ${e=>{var a;return!e["data-allow-paging"]&&i.AH`
      flex-wrap: wrap;

      > div {
        min-width: 100%;
        margin: ${2*(null==(a=e.theme.sizes)?void 0:a.cardinal)}px;
      }
    `}};

  ${e=>i.AH`
      &:focus-visible {
        .humany-html {
          ${(0,o.ns)(e)}
        }
      }
    `}
`,f=(0,l.A)(o.Ed)`
  flex: 1;
  font-size: ${e=>{var a;return null==(a=e.theme.fonts)?void 0:a.normal}};
  line-height: 1.6em;
  font-weight: 300;

  ${e=>e["data-expandable"]&&!e["data-expanded"]&&i.AH`
      max-width: 100%;

      p {
        display: none;
        &:first-child {
          display: block;
          margin-bottom: 0;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
      }
    `}
`,m=l.A.div`
  text-align: center;
  width: 100%;
  span {
    font-size: ${e=>{var a;return null==(a=e.theme.fonts)?void 0:a.small}};
    display: inline-block;
    width: 30px;
    text-align: center;
  }
`,g=(0,l.A)(o.$n)`
  background-color: transparent;
  border: none;
  cursor: pointer;
  transition: opacity 200ms ease-out;
  justify-self: flex-end;
  align-self: flex-start;
  padding: ${e=>{var a;return null==(a=e.theme.sizes)?void 0:a.small}} svg {
    display: block;
  }

  &:focus-visible {
    ${o.ns}
  }

  ${e=>e["data-disabled"]?i.AH`
          opacity: 0.8;
        `:i.AH`
          @media (hover) {
            &:hover {
              opacity: 0.5;
            }
          }
        `}
`,x=(0,l.A)(g)`
  position: absolute;
  top: 7.5px;
  right: 7.5px;
  width: 25px;
  height: auto;
  padding: ${e=>{var a,t;return`calc(${null==(a=e.theme.sizes)?void 0:a.small}/2) ${null==(t=e.theme.sizes)?void 0:t.small}`}};
  svg {
    vertical-align: middle;
    line,
    path {
      stroke: ${e=>{var a;return null==(a=e.theme.colors)?void 0:a.text}};
    }
  }
`,b=(0,l.A)(o.s$)`
  line {
    stroke: #ffffff;
  }
`;l.A.div`
  display: none;
`}}]);
//# sourceMappingURL=ace-6405.js.map