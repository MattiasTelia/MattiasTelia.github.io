/*! For license information please see ace-5387.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[5387],{45387:(e,t,a)=>{a.r(t),a.d(t,{default:()=>p});var i=a(31085),n=a(3468),c=a(11330),s=a(87744),l=a(27389),o=a(93922),d=a(14041);const r=({className:e,guides:t,header:a,accordion:n,loading:c,route:r="guide",categoryTitle:u,...m})=>{const{name:h,params:{contactCategory:x=0,guide:j}}=(0,s.PR)(),{name:p}=(0,s.wO)(),y=(0,s.NF)(),f=(0,s.Py)(),N=(0,s.wA)(),$=(0,d.useCallback)(((e,t,a,c)=>{const{id:d,title:r}=e;return n&&j===d?(0,i.jsx)(s.gQ,{id:d,title:r,route:h,collapseUri:u&&(0,l.J1)(u),children:f.map((e=>(0,i.jsx)(o.uA,{id:e.id,branch:"default",accordion:n},e.id)))},d):c?c(e,t,a,c):null}),[n,f,j]);return t.length||c?(0,i.jsx)(g,{...m,"data-loading":c,className:(0,l.JS)(e,"humany-deflection-list"),items:t,header:a,expandable:!!n,renderItem:$,dispatch:N,routing:{guide:r},paramMappers:{guide:({id:e,title:t})=>(0,l.$6)({contactCategory:x,guide:e,accordion:n?p:void 0,uriName:(0,l.J1)(t)})},children:(0,i.jsx)(s.aH,{loading:c})}):(0,s.Xn)(y,{...m,className:(0,l.JS)(e,"humany-deflection-list")})},g=(0,n.A)(s.tz)`
  ${s.jo}
  ${s.MH}
`,u=(0,n.A)(c.ContactList)`
  ${s.MH}
  ${s.jo}
`,m=(0,n.A)(s.kk)`
  ${e=>(0,s.MH)(e)}
  ${s.jo}
  ${c.contactItemList}

  && {
    i {
      font-size: 25px;
      width: 1.28571429em;
      text-align: center;
    }
  }
`,h=(0,n.A)(s.N_)`
  &:focus-visible {
    ${s.ns};
  }

  ${c.contactLink}
`,x=n.A.div`
  display: flex;
  flex-direction: column;
  gap: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
`,j=(0,n.A)(s.D7)`
  font-weight: bold;
`,p=({className:e,...t})=>{const a=(0,s.wA)(),n=(0,s.NF)(),c=(0,s.PR)(),{deflectionHeader:o="",routes:d={},contactMethods:g=[],categories:p=[],guides:y=[],deflectionAccordion:f=!1,loading:N=!1}=(0,s.Bi)(),{contactCategory:$,guide:b="guide"}=d;if(!p.length&&!g.length&&!N)return(0,s.Xn)(n,{...t,className:(0,l.JS)(e,"humany-contact-category-list")});const{name:k,params:{contactCategory:A}}=c,_=(0,l._f)(A,p);return g.length?(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(r,{className:e,guides:y,categoryTitle:_&&_.title,header:o,route:b,accordion:f,loading:N}),(0,i.jsx)(u,{"data-loading":N,className:e,contactMethods:g,dispatch:a,children:(0,i.jsx)(s.aH,{loading:N})})]}):(0,i.jsx)(m,{...t,"data-loading":N,className:(0,l.JS)(e,"humany-contact-category-list"),items:_&&_.items||p,renderItem:({id:e,title:t,symbol:a,matches:n,items:c,description:o})=>n||c&&c.length?(0,i.jsx)("li",{"data-contact-category":e,children:(0,i.jsxs)(h,{routeName:$||k,params:(0,l.$6)({contactCategory:e,uriName:(0,l.J1)(t)}),children:[a&&(0,i.jsx)(s.s$,{symbol:a}),null!=o&&o.length?(0,i.jsxs)(x,{children:[(0,i.jsx)(j,{children:t}),(0,i.jsx)(s.D7,{children:o})]}):(0,i.jsx)(s.D7,{children:t})]})},e):null,children:(0,i.jsx)(s.aH,{loading:N})})}}}]);
//# sourceMappingURL=ace-5387.js.map