/*! For license information please see ace-1591.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[1591,4445],{4445:(t,e,n)=>{n.r(e),n.d(e,{default:()=>m});var o=n(31085),a=n(3468),i=n(20499),d=n(11330),r=n(87744),c=n(91872),s=n(27389),u=n(14041),l=n(37706);n(59476),n(94701);const m=({contactMethodId:t,guideId:e,groupId:n,className:a})=>{var d,m,b,y,h;const[v,p]=(0,u.useState)(),g=(0,r.NF)(),I=(0,r.wA)(),w=(0,u.useRef)(!0),k=(0,r.LM)();(0,u.useEffect)((()=>{const{events:e}=g.get("$widget"),o=e.subscribe("conversational-hub-provider:form-submitted",(async(t,e)=>{var o;if((null==(o=e.form.meta)?void 0:o.groupId)!==n||e.id!==(null==v?void 0:v.id))return;k&&(e.form.meta||(e.form.meta={}),e.form.meta.conversation=k);const a=await g.getAsync("contactMethods"),i={...v,body:{...v.body,form:e.form}},{errors:d,valid:r,errorTypes:s}=await a.validate(i);if(!r){const t=new c.ok(v.body.form);return p(void 0),t.setValidationErrors(d),i.body={...i.body,form:t.get()},void p({...i})}const u=await a.submit(i);i.confirmation=u,p(i)})),a=e.subscribe("conversational-hub-provider:evaluate",(async(e,o)=>{if(String(o.id)!==String(t))return;const a=await(await g.getAsync("contactMethods")).evaluate(v);let i={...v,body:{...v.body,form:a}};const d=(0,l.u)(i,{submit:"Submit",errors:{},meta:{groupId:n}});i={...i,body:d},p(i)}));return()=>{o(),a()}}),[g,v,p,k]);const C=(t,e,n=null)=>{if(t["ui:component"]&&"Date"===t["ui:component"])return Object.assign(t,{"ui:bot":!0,"ui:entrance":e}),t;for(const n in t)if("object"==typeof t[n]&&null!==t[n]){const o=C(t[n],e,t);if(void 0!==o)return o}},M=(0,u.useCallback)((async t=>{const o=await(await i.DataClient.getInstance(g)).fetch(i.DataType.ContactMethod,{contactMethodId:t,guideId:e},{noCache:!0,isBot:!0}),a=(0,l.u)(o,{submit:"Submit",errors:{},meta:{groupId:n}});if(o.body=a,o.body.guideId=e,!w.current)return null;p(o)}),[w]);return(0,u.useEffect)((()=>(M(t),()=>{w.current=!1})),[t,M]),v?("ace.callback"===v.clientName&&null!=(d=v.body)&&d.entrance&&C(v,null==(m=v.body)?void 0:m.entrance),(0,o.jsx)(f,{...v,body:{...v.body,form:v.body.form?{...v.body.form,data:null==(b=v.body.form)?void 0:b.data,layout:{...v.body.form.layout},meta:null==(y=v.body.form)?void 0:y.meta,schema:null==(h=v.body.form)?void 0:h.schema}:void 0,guideId:v.body.guideId},inline:!0,expanded:!0,dispatch:I,className:(0,s.JS)("humany-bot-contact-method",a)})):null},f=(0,a.A)(d.ContactMethod)`
  padding: ${t=>{var e;return null==(e=t.theme.sizes)?void 0:e.normal}} ${t=>{var e;return null==(e=t.theme.sizes)?void 0:e.medium}};
`},91591:(t,e,n)=>{n.r(e),n.d(e,{default:()=>s});var o=n(31085),a=n(3468),i=n(11330),d=n(87744),r=n(14041),c=n(4445);n(20499),n(91872),n(27389),n(37706),n(59476),n(94701);const s=({actions:t,entryId:e,groupId:n})=>{const a=(0,d.wA)(),i=(0,d.NF)(),[c,s]=(0,r.useState)([]),[f,b]=(0,r.useState)([]);return(0,r.useEffect)((()=>{i.getAsync("contactMethods").then((n=>{if(!n)return;const o=t.map((async t=>{var o;if(null==(o=t.data)||!o.clientName)return null;const a=await n.handleAdapters(t.data);return{...a,...t.data,description:t.data.description?t.data.description:a.description,onClick:(n,o)=>{if("function"==typeof a.onClick&&a.onClick(n,o),!n.defaultPrevented)if(o.inline&&!o.expanded)b([...f,o.id]);else{const{events:n}=i.get("$widget");n.dispatch("conversational-hub-provider:open-contact-method",{entryId:e,contactMethod:o,actionKey:t.actionKey}),n.dispatch("tracking:contact-method-list-item-clicked",o)}}}}));Promise.all(o).then((t=>{s(t.filter((t=>!!t)))}))}))}),[t,i,e,f]),c.length?(0,o.jsx)(u,{className:"humany-bot-contact-list",contactMethods:c,dispatch:a,itemRenderer:(t,e)=>(f.includes(t.id)||t.expanded)&&t.inline||"custom.link"===t.clientName?(0,o.jsx)(l,{contactMethodId:t.id,groupId:n,guideId:t.body.guideId}):(0,o.jsx)(m,{...t,...e})}):null},u=(0,a.A)(i.ContactList)`
  > ul > li {
    a {
      display: flex;
      align-items: center;
      outline-offset: -2px;
    }

    &:not(:last-child) {
      ${t=>t.theme.border&&`border-bottom: ${t.theme.border};`}
    }
  }
`,l=(0,a.A)(c.default)`
  i {
    margin: 0 ${t=>{var e;return null==(e=t.theme.sizes)?void 0:e.medium}} 0 0;
    display: flex;
    justify-content: center;
    align-items: center;
  }
`,m=(0,a.A)(i.ContactMethod)`
  padding: ${t=>{var e;return null==(e=t.theme.sizes)?void 0:e.medium}};
  i {
    margin: 0 ${t=>{var e;return null==(e=t.theme.sizes)?void 0:e.medium}} 0 0;
    display: flex;
    justify-content: center;
    align-items: center;
  }
`}}]);
//# sourceMappingURL=ace-1591.js.map