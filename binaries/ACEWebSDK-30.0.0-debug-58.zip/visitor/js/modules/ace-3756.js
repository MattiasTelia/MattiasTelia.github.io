/*! For license information please see ace-3756.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[3756],{83756:(e,t,a)=>{a.r(t),a.d(t,{default:()=>P});var o=a(31085),l=a(15428),i=a(3468),n=a(11330),r=a(87744),s=a(93922),d=a(27389),c=a(14041),u=a(27811);const m=({className:e,defaultAnswerVersionLabel:t,guide:{perspective:a,perspectives:l},availablePerspectives:i=[]})=>{const{name:n,params:s}=(0,r.PR)(),u=(0,c.useMemo)((()=>l&&i.length?i.filter((({name:e})=>!!l[e])).map((({name:e,title:t})=>({label:t,connection:l[e]}))):[]),[l,i]);return(0,o.jsx)(h,{className:(0,d.JS)(e,"humany-guide-answer-version-picker"),items:u,renderItem:e=>{const l="Default"===e.label?t:e.label,i=a===e.connection,r=i&&(!s.connection||a===s.connection);return(0,o.jsx)("li",{"data-version":e.connection,children:(0,o.jsx)(g,{as:r?"span":void 0,text:l,routeName:n,selected:i,"aria-label":l,title:l,params:{...s,connection:e.connection}},e.connection)},e.connection)}})},h=(0,i.A)(r.B8)`
  display: flex;
  align-items: center;
  flex-wrap: wrap;

  list-style: none;
  padding: 0;
  margin: 0;

  li:not(:last-child) {
    margin: 0 calc(${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}} * 2) 0 0;
  }

  li > span {
    cursor: default;
  }
`,g=(0,i.A)(r.Yq)`
  font-weight: 300;
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  text-decoration: none;

  ${e=>e.selected&&l.AH`
      font-weight: bold;
      text-decoration: underline;
    `}

  &:focus-visible {
    ${r.x_};
  }
`,v=(0,i.A)(n.ContactList)`
  border-top: ${e=>e.theme.border};
  ${e=>"true"===e.backButtonShown&&`border-bottom: ${e.theme.border};`}
`,b=(0,i.A)(r.Gb)`
  ${e=>{var t,a;return`padding: ${null==(t=e.theme.sizes)?void 0:t.large} ${null==(a=e.theme.sizes)?void 0:a.large};`}}
`,p=(0,i.A)(r.oR)`
  ${e=>{var t,a;return`padding: ${null==(t=e.theme.sizes)?void 0:t.large} ${null==(a=e.theme.sizes)?void 0:a.large};`}}

  display: block;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
  font-weight: bold;
`,f=({backButtonShown:e=!1,accordion:t=!1})=>{const a=(0,r.wA)(),{loading:l=!1,dialog:i=[],guide:n,handoverContactMethods:s=[],contactHeader:d,showFeedback:u,feedbackDirection:m="horizontal",feedbackRecognitionLabel:h,feedbackGiven:g,feedbackHeader:f,positiveFeedbackLabel:y,negativeFeedbackLabel:x,contactFeedbackLabel:$}=(0,r.Bi)(),[j,w]=(0,c.useState)(!1);return(0,c.useEffect)((()=>{g||w(!1)}),[g]),!u||!n||!n.allowFeedback||l&&!g||i.length?null:g&&h&&!s.length&&!l?(0,o.jsx)(p,{accordion:t?"true":"false",tabindex:-1,ref:e=>{!j&&e&&(w(!0),e.focus())},children:h}):n.hasHandover&&s.length?(0,o.jsx)(v,{backButtonShown:e?"true":"false",accordion:t?"true":"false",header:d,contactMethods:s,dispatch:a}):(0,o.jsx)(b,{accordion:t?"true":"false",positive:y,negative:n.hasHandover?$:x,header:f,selected:g,onFeedback:e=>a("feedback",e),direction:m})},y=({guide:{categories:e=[]},toolbar:{picker:t=u.uq.NONE}})=>{const[a,l]=(0,c.useState)([]),i=(0,r.NF)();return(0,c.useEffect)((()=>{(0,d.fF)("index",e.map((e=>e.toString())),i).then((e=>{l(e)}))}),[e]),a.length?(0,o.jsx)(r.m_,{className:"humany-guide-category-tooltip",sticky:t===u.uq.DRAWER,content:(0,o.jsx)(o.Fragment,{children:a.map((e=>(0,o.jsx)(x,{className:"humany-guide-category-trail",children:e.map(((t,a)=>(0,o.jsxs)(r.EY,{className:"humany-guide-category-trail-segment",children:[t.symbol&&0===a&&(0,o.jsx)(r.s$,{size:14,symbol:t.symbol}),t.title,a!==e.length-1&&(0,o.jsx)($,{className:"humany-category-separator",children:"/"})]},t.id)))},e.map((e=>e.id)).join("."))))}),children:t===u.uq.DRAWER?(0,o.jsx)(r.g8,{className:"humany-guide-category-tooltip-button","data-has-label":"false","data-has-symbol":"true",children:(0,o.jsx)(j,{size:19,symbol:{type:"Svg",content:"information"}})}):(0,o.jsx)(j,{size:19,symbol:{type:"Svg",content:"information"}})}):null},x=i.A.div`
  i,
  svg {
    margin: 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}} 0 0;
  }

  &:not(:last-child) {
    margin: 0 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
  }
`,$=(0,i.A)(r.EY)`
  margin: 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
`,j=(0,i.A)(r.s$)`
  display: block;
`,w=({header:e,tooltip:t,printActionLabel:a,copyActionLabel:l,addFavoriteTooltip:i,removeFavoriteCancelLabel:n,removeFavoriteConfirmLabel:s,removeFavoriteHeader:d,removeFavoriteLabel:m,removeFavoriteTooltip:h,toolbarFunctionsCloseButtonAriaLabel:g,allowCopy:v=!1,allowPrint:b=!1,showFavoriteToggle:p=!1,picker:f=u.uq.NONE,guide:y,dispatch:x})=>{const[$,j]=(0,r.rB)(),w=(0,c.useCallback)((e=>{y&&x("copy",y)}),[y,x]),L=(0,c.useCallback)((()=>{y&&x("print")}),[y,x]),z=(0,c.useMemo)((()=>{const{id:e,title:t}=y,c=[];if(v&&c.push({type:"copy",child:(0,o.jsxs)(r.g8,{"data-has-label":l?"true":"false","data-has-symbol":"true",title:l,"aria-label":a,onClick:w,children:[(0,o.jsx)(k,{size:16,symbol:{type:"Svg",content:"copy"}}),l&&(0,o.jsx)(r.D7,{children:l})]})}),b&&c.push({type:"print",child:(0,o.jsxs)(r.g8,{"data-has-label":a?"true":"false","data-has-symbol":"true",title:a,"aria-label":a,onClick:L,children:[(0,o.jsx)(k,{size:16,symbol:{type:"Svg",content:"print"}}),a&&(0,o.jsx)(r.D7,{children:a})]})}),p){const a=$.indexOf(e)>-1;c.push({type:"favorite",child:(0,o.jsx)(r.Zu,{id:e,guideTitle:t,isFavorite:a,buttonLabel:a?h:i,addFavoriteTooltip:i,removeFavoriteCancelLabel:n,removeFavoriteConfirmLabel:s,removeFavoriteHeader:d,removeFavoriteLabel:m,removeFavoriteTooltip:h,actions:j})})}return c}),[$,y,v,b,p,a,l,i,n,s,d,m,h]);if(!z.length)return null;const N=(0,o.jsx)(F,{tabIndex:0,title:t,"data-has-symbol":"true","data-has-label":"false",children:(0,o.jsx)(k,{symbol:{type:"Svg",content:"options"},size:18})}),C=({type:e,child:t})=>(0,o.jsx)("li",{"data-function-type":e,children:t},e);return f===u.uq.DROPDOWN?(0,o.jsx)(A,{className:"humany-guide-functions-dropdown-list",header:e,items:z,trigger:N,renderItem:C,closeButtonAriaLabel:g}):f===u.uq.DRAWER?(0,o.jsx)(r.g7,{className:"humany-guide-functions-drawer-list",animation:{type:r.gw.SlideInBottom},header:e,items:z,trigger:N,renderItem:C,closeButtonAriaLabel:g}):null},k=(0,i.A)(r.s$)`
  circle {
    fill: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  }

  line,
  path,
  rect {
    stroke: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  }
`,A=(0,i.A)(r.Q5)`
  display: block;
  min-height: auto;
`,F=(0,i.A)(r.g8)`
  padding: calc(${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}} * 2) 0;
`,L=({header:e,tooltip:t,picker:a=u.uq.NONE,guide:l,...i})=>{const{name:n,params:s}=(0,r.PR)(),m=(0,c.useMemo)((()=>Object.keys(l.translations||{}).reduce(((e,t)=>{const a={};return a.key=t,a.id=(l.translations||{})[t],a.label=i[`${t}LanguageLabel`],(a.id||a.label)&&e.push(a),e}),[])),[l,i]);if(!m.length)return null;const h=((e,t)=>{var a;return(null==(a=t.find((t=>t.id===e.id)))?void 0:a.label)||""})(l,m),g=(0,o.jsxs)(z,{tabIndex:0,title:t,"data-has-symbol":"true","data-has-label":a===u.uq.DROPDOWN&&h?"true":"false",children:[a===u.uq.DROPDOWN&&(0,o.jsxs)(o.Fragment,{children:[h&&(0,o.jsx)(C,{children:h}),(0,o.jsx)(B,{symbol:{type:"Svg",content:"caret-down"},size:11})]}),a===u.uq.DRAWER&&(0,o.jsx)(N,{symbol:{type:"Svg",content:"language"},size:20})]}),v=({label:e,key:t,id:a})=>(0,o.jsx)("li",{"data-language":t,children:(0,o.jsx)(R,{tabIndex:0,text:e,routeName:n,selected:l.id===a,params:(0,d.$6)({...s,connection:void 0,guide:a})})},t);return a===u.uq.DROPDOWN?(0,o.jsx)(S,{className:"humany-guide-languages-dropdown-list",header:e,items:m,trigger:g,renderItem:v}):a===u.uq.DRAWER?(0,o.jsx)(r.g7,{className:"humany-guide-languages-drawer-list",animation:{type:r.gw.SlideInBottom},header:e,items:m,trigger:g,renderItem:v}):null},z=(0,i.A)(r.g8)`
  &&& {
    margin: 0 ${e=>{var t;return`calc(${null==(t=e.theme.sizes)?void 0:t.small} * 2)`}} 0 0;
  }
`,N=(0,i.A)(r.s$)`
  circle {
    fill: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  }

  line,
  path,
  rect {
    stroke: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  }
`,C=(0,i.A)(r.EY)`
  margin: 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}} 0 0;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
`,B=(0,i.A)(r.s$)`
  align-self: flex-end;
  stroke-width: 2px;
  stroke-linecap: round;

  && {
    width: 0.6em;
    height: 1em;
  }
  line {
    stroke: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  }
`,S=(0,i.A)(r.Q5)`
  display: block;
  min-height: auto;
`,R=(0,i.A)(r.Yq)`
  color: ${e=>{var t,a;return e.selected?null==(t=e.theme.colors)?void 0:t.primary:null==(a=e.theme.colors)?void 0:a.text}};
  ${e=>e.selected&&"font-weight: bold;"}

  outline: none;
  &:focus-visible {
    ${r.x_}
    text-decoration: underline;
  }
`,O=({className:e="",dispatch:t})=>{const{toolbarLanguageHeader:a,toolbarFunctionsHeader:l,toolbarLanguageTooltip:i,toolbarFunctionsTooltip:n,toolbarFunctionsCloseButtonAriaLabel:s,printActionLabel:c,copyActionLabel:m,addFavoriteTooltip:h,removeFavoriteCancelLabel:g,removeFavoriteConfirmLabel:v,removeFavoriteHeader:b,removeFavoriteLabel:p,removeFavoriteTooltip:f,guide:x,toolbar:$,...j}=(0,r.Bi)();if(!x||!$||(e=>{const{allowCopy:t=!1,allowPrint:a=!1,guideCategories:o=!1,language:l=!1,showFavoriteToggle:i=!1,picker:n=u.uq.NONE}=e;return!t&&!a&&!l&&!i&&!o||n===u.uq.NONE})($))return null;const{language:k,guideCategories:A,allowCopy:F,allowPrint:z,showFavoriteToggle:N,picker:C}=$;return(0,o.jsxs)(D,{className:(0,d.JS)("humany-guide-toolbar",e),children:[k&&Object.keys(x.translations||{}).length>1&&(0,o.jsx)(L,{guide:x,header:a,tooltip:i,picker:C,...j}),A&&(0,o.jsx)(y,{guide:x,toolbar:$}),(F||z||N)&&(0,o.jsx)(w,{guide:x,header:l,tooltip:n,printActionLabel:c,copyActionLabel:m,addFavoriteTooltip:h,removeFavoriteCancelLabel:g,removeFavoriteConfirmLabel:v,removeFavoriteHeader:b,removeFavoriteLabel:p,removeFavoriteTooltip:f,toolbarFunctionsCloseButtonAriaLabel:s,allowCopy:F,allowPrint:z,showFavoriteToggle:N,picker:C,dispatch:t})]})},D=i.A.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 0 0 0 auto;

  > :not(:last-child) {
    margin: 0 calc(${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}} * 2) 0 0;
  }
`,P=(0,c.forwardRef)((({className:e,accordion:t=!1,...a},l)=>{const{loading:i=!1,dialog:n=[],contactMethods:u=[],showHeader:h=!0,showAnswerVersions:g=!1,defaultAnswerVersionLabel:v="Default",backButtonLabel:b,metadataByLabel:p,metadataModifiedLabel:y,metadataPublishedLabel:x,availablePerspectives:$,metadata:j,toolbar:w,guide:k,error:A}=(0,r.Bi)(),{params:{connection:F,guide:L}}=(0,r.PR)(),z=(0,r.NF)(),N=(0,r.Py)(),C=(0,r.wA)(),B=(0,c.useMemo)((()=>({transform:{img:e=>(0,o.jsx)(r.Yf,{attrs:e,htmlBody:(null==k?void 0:k.body)||""}),a:e=>{const{children:t,...a}=e,l=a["data-target"];if(l&&n.length){const e=n.find((({connection:e})=>e===l));if(e)return(0,o.jsx)(r.J2,{...e,children:t})}return(0,r.IU)(z)(e)}}})),[k,z,n]),S=(0,c.useCallback)((()=>{C("back")}),[C]);if(!k&&!A&&!i)return(0,r.Xn)(z,{...a,className:(0,d.JS)(e,"humany-guide")});const{id:R="",title:D="",body:P="",translations:V={}}=k||{};if(A&&404===A.status)return(0,o.jsx)(s.Mk,{showSearch:!1});const G=!!t&&!!F,Q=Object.keys(V).find((e=>V[e]===`${R}`));return(0,o.jsxs)(q,{ref:l,...a,"data-loading":i,className:(0,d.JS)(e,"humany-guide"),children:[(0,o.jsxs)(M,{"data-loading":i,accordion:t?"true":"false",className:"humany-guide-content",children:[(g&&k||!!w)&&(0,o.jsxs)(I,{className:"humany-guide-top",children:[g&&k&&(0,o.jsx)(m,{defaultAnswerVersionLabel:v,availablePerspectives:$,guide:k}),!!w&&(0,o.jsx)(O,{dispatch:C})]}),!(!D&&!P)&&(0,o.jsx)(H,{className:"humany-guide-body",accordion:t?"true":"false",header:h&&D||void 0,html:P,htmlParseInstruction:B,lang:Q}),n&&-1===P.indexOf("h-option-link")&&(0,o.jsx)(T,{dialog:n}),(0,o.jsx)(E,{backButtonShown:G?"true":"false",contactMethods:u,dispatch:C,guideId:k&&k.id}),!u.length&&L===(null==k?void 0:k.id)&&(0,o.jsx)(f,{backButtonShown:G,accordion:t}),G&&(0,o.jsxs)(Y,{"aria-label":b,onClick:S,children:[(0,o.jsxs)(J,{width:"7",height:"13",viewBox:"0 0 7 13",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[(0,o.jsx)("line",{x1:"6.64645",y1:"12.5513",x2:"0.648357",y2:"6.55319"}),(0,o.jsx)("line",{x1:"0.646447",y1:"6.64455",x2:"6.64454",y2:"0.646465"})]}),b&&(0,o.jsx)("span",{children:b})]}),j&&(0,o.jsx)(_,{...j,modified:null==k?void 0:k.modified,published:null==k?void 0:k.published,modifiedBy:null==k?void 0:k.modifiedBy,publishedBy:null==k?void 0:k.publishedBy,byLabel:p,modifiedLabel:y,publishedLabel:x}),N.map((e=>(0,o.jsx)(W,{id:e.id,branch:"default",embedded:!0},e.id)))]}),(0,o.jsx)(r.aH,{loading:i})]})})),q=i.A.div`
  ${r.MH}
  min-width: 0;
`,H=(0,i.A)(r.fz)`
  ${r.Bh}
  ${e=>{var t;return`padding: ${null==(t=e.theme.sizes)?void 0:t.large};`}}
  display: block;
  line-height: 1.6em;

  ${e=>{var t,a;return(0,r.jc)(e)("h1",l.AH`
        font-size: ${null==(t=e.theme.fonts)?void 0:t.large};
        font-weight: normal;
        line-height: 1.6em;
        line-height: 1.6em;
        margin: 0 0 ${null==(a=e.theme.sizes)?void 0:a.small};
      `)}}

  p {
    font-weight: 300;
    font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
    color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
    a {
      display: inline;
    }
  }
`,E=(0,i.A)(n.ContactList)`
  border-top: ${e=>e.theme.border};
  ${e=>"true"===e.backButtonShown&&`border-bottom: ${e.theme.border};`}
`,T=(0,i.A)(r.jP)`
  ${e=>{var t,a;return`padding: 0 ${null==(t=e.theme.sizes)?void 0:t.large} ${null==(a=e.theme.sizes)?void 0:a.large};`}}
  display: block;
`,I=i.A.div`
  ${e=>{var t,a;return`padding: calc(${null==(t=e.theme.sizes)?void 0:t.normal}*2) ${null==(a=e.theme.sizes)?void 0:a.large};`}}
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: ${e=>e.theme.border};
  border-radius: ${e=>`${e.theme.borderRadius} ${e.theme.borderRadius}`} 0 0;
  background-color: #ffffff;
`,M=i.A.div`
  ${r.jo}
  display: block;
  > a {
    ${n.contactLink}
  }

  ${e=>"true"===e.accordion&&l.AH`
      white-space: normal;
      box-shadow: none;
      background-color: #fafafa;
    `}
`,_=(0,i.A)(r.OS)`
  display: block;
  ${e=>{var t,a;return`padding: calc(${null==(t=e.theme.sizes)?void 0:t.normal}*2) ${null==(a=e.theme.sizes)?void 0:a.large};`}}
  font-weight: 300;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  border-top: ${e=>e.theme.border};
`,W=(0,i.A)(s.uA)`
  border-top: ${e=>e.theme.border};
`,Y=(0,i.A)(r.$n)`
  ${e=>{var t,a;return`padding: ${null==(t=e.theme.sizes)?void 0:t.normal} calc(${null==(a=e.theme.sizes)?void 0:a.normal} * 2);`}}
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
  text-decoration: underline;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
  span {
    font-weight: 300;
  }
  &:focus-visible {
    ${r.bn}
    padding: ${e=>{var t,a;return`calc(${null==(t=e.theme.sizes)?void 0:t.small} / 2) ${null==(a=e.theme.sizes)?void 0:a.small}`}};
  }
`,J=i.A.svg`
  margin-right: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
  line {
    stroke: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
  }
`}}]);
//# sourceMappingURL=ace-3756.js.map