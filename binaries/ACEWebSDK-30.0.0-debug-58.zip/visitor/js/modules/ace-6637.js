/*! For license information please see ace-6637.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[6637],{66637:(e,r,o)=>{o.r(r),o.d(r,{default:()=>l});var a=o(31085),t=o(15428),s=o(3468),n=o(79867);const l=({className:e,...r})=>{const{label:o,active:t,mode:s="flat",alert:l={}}=(0,n.Bi)(),{symbol:i,label:c,show:u}=l,g=(0,n.wA)();return t?(0,a.jsxs)(f,{className:e,mode:s,"aria-label":o,onClick:()=>{g("toggle")},children:[(0,a.jsx)(m,{children:o}),i&&(0,a.jsx)(d,{showAlert:u,children:(0,a.jsx)(n.s$,{symbol:i,title:c,size:20})})]}):null},i=t.i7`
  0% {
    background-position:0% 51%
  }
  50% {
    background-position:100% 0%
  }
  100% {
    background-position:0% 51%
  }
`,c=t.i7`
  0% {
    transform: rotate(0deg) scale(1.00);
  }
  50% {
    transform:  rotate(0deg) scale(1.00);
  }
  55% {
    transform:  rotate(-3deg) scale(0.80);
  }
  60% {
    transform:  rotate(-3deg) scale(0.80);
  }
  65% {
    transform:  rotate(3deg) scale(1.20);
  }
  70% {
    transform:  rotate(-3deg) scale(1.20);
  }
  75% {
    transform:  rotate(3deg) scale(1.20);
  }
  80% {
    transform:  rotate(-3deg) scale(1.20);
  }
  85% {
    transform:  rotate(3deg) scale(1.20);
  }
  90% {
    transform:  rotate(-3deg) scale(1.20);
  }
  95% {
    transform:  rotate(3deg) scale(1.20);
  }
  100% {
    transform:  rotate(0deg) scale(1);
  }
`,d=s.A.span`
  flex-grow: 0;
  transform: translateX(${e=>e.showAlert?"0px":"50px"});
  opacity: ${e=>e.showAlert?1:0};
  transition: transform 0.5s ease, opacity 0.3s ease;
`,m=s.A.span`
  flex: 1;
  font-weight: 300;
`,u=e=>t.AH`
  animation: ${(e=>{var r,o,a;return t.i7`
  0% {
    background-color: ${null==(r=e.theme.colors)?void 0:r.primary};
  }
  50% {
    background-color: ${null==(o=e.theme.colors)?void 0:o.accent};
  }
  100 {
    background-color: ${null==(a=e.theme.colors)?void 0:a.primary};
  }
`})(e)} 1s ease infinite;
`,g=e=>{var r,o;return t.AH`
  background: linear-gradient(
    155deg,
    ${null==(r=e.theme.colors)?void 0:r.primary},
    ${null==(o=e.theme.colors)?void 0:o.accent}
  );
  background-position: 0px 0px;
  background-size: 200% 200%;
  animation: ${i} 1.5s ease infinite;
`},f=(0,s.A)(n.$n)`
  overflow: hidden;
  padding: ${e=>{var r;return null==(r=e.theme.sizes)?void 0:r.large}};
  border-radius: ${e=>e.theme.borderRadius};
  color: ${e=>{var r;return null==(r=e.theme.colors)?void 0:r.text}};
  ${e=>"flashing"===e.mode?u:"flashingGradient"===e.mode?g:""}
  background-color: ${e=>{var r;return null==(r=e.theme.colors)?void 0:r.primary}};
  display: flex;
  align-items: center;
  justify-content: center;
  i,
  svg {
    animation: ${c} 3s ease infinite;
  }

  &:focus-visible {
    ${e=>(0,n.ns)(e)}
    background: ${e=>{var r;return null==(r=e.theme.colors)?void 0:r.text}};
    color: ${e=>{var r;return null==(r=e.theme.colors)?void 0:r.primary}};
  }
`}}]);
//# sourceMappingURL=ace-6637.js.map