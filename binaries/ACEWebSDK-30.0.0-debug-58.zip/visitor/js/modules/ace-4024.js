/*! For license information please see ace-4024.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[4024],{24024:(e,t,a)=>{a.r(t),a.d(t,{default:()=>_});var s=a(43144);const _=e=>(0,s.unmountComponentAtNode)(e)}}]);
//# sourceMappingURL=ace-4024.js.map