/*! For license information please see ace-1640.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[1640],{61640:(e,t,r)=>{r.r(t),r.d(t,{default:()=>Se});var n=r(31085),a=r(3468),l=r(79867),s=r(27389),i=r(15428),o=r(14041),c=r(91872),d=r(59476);r(33296),r(94701),r(22833);const m=({className:e})=>{const[t,r]=(0,o.useState)(""),[a,i]=(0,o.useState)(0),[c,d]=(0,o.useState)(0),m=(0,l.jf)(),b=(0,l.wA)(),{inputPlaceholder:x="Type your message",inputHidden:y=!1,inputDisabled:$=!1,sendButtonLabel:j="Send message",inputMultiline:k=!0,secondaryAction:w}=(0,l.Bi)(),[A,N]=(0,l.Ll)(!0),z=(0,l.NF)();(0,o.useEffect)((()=>{if(N.current){const{lineHeight:e,maxHeight:t}=getComputedStyle(N.current);if(e&&e.indexOf("px")>-1){const r=e.split("px"),n=parseInt(r[0],10);i(n);const a=t.split("px");d(parseInt(a[0],10))}}}),[N.current]);const C=e=>{e.shiftKey&&k?t.length<1&&e.preventDefault():(e.preventDefault(),t&&t.length>0&&(b("user-submit",{text:t}),r(""),S("")))},S=e=>{(e=>{if(k&&N.current){const t=N.current.scrollHeight;if(t>a){N.current.style.height="auto";let r=t;e.length<1&&(r=a),N.current.style.height=`${r}px`,N.current.style.overflowY=r>=c?"scroll":"hidden"}}})(e),r(e),e&&e.length>0&&b("user-typing",{textLength:e.length})};return y?null:(0,n.jsxs)(g,{grow:k,className:(0,s.JS)("humany-conversation-input",e),scrollableCss:A,isTabbing:m,children:[w&&(0,n.jsx)(p,{className:"humany-secondary-button",disabled:$,onClick:e=>{if(!w)return;e.preventDefault(),b("action",{actionKey:w.action,...w});const{events:t}=z.get("$widget");t.dispatch("tracking:secondary-clicked",{})},title:w.label,"aria-label":w.label,children:(0,n.jsx)(l.s$,{size:24,symbol:{type:"Svg",content:w.icon||"browse"}})}),k?(0,n.jsx)(u,{value:t,onChange:S,onEnter:C,disabled:$,"aria-label":x,placeholder:x,type:"textarea",rows:1,ref:N}):(0,n.jsx)(h,{value:t,onChange:S,onEnter:C,disabled:$,"aria-label":x,placeholder:x}),(0,n.jsx)(v,{className:"humany-send-button",disabled:!1,onClick:C,title:j,"aria-label":j,children:(0,n.jsx)(f,{size:22,symbol:{type:"Svg",content:"send"},hasContent:!!t&&!!t.length})})]})},u=(0,a.A)(l.pd)`
  resize: none;
  flex: 1;
  flex-shrink: 1;
  min-height: 1.2em;
  max-height: 148px;
  line-height: 1.2em;
  height: 1.2em;
  padding: 0;
  margin: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}};
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
  border: none;
  transition: height 200ms linear;
  outline: none;
  &:focus-visible {
    ${l.ns};
    outline-offset: 12px;
  }
`,h=(0,a.A)(l.pd)`
  flex: 1;
  border: none;
  background-color: transparent;
  font-weight: 300;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
  line-height: 1.2em;
  outline: none;
  padding: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}};
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  &::placeholder {
    color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.textLight}};
    font-style: italic;
  }
`,v=(0,a.A)(l.$n)`
  flex: 0 0 50px;
  align-self: stretch;
  background-color: transparent;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  color: #a6a6a6;
  &:focus-visible {
    ${l.ns};
  }
`,p=(0,a.A)(v)`
  border-right: ${e=>e.theme.border};
  margin: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}} 0;
`,g=a.A.div`
  ${e=>e.grow?i.AH`
          min-height: 50px;
          max-height: 150px;
        `:i.AH`
          height: 50px;
        `}
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  background-color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.accent}};
  border-top: ${e=>e.theme.inputBorder};
  ${e=>e["data-has-focus"]&&e.isTabbing&&l.ns}
  textarea {
    ${e=>!!e.scrollableCss&&e.scrollableCss}
  }
`,f=(0,a.A)((({hasContent:e,...t})=>(0,n.jsx)(l.s$,{...t})))`
  line,
  path {
    stroke: ${e=>{var t;return e.hasContent?null==(t=e.theme.colors)?void 0:t.primary:"#a6a6a6"}};
    fill: ${e=>{var t;return e.hasContent?null==(t=e.theme.colors)?void 0:t.primary:"#a6a6a6"}};
  }
`,b=a.A.div`
  width: ${e=>e.avatarSize||"32px"};
  height: ${e=>e.avatarSize||"32px"};
  border-radius: 50%;
  background-color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.accent}};
  border: ${e=>e.theme.border};
  grid-area: avatar;
  align-self: flex-end;
  justify-self: center;
  overflow: hidden;
  margin-right: 10px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};

  > img {
    height: 100%;
    width: 100%;
    object-fit: cover;
  }

  > svg {
    width: 90%;
    height: 90%;
    padding: 10%;
    color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};

    line,
    path,
    circle,
    fill {
      stroke: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
    }
  }
`,x=i.i7`
  0% {
    opacity: 0;
  }
  75% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
`,y=a.A.div`
  display: flex;
  justify-content: center;
  > div {
    height: 10px;
    width: 10px;
    border-radius: 50%;
    margin: 5px;
    background-color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
    animation: ${x} 1s infinite;
  }
  > div:nth-of-type(2) {
    animation-delay: 100ms;
  }
  > div:nth-of-type(3) {
    animation-delay: 200ms;
  }
`,$=a.A.div`
  grid-area: content;
  max-width: 100%;
  overflow: hidden;
`,j=(0,a.A)(l.o5)`
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
  font-weight: normal;
  margin: 0;
`,k=a.A.div`
  display: flex;
  ${e=>e.left&&"justify-content: start;"};
  ${e=>e.center&&"justify-content: center;"};
  ${e=>e.right&&"justify-content: end;"};
`,w=a.A.div`
  ${e=>{var t;return e.padded&&`padding: ${null==(t=e.theme.sizes)?void 0:t.medium};`}}
  ${e=>!e.user&&e.stacked&&A(e.stacked,e.theme)}
    ${e=>e.user&&e.stacked&&N(e.stacked,e.theme)}

    display: inline-block;
  margin-top: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
  && > * {
    overflow-wrap: break-word;
    word-wrap: break-word;
    word-break: break-all;
    word-break: break-word;
    hyphens: auto;
  }
  max-width: 100%;
  ${e=>e.fullWidth&&"width: 100%;"}
`,A=(e,t)=>{var r,n;const a=i.AH`
    background-color: ${null==(r=t.colors)?void 0:r.accent};
    color: ${null==(n=t.colors)?void 0:n.text};
    ${t.border&&`border: ${t.border};`};
  `;return t.borderRadius?i.AH`
    ${a}

    border-top-right-radius: ${t.borderRadius};
    border-bottom-right-radius: ${t.borderRadius};

    ${"first"===e&&`\n            border-top-left-radius: ${t.borderRadius};\n        `}

    ${"last"===e&&`\n            border-bottom-left-radius: ${t.borderRadius};\n        `}
  `:a},N=(e,t)=>{var r,n;const a=i.AH`
    background-color: ${null==(r=t.colors)?void 0:r.primary};
    color: ${null==(n=t.colors)?void 0:n.accent};
  `;return t.borderRadius?i.AH`
    ${a}

    border-top-left-radius: ${t.borderRadius};
    border-bottom-left-radius: ${t.borderRadius};

    ${"first"===e&&`\n            border-top-right-radius: ${t.borderRadius};\n        `}

    ${"last"===e&&`\n            border-bottom-right-radius: ${t.borderRadius};\n        `}
  `:a},z=a.A.div`
  margin-bottom: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
  &:last-child {
    margin-bottom: 0;
  }
`,C=e=>{var t,r;return i.AH`
  margin: ${null==(t=e.theme.sizes)?void 0:t.medium} 0;
  padding: 0 ${null==(r=e.theme.sizes)?void 0:r.medium};
`},S=(0,a.A)(c.s2)`
  & button.humany-form-component-button {
    ${e=>{var t,r,n,a;return(null==(t=e.theme.colors)?void 0:t.primary)&&(null==(r=e.theme.colors)?void 0:r.accent)&&(0,l.kI)({active:!1,primaryColor:null==(n=e.theme.colors)?void 0:n.primary,secondaryColor:null==(a=e.theme.colors)?void 0:a.accent,theme:e.theme})}};
    display: block;
    width: 100%;
    margin-bottom: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
  }
  & button.humany-form-component-submit {
    width: 100%;
    margin: 0;
    :not(:last-child) {
      margin-bottom: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
    }
  }
`,H=(0,a.A)(l.Ed)`
  white-space: pre-wrap;
  a {
    color: ${e=>e.theme.colors.link};
    &:focus {
      ${e=>{var t;return(null==(t=e.theme.accessibility)?void 0:t.isTabbing)&&l.ns}};
    }
  }
`,R=(0,a.A)(l.B8)`
  padding: 0;
  list-style: none;
  margin: 0 -${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
  > li {
    margin: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
  }
`,L=a.A.button`
  ${e=>(0,l.gX)(e)};
  display: block;
  background-color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
  width: 100%;
  color: #fff;
  &:focus-visible {
    ${l.ns}
    background-color: transparent;
  }
`,K=(0,o.forwardRef)((({boxed:e,className:t,agentData:r},a)=>(0,n.jsx)($,{ref:a,children:(0,n.jsx)(k,{left:e,center:!e,children:(0,n.jsx)(w,{padded:!!e,stacked:e?"first":void 0,children:(0,n.jsxs)(y,{children:[(0,n.jsx)("div",{}),(0,n.jsx)("div",{}),(0,n.jsx)("div",{})]})})})}))),_=o.createContext(null),I=a.A.p`
  && {
    font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.small}};
    font-weight: 300;
  }
  margin: 0;
  line-height: 1.5em;
  grid-area: info;
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
`,B=(e,t)=>new Date(e).toLocaleTimeString(t||[],{hour:"numeric",minute:"2-digit"}),E=({className:e,name:t,timestamp:r,ariaHidden:a=!1})=>{const l=(0,o.useContext)(_);if(!t&&!r)return null;let s="";return t?s=r?`${t}: ${B(r,l)}`:t:r&&(s=B(r,l)),(0,n.jsx)(I,{"aria-hidden":a,children:s})},D=({className:e,children:t,sender:r,timestamp:a})=>{const{avatar:i,name:o}=r,{avatarSize:c,avatarLabel:d="Avatar"}=(0,l.Bi)();return(0,n.jsxs)(F,{hasAvatar:!!i,className:(0,s.JS)(e,"humany-conversation-agent-message"),children:[i&&(0,n.jsx)(b,{className:"humany-agent-avatar",avatarSize:c,children:"string"==typeof i?(0,n.jsx)("img",{src:i,alt:d}):(0,n.jsx)(l.s$,{symbol:i})}),t,(0,n.jsx)(E,{name:o,timestamp:a,ariaHidden:!0})]})},F=a.A.div`
  display: grid;
  margin-right: 10%;
  width: 90%;
  ${e=>e.hasAvatar?i.AH`
          grid-template-columns: auto 1fr;
          grid-template-rows: 1fr auto;
          grid-template-areas:
            'avatar content'
            '. info';
        `:i.AH`
          grid-template-columns: 1fr;
          grid-template-rows: 1fr auto;
          grid-template-areas:
            'content'
            'info';
        `};
`,T=(0,o.forwardRef)((({className:e,children:t,timestamp:r,discrete:a,fullWidth:l},i)=>(0,n.jsx)(J,{ref:i,className:(0,s.JS)(e,"humany-conversation-system-message"),fullWidth:l,children:a?(0,n.jsxs)(O,{className:"humany-conversation-discrete-message",children:[t,(0,n.jsx)(E,{timestamp:r})]}):(0,n.jsxs)(n.Fragment,{children:[t,(0,n.jsx)(E,{timestamp:r})]})}))),J=a.A.div`
  ${e=>e.fullWidth&&"width: 100%"};
  padding: 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.large}};
  overflow: auto;
`,O=a.A.div`
  text-align: center;
  word-wrap: break-word;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  > p {
    margin: 0;
  }
`,M=({className:e,children:t,timestamp:r})=>{const{userLabel:a=""}=(0,l.Bi)();return(0,n.jsxs)(q,{className:(0,s.JS)(e,"humany-conversation-user-message"),children:[t,(0,n.jsx)(E,{name:a,timestamp:r,ariaHidden:!0})]})},q=a.A.div`
  margin-left: 10%;
  width: 90%;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
`,W=e=>Array.isArray(e)?e:Object.keys(e).map((t=>({label:e[t],actionKey:t}))),V=({header:e,actions:t,dispatch:r})=>{const a=(0,l.NF)(),{events:s}=a.get("$widget");return(0,n.jsx)(X,{className:"humany-conversation-button-list",header:e,items:W(t),renderItem:e=>{var t;const a=!(null==(t=null==e?void 0:e.data)||!t.href);return(0,n.jsx)("li",{children:a?(0,n.jsxs)(U,{href:e.data.href,target:e.data.target,"aria-label":e.label,title:e.label,children:[(0,n.jsx)(l.s$,{symbol:e.symbol}),e.label]}):(0,n.jsxs)(P,{onClick:()=>{r("action",e),s.dispatch("tracking:button-list-item-clicked",e)},"aria-label":e.label,title:e.label,children:[(0,n.jsx)(l.s$,{symbol:e.symbol}),e.label]})},e.actionKey)}})},X=(0,a.A)(l.kk)`
  ${l._R}
  > ul {
    display: flex;
    flex-wrap: wrap;
    gap: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
    > li {
      margin: 0;
    }
  }
  ${C}
`,U=(0,a.A)(l.N_)`
  ${l.gX};

  display: block;
  padding: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
  background-color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
  width: 100%;
  color: #ffffff;
  overflow: hidden;
  text-overflow: ellipsis;
  &:focus-visible {
    ${l.ns}
    background-color: transparent;
  }

  i,
  svg {
    margin-right: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
  }
`,P=(0,a.A)(l.$n)`
  ${l.gX};

  display: block;
  padding: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
  background-color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
  width: 100%;
  color: #ffffff;
  overflow: hidden;
  text-overflow: ellipsis;
  &:focus-visible {
    ${l.ns}
    background-color: transparent;
  }

  i,
  svg {
    margin-right: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
  }
`,Z=({type:e,content:t={}})=>{const r=(0,l.xZ)(e);return r&&e?(0,n.jsx)(o.Suspense,{fallback:null,children:(0,n.jsx)(r,{...t})}):null},Y=({body:e})=>(0,n.jsx)(G,{className:"humany-html",html:e}),G=(0,a.A)(l.Ed)`
  ${l.Bh}
  color: inherit;
  white-space: normal;
  ${C}
  a {
    color: ${e=>e.theme.colors.link};
    &:focus-visible {
      ${l.ns};
    }
  }
  p {
    word-break: auto-phrase;
  }
`,Q=({header:e,actions:t,dispatch:r})=>(0,n.jsx)(ee,{className:"humany-conversation-item-list",header:e,items:W(t),renderItem:e=>{var t;return(0,n.jsx)("li",{children:(0,n.jsxs)(te,{children:[(null==(t=e.symbol)?void 0:t.content)&&(0,n.jsx)("div",{className:"item-icon",children:(0,n.jsx)(l.s$,{size:22,symbol:{type:e.symbol.type,content:e.symbol.content}})}),(0,n.jsxs)("div",{className:"item-body",children:[(0,n.jsx)(l.$n,{onClick:()=>{r("action",e)},"aria-label":e.label,title:e.label,children:e.label}),e.description&&(0,n.jsx)("p",{children:e.description})]})]})},e.actionKey)}}),ee=(0,a.A)(l.kk)`
  ${l._R}

  > .humany-paragraph {
    ${C}
    margin-bottom: 0;

    h1 {
      margin: 0;
    }
  }

  ${e=>(0,l.jc)(e)("h1",i.AH`
        white-space: normal;
      `)}

  > ul {
    display: flex;
    flex-direction: column;
    gap: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
    > li {
      margin: 0;
    }
  }

  li {
    border-bottom: ${e=>e.theme.border};

    &:last-of-type {
      border-bottom: none;
    }
  }
`,te=a.A.div`
  display: flex;
  gap: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}};
  ${C}

  .item-icon {
  }

  .item-body {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};

    p {
      margin: 0;
      white-space: normal;
    }
  }

  button {
    background: transparent;
    border: none;
    font-family: inherit;
    font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
    cursor: pointer;
    padding: 0;
    margin: 0;

    &:focus-visible {
      ${l.ns}
      span {
        color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
        text-decoration: underline;
      }
    }
  }
`,re=({header:e,actions:t,dispatch:r})=>{const a=(0,l.ZC)(t),i=(0,o.useRef)(),c=(0,l.jf)(),d=(0,l.NF)(),{events:m}=d.get("$widget");return(0,o.useEffect)((()=>{if(a&&Array.isArray(t)&&Array.isArray(a)&&a.length<t.length&&i.current){const e=i.current.querySelectorAll(".humany-conversation-link-list > ul > li"),r=e[a.length];if(e.length===t.length&&a.length){const t=e[a.length-1];if(t){const e=t.querySelector(".humany-button");e&&e.focus()}}else r&&new MutationObserver(((e,t)=>{e.forEach((e=>{if(e.addedNodes){const r=Array.from(e.addedNodes).find((e=>"BUTTON"===e.tagName));r&&(0,s.jR)(i.current,document.activeElement)&&(c&&r.focus(),t.disconnect())}}))})).observe(r,{attributes:!1,characterData:!1,childList:!0,subtree:!0,attributeOldValue:!1,characterDataOldValue:!1})}})),(0,n.jsx)(ne,{ref:i,className:"humany-conversation-link-list",header:e,items:W(t),renderItem:e=>(0,n.jsx)("li",{children:(0,n.jsxs)(ae,{help:"help"===e.actionKey,onClick:()=>{r("action",e),m.dispatch("tracking:link-list-item-clicked",e)},"aria-label":e.label,title:e.label,children:[e.label,"help"===e.actionKey&&(0,n.jsx)(l.s$,{size:14,symbol:{type:"Svg",content:"caret-down"}})]})},e.actionKey)})},ne=(0,a.A)(l.kk)`
  ${l._R}
  ${C}

    ${e=>(0,l.jc)(e)("h1",i.AH`
        white-space: normal;
      `)}

    > ul {
    display: flex;
    flex-direction: column;
    gap: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
    > li {
      margin: 0;
    }
  }
`,ae=(0,a.A)(l.$n)`
  display: block;
  text-align: left;
  font-weight: 300;
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
  max-width: 100%;
  text-overflow: ellipsis;
  overflow: hidden;

  ${e=>{var t,r;return e.help&&i.AH`
      color: ${null==(t=e.theme.colors)?void 0:t.text};
      text-decoration: underline;

      i,
      svg {
        margin-left: ${null==(r=e.theme.sizes)?void 0:r.small};
      }
    `}}

  &:focus-visible {
    ${l.ns}
    span {
      color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
      text-decoration: underline;
    }
  }
`,le=()=>(0,n.jsx)(se,{className:"humany-conversation-separator"}),se=a.A.div`
  ${e=>e.theme.border&&`border-bottom: ${e.theme.border};`}
  width: 100%;
`,ie=({text:e})=>(0,n.jsx)(oe,{className:"humany-conversation-text",variant:"span",children:e}),oe=(0,a.A)(l.o5)`
  ${C}
`,ce=({header:e="Video call",acceptLabel:t="Accept",declineLabel:r="Decline",dispatch:a})=>{const s=(0,o.useMemo)((()=>[{label:t,actionKey:"accept-video-call",symbol:{type:"Svg",content:"video"}},{label:r,actionKey:"decline-video-call",symbol:{type:"Svg",content:"close"}}]),[t,r]);return(0,n.jsx)(de,{className:"humany-conversation-video-request",header:e,items:s,renderItem:e=>{const t="accept-video-call"===e.actionKey?"#70c48e":"#da5c85";return(0,n.jsx)("li",{children:(0,n.jsx)(me,{onClick:()=>{a("action",e)},"aria-label":e.label,title:e.label,bgColor:t,children:(0,n.jsx)(l.s$,{symbol:e.symbol,size:25})})},e.actionKey)}})},de=(0,a.A)(l.kk)`
  ${e=>(0,l._R)(e)}
  > ul {
    display: flex;
    flex-wrap: wrap;
    gap: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
    > li {
      margin: 0;
    }
  }
  ${e=>C(e)}
`,me=(0,a.A)(l.$n)`
  ${l.gX};

  background-color: ${e=>e.bgColor};
  display: flex;
  justify-content: center;
  align-items: center;
  color: #ffffff;
  width: 46px;
  height: 46px;
  border-radius: 100%;

  &:focus-visible {
    ${l.ns}
    background-color: transparent;

    i,
    svg {
      color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};

      path {
        stroke: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
      }
    }
  }

  i,
  svg {
    color: #fff;

    path {
      stroke: #fff;
    }
  }
`,ue=([e,t])=>({type:e,content:t}),he=({items:e,dispatch:t})=>{const r=e.map(ue).filter((e=>e.type.includes("ace-knowledge"))).map((e=>"humany-"+e.type.toString()));return!!e.map(ue).filter((e=>{const t=null==e?void 0:e.content,r=null==t?void 0:t.actions;return!(null==r||!r.filter((e=>"contact"===e.actionKey)).length)})).length&&r.push("humany-secondary-action-list"),!!e.map(ue).filter((e=>{var t;const r=null==e?void 0:e.content;return!(null==(t=null==r?void 0:r.tags)||!t.includes("category"))})).length&&r.push("humany-category-list"),(0,n.jsx)(ve,{role:"none",className:(0,s.JS)("humany-message-list",r.join(" ")),items:e.map(ue),renderLi:!0,renderItem:e=>{switch(e.type){case d.ss.Text:return(0,n.jsx)(ie,{text:e.content});case d.ss.HTML:return(0,n.jsx)(Y,{...e.content});case d.ss.Separator:return(0,n.jsx)(le,{...e.content});case d.ss.ItemList:return(0,n.jsx)(Q,{...e.content,dispatch:t});case d.ss.LinkList:return(0,n.jsx)(re,{...e.content,dispatch:t});case d.ss.ButtonList:return(0,n.jsx)(V,{...e.content,dispatch:t});case d.ss.VideoRequest:return(0,n.jsx)(ce,{...e.content,dispatch:t});default:return(0,n.jsx)(Z,{type:e.type,content:e.content})}}})},ve=(0,a.A)(l.B8)`
  ${l.p_}

  > li {
    margin: 0;
  }
`,pe=(0,o.forwardRef)((({className:e,timestamp:t,sender:r,type:a,content:s},i)=>{const c=(0,o.useCallback)((e=>{let t="first";return s.length>1&&(t=0===e?"first":e+1===s.length?"last":"middle"),t}),[s]),{userLabel:m=""}=(0,l.Bi)();switch(a){case d.Jw.System:return(0,n.jsx)(n.Fragment,{children:s.map((r=>{const{key:a,body:s,title:o,form:c,actions:d}=r,m=!(!s||o||c||d);return(0,n.jsx)(T,{className:e,discrete:m,ref:i,timestamp:t,fullWidth:!!c||!!d,children:m&&s?(0,n.jsx)(l.Ed,{html:s}):(0,n.jsx)(ge,{isSystem:!0,content:r})},a)}))});case d.Jw.Agent:return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(fe,{className:"humany-sr-only",children:(0,n.jsx)(E,{name:null==r?void 0:r.name,timestamp:t})}),(0,n.jsx)(D,{sender:r,timestamp:t,className:e,children:(0,n.jsx)($,{className:"humany-message-content-bundle",children:s.map(((e,t)=>(0,n.jsx)(k,{className:"humany-message-container",left:!0,ref:i,children:(0,n.jsx)(ge,{content:e,stacked:c(t)})},e.key)))})})]});case d.Jw.User:return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(fe,{className:"humany-sr-only",children:(0,n.jsx)(E,{name:m,timestamp:t})}),(0,n.jsx)(M,{timestamp:t,className:e,children:(0,n.jsx)($,{className:"humany-message-content-bundle",children:s.map(((e,t)=>(0,n.jsx)(k,{className:"humany-message-container",right:!0,ref:i,children:(0,n.jsx)(ge,{isUser:!0,content:e,stacked:c(t)})},e.key)))})})]});default:return null}})),ge=({content:e,isUser:t,isSystem:r,stacked:a})=>{const s=(0,l.wA)(),{title:i,body:o,actions:c,form:d,items:m}=e;return m?(0,n.jsx)(w,{className:"humany-message-content",user:!!t,stacked:a,children:(0,n.jsx)(he,{items:m,dispatch:s})}):(0,n.jsxs)(w,{className:"humany-message-content",padded:!r,user:!!t,stacked:a,fullWidth:!!d||!!c,children:[i&&(0,n.jsx)(z,{children:(0,n.jsx)(j,{variant:"h2",children:i})}),o&&(0,n.jsx)(z,{children:(0,n.jsx)(H,{html:o})}),d&&(0,n.jsx)(z,{children:(0,n.jsx)(S,{...d,onChange:(e,t)=>{s("form",{data:t,formKey:d.schema.id,actionKey:e})}})}),c&&(0,n.jsx)(z,{children:(0,n.jsx)(R,{items:Object.keys(c).map((e=>({label:c[e],actionKey:e}))),renderItem:e=>(0,n.jsx)("li",{children:(0,n.jsx)(L,{onClick:()=>{s("action",e.actionKey)},children:e.label})},e.actionKey)})})]})},fe=a.A.div`
  position: absolute !important;
  height: 1px;
  width: 1px;
  overflow: hidden;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  left: -10000000px;
  top: auto;
`,be=()=>{const{skipToLatestMessageLabel:e="Skip to latest message"}=(0,l.Bi)(),t=(0,l.NF)(),r=()=>{const e=t.get("widgetDOMElement");if(e){const t=e.querySelectorAll(".humany-conversation-entry");t.length&&t[t.length-1].focus()}};return(0,n.jsx)(xe,{className:"humany-skip-to-latest-message",onKeyDown:e=>{("Enter"===e.key||13===e.keyCode)&&r()},onClick:r,children:e})},xe=a.A.button`
  position: absolute;
  bottom: 60px;
  text-align: center;
  background-color: white;
  text-decoration: none;
  padding: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
  border-radius: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
  left: -10000000px;
  &:focus-visible {
    left: 50%;
    transform: translateX(-50%);
    ${l.ns};
  }
`,ye=()=>{const e=(0,l.NF)(),t=(0,o.useCallback)((e=>{e&&setTimeout((()=>{e.scrollIntoView({block:"start",behavior:"smooth"})}),250)}),[]),[r,a]=(0,l.Ll)(!0),{messages:s,loading:i,typingActors:c=[],providers:d=[]}=(0,l.Bi)(),u=o.useRef((null==s?void 0:s.length)||0),h=d.includes("ace-knowledge-bot");return(0,o.useEffect)((()=>{const t=e.get("widgetDOMElement");if(t&&h){const e=t.querySelectorAll(".humany-conversation-entry");e.length&&e.length>u.current&&(u.current=e.length,e[e.length-1].focus())}})),(0,n.jsxs)(n.Fragment,{children:[(0,n.jsxs)($e,{tabIndex:0,scrollableCss:r,ref:a,children:[s&&s.length?s.map(((e,r)=>{const{type:a,timestamp:l,sender:s,content:i}=e;return(0,n.jsx)(je,{className:"humany-conversation-entry",tabIndex:-1,children:(0,n.jsx)(pe,{...e,ref:t})},`${a}_${null==s?void 0:s.name}_${l}_${i[0].key}`)})):null,c&&c.length?c.map(((e,r)=>(0,n.jsx)(je,{id:`typing_${e.name}`,children:(0,n.jsx)(D,{timestamp:Date.now(),sender:e,children:(0,n.jsx)(K,{boxed:!0,ref:t})})},`typing_${e.name}`))):null,i&&(0,n.jsx)(je,{children:(0,n.jsx)(K,{ref:t})})]}),(0,n.jsx)(m,{}),(0,n.jsx)(be,{})]})},$e=a.A.div`
  display: flex;
  flex-direction: column;
  align-items: stretch;
  flex: 0 1 100%;
  padding: 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}};
  ${e=>!!e.scrollableCss&&e.scrollableCss};
  &:focus-visible {
    ${e=>(0,l.ns)(e)};
  }
`,je=a.A.div`
  margin: 0;
  margin-bottom: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}};

  &:first-of-type {
    margin-top: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}};
  }

  &:last-of-type {
    padding-bottom: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}};
  }

  & span,
  p,
  a,
  div {
    font-weight: 300;
  }

  & b,
  h1 {
    font-weight: normal;
  }

  &:focus-visible {
    ${l.ns}
    border-radius: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
  }
  ${e=>(0,l.jc)(e)("h1",i.AH`
        font-weight: normal;
      `)}
`,ke=({dispatch:e})=>{const t=(0,o.useRef)(null);return(0,o.useEffect)((()=>{t.current&&t.current.parentNode&&e("overlay-mounted",t.current)}),[t]),(0,n.jsx)(l.yH,{portalId:"humany-conversation-overlay-portal",className:"humany-conversation-overlay-outlet",ref:t})},we=({dispatch:e,header:t,buttonLabel:r})=>(0,n.jsxs)(Ae,{portalId:"humany-conversation-portal",className:"humany-conversation-outlet",children:[(0,n.jsxs)(Ne,{className:"humany-conversation-outlet-head",children:[(0,n.jsx)(Ce,{className:"humany-conversation-outlet-head-button","aria-label":r,title:r,onClick:()=>e("hide-overlay-conversation"),children:(0,n.jsx)(l.s$,{symbol:{type:"Svg",content:"caret-down"},size:20})}),t&&(0,n.jsx)(ze,{className:"humany-conversation-outlet-header",variant:"h1",children:t})]}),(0,n.jsx)(ye,{})]}),Ae=(0,a.A)(l.yH)`
  z-index: 11;
  top: auto;
  height: 65%;
  background-color: #ffffff;
  display: flex;
  flex-direction: column;
  border-top-right-radius: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.large}};
  border-top-left-radius: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.large}};
`,Ne=a.A.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
  padding: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
  ${e=>e.theme.border&&`border-bottom: ${e.theme.border};`}
`,ze=(0,a.A)(l.o5)`
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.medium}};
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  margin: 0;
`,Ce=(0,a.A)(l.$n)`
  display: flex;
  align-items: center;
  justify-content: center;
  padding: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}} ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}};
  ${e=>e.theme.borderRadius&&`border-radius: ${e.theme.borderRadius};`}

  &:focus-visible {
    ${l.ns};
  }

  svg line {
    stroke: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  }
`,Se=({className:e,...t})=>{const{overlay:r,overlayConversationHeader:a,overlayConversationCloseLabel:i,conversationControllerId:o}=(0,l.Bi)(),c=(0,l.wA)(),d=(0,l.NF)().get("$settings");return(0,n.jsx)(l.rZ.Provider,{value:o?{id:o}:null,children:(0,n.jsxs)(_.Provider,{value:null==d?void 0:d.language,children:[(0,n.jsx)(He,{"aria-live":"polite",...t,className:(0,s.JS)(e,"humany-conversation-component"),children:(0,n.jsx)(ye,{})}),r&&(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(ke,{dispatch:c}),r.conversation&&(0,n.jsx)(we,{dispatch:c,header:a,buttonLabel:i})]})]})})},He=a.A.div`
  position: absolute;
  right: 0;
  left: 0;
  bottom: 0;
  top: 0;
  overflow: hidden;
  display: flex;
  flex-direction: column;
`}}]);
//# sourceMappingURL=ace-1640.js.map