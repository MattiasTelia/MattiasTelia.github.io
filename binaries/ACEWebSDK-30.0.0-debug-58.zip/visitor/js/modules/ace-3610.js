/*! For license information please see ace-3610.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[3610],{43610:(a,s,e)=>{e.r(s),e.d(s,{default:()=>c});var i=e(31085),t=e(3468),n=e(87744),o=e(27389);const c=({className:a,...s})=>{const e=(0,n.NF)(),{showHeader:t,notificationList:c,loading:d=!1}=(0,n.Bi)();return null!=c&&c.notifications.length||d?(0,i.jsx)(l,{...s,className:a,notificationList:c,loading:d,showHeader:t}):(0,n.Xn)(e,{...s,className:(0,o.JS)(a,"humany-notification-list")})},l=(0,t.A)(n.qb)`
  ${a=>(0,n.jo)(a)}
`}}]);
//# sourceMappingURL=ace-3610.js.map