/*************************************************************
 * CONFIGURATION OF ACE Web SDK
 *
 * For more information, see
 * Telia ACE Configuration Instruction ACE Web SDK
 *************************************************************/

CallGuide.config.services = {
  /* ***************************************
   * GENERAL
   *************************************** */

  ACEWebSDK: {
    features: {
      // The features section can be used to turn on or off specific features in Web SDK.

      // Enable ACE Chat API (to load chat client, see loadACEChatClient setting below)
      enableChat: true,

      // Enable ACE Proactive Web
      enableProactiveWeb: false,

      // Enable ACE Cobrowsing
      enableCobrowsing: false,

      // Load ACE Online One Widget (v5) and ACE Plugins for ACE Knowledge
      // ACE Online Widgets v5 is One Widget
      loadACEKnowledge_v5: true,

      // JavaScript API for ACE Web API (client version) related functions
      enableWebApi: true,

      // Load ACE Reference Chat Client files 'ACEChat.min.js', 'ACEChat.min.js'
      // and chat config file (defined in conf.chat.conf.aceChatClientConfig)
      loadACEChatClient: true,

      // Insights is unavailable in this version of Web SDK,
      // and no supported frameworks are available.
      enableInsights: false,
    },

    conf: {
      // /////////////////
      // LANGUAGE SECTION
      // /////////////////

      languages: {
        nb: '1',
        en: '1',
        fi: '1',
        sv: '1',
        da: '1',
      },
      defaultLanguage: 'en',

      // langDetect can be reached on either Chat Engine,
      // Proactive Web Engine, or COB Server.
      langDetectUrl: 'https://chat.domain.ex/langDetect',

      // ///////////////////
      // ASSOCIATED DOMAINS
      // ///////////////////

      // For multiple domains to work, singleDomain need to be set to false.
      // See Domains section in Configuration Instructions for more details.

      singleDomain: false,

      // One instance of ACE Web SDK can be loaded on more than one domain,
      // and cobrowsing and chat follows seamlessly across the involved domains.
      // However, the involved domains (or origins) must be declared here.
      // Further, CORS allowed origins for the subproducts chat, proactive web, and cobrowsing
      // must be configured for EACH corresponding engine.
      // From ACE 13, the list of allowed origins for Chat Engines can be set in ACE Admin,
      // per Chat Engine and Organisation Area.
      // From ACE 15, ACE Web SDK has its onw list, configured in ACE Admin. This list is applied
      // to the CORS control in ACE Web API, but can also be fetched by ACE Web SDK.
      // ACE Web SDK uses the list of origins to decide if the session ids can be fetched or not.
      //
      // Example declaring a domain list (and and a white list of origins for session ids) in the
      // present file:
      // domains: ['cust.domain.ex', 'www.domain.ex', 'wds.domain.ex'],

      // Example fetching the list of origins from a URL:
      // allowedOrigins: 'https://www.callguide.com/wda/getConfiguration',

      // As if this amount of options was not enough, you can also configure allowedOrigins as an
      // array of white-listed origins. Example:
      // allowedOrigins: ['https://b2b.acme.com', 'https://consumer.acme.com'],

      // If both allowedOrigins and domains are declared, the visitor clients will use the
      // allowedOrigins, and the domains parameter is required only for agent cobrowsing client.
      // Thus, if allowedOrigins are used and if no Cobrowsing is configured, the domains parameter
      // can be deleted.

      domains: ['cust.domain.ex', 'www.domain.ex', 'wds.domain.ex'],

      insights: {
        // If true, ACE Web SDK will dispatch custom events ('ace.websdk.insights') within the
        // current window, for each insight event. Applications can subscribe to these by
        // registering corresponding event listeners.
        enableCustomEvents: false,

        // Currently no allowed data-gathering framework available
      },

      // ///////////////////
      // AUTHENTICATION TOKEN
      // ///////////////////

      // ACE Web SDK can fetch a token, for authentication in chat sessions.
      // Two options can be configured here:
      // - From web storage (has predecence if both are configured)
      // - From an URL (format: https://idp.domain.ex/auth/jwt.json)
      // Note: There are also possibilities to add the token using api functions.
      authToken: {
        fromWebStorage: {
          storage: '', // 'local', 'session', or empty to disable!
          key: 'authToken',
        },
        fromUrl: {
          url: '', // Empty to disable!
          responseType: 'json',
          tokenProperty: 'jwt',
        },
      },

      aceWebApi: {
        // For Single-tenant ACE System:
        // URL format: https://{clusterwarehost}/webapi/client/{companyName}
        // Example: baseUrl: 'https://cgedgestage.labbn.se/webapi/client/devtrack1',
        //
        // For Multi-tenant ACE System (companyName appended automatically):
        // URL format: https://{clusterwarehost}/webapi/client
        // Example: baseUrl: 'https://cgedgestage.labbn.se/webapi/client',

        baseUrl: 'https://{clusterware}/webapi/client',
        timeout: 3000, // milliseconds
      },

      // Array of configurations, one for each ACE Knowledge Implementation.
      aceKnowledge: [
        {
          // If object has a companyName property, it is loaded only when companyNames match.
          // Otherwise the implementation is always loaded.
          // companyName: '',

          // The URL to the Humany implementation and the version must be provided.
          // Note: Only version 4 and 5 implementations are supported.
          humanyUrl: 'https://{tenant}.humany.net/{implementation}',
          version: 'v5',
          suppressContactCentreStatus: false,
          // External chat form validation can be disabled by setting disableDefaultValidation.
          // Note: humanyUrl: 'localProduction' will override this configuration.
          disableDefaultValidation: false,
          callback: {
            maxAvailableDates: 14,
            minuteInterval: 10,
          },
          chat: {
            enableConversationHistoryTransfer: true,
            enableWritingWhileInQueue: true,
            playChatNoticeSound: false,
          },
          /*
           Dynamic placeholders for plugin texts:
           - For opening hours properties: {{hours}}
           - For queue properties: {{eqt}}, {{position}}, {{agents}}
           - For email properties: {{emailAddress}}
           - For phone number properties: {{phoneNumber}}
           */
          pluginTexts: {
            phone: {
              sv: {
                openingHours: 'Öppettider: {{hours}}',
                queueSituation: 'Beräknad kötid är {{eqt}}.',
                closed: 'Stängt',
                getOpeningHoursError: 'Kan inte hämta öppettider',
                getQueueSituationError: 'Kan inte hämta kötider',
              },
              en: {
                openingHours: 'Opening hours: {{hours}}',
                queueSituation: 'Estimated queue time: {{eqt}} minute/s.',
                closed: 'Closed',
                getOpeningHoursError: 'Technical error fetching opening hours',
                getQueueSituationError: 'Technical error fetching queue information',
              },
              fi: {
                openingHours: 'Aukioloajat: {{hours}}',
                queueSituation: 'Arvioitu jonotusaika on {{eqt}} minuutti/a.',
                closed: 'Suljettu',
                getOpeningHoursError: 'Aukioloaikojen haku epäonnistui teknisen virheen takia',
                getQueueSituationError: 'Jonotustietojen haku epäonnistui teknisen virheen takia',
              },
              no: {
                openingHours: 'Åpningstider: {{hours}}',
                queueSituation: 'Beregnet køtid: {{eqt}} minutt(er).',
                closed: 'Lukket',
                getOpeningHoursError: 'Kan ikke hente åpningstider',
                getQueueSituationError: 'Kan ikke hente køtider',
              },
              da: {
                openingHours: 'Åbningstider: {{hours}}',
                queueSituation: 'Anslået køtid: {{eqt}} minutte/r.',
                closed: 'Lukket',
                getOpeningHoursError: 'Teknisk fejl ved hentning af åbningstider',
                getQueueSituationError: 'Teknisk fejl ved hentning af køinformation',
              },
              de: {
                openingHours: 'Öffnungszeiten: {{hours}}',
                queueSituation: 'Geschätzte Queue-Zeit: {{eqt}} Minute/n.',
                closed: 'Geschlossen',
                getOpeningHoursError: 'Technischer Fehler beim Abrufen der Öffnungszeiten',
                getQueueSituationError: 'Technischer Fehler beim Abrufen der Queue-Zeiten',
              },
            },
            email: {
              sv: {
                openingHours: 'Öppettider: {{hours}}',
                queueSituation: 'Beräknad svarstid är {{eqt}}.',
                closed: 'Stängt',
                getOpeningHoursError: 'Kan inte hämta öppettider',
                getQueueSituationError: 'Kan inte hämta kötider',
                weWillEmailYou: 'Tack för ditt mail! Vi återkommer med svar till {{emailAddress}}.',
              },
              en: {
                openingHours: 'Opening hours: {{hours}}',
                queueSituation: 'Estimated response time: {{eqt}} minute/s.',
                closed: 'Closed',
                getOpeningHoursError: 'Technical error fetching opening hours',
                getQueueSituationError: 'Technical error fetching queue information',
                weWillEmailYou: 'Thank you, we will get back to you at {{emailAddress}}.',
              },
              fi: {
                openingHours: 'Aukioloajat: {{hours}}',
                queueSituation: 'Arvioitu vasteaika: {{eqt}} minuutti/a.',
                closed: 'Suljettu',
                getOpeningHoursError: 'Aukioloaikojen haku epäonnistui teknisen virheen takia',
                getQueueSituationError: 'Jonotustietojen haku epäonnistui teknisen virheen takia',
                weWillEmailYou:
                  'Kiitos yhteydenotostasi! Olemme yhteydessä sähköpostitse osoitteella {{emailAddress}}.',
              },
              no: {
                openingHours: 'Åpningstider: {{hours}}',
                queueSituation: 'Beregnet svartid: {{eqt}} minutt(er).',
                closed: 'Lukket',
                getOpeningHoursError: 'Kan ikke hente åpningstider',
                getQueueSituationError: 'Kan ikke hente køtider',
                weWillEmailYou: 'Takk for e-posten. Vi sender et svar til {{emailAddress}}.',
              },
              da: {
                openingHours: 'Åbningstider: {{hours}}',
                queueSituation: 'Anslået svartid: {{eqt}} minutte/r.',
                closed: 'Lukket',
                getOpeningHoursError: 'Teknisk fejl ved hentning af åbningstider',
                getQueueSituationError: 'Teknisk fejl ved hentning af køinformation',
                weWillEmailYou: 'Tak, vi vender tilbage til dig på {{emailAddress}}.',
              },
              de: {
                openingHours: 'Öffnungszeiten: {{hours}}',
                queueSituation: 'Geschätzte Antwortzeit: {{eqt}} Minute/n.',
                closed: 'Geschlossen',
                getOpeningHoursError: 'Technischer Fehler beim Abrufen der Öffnungszeiten',
                getQueueSituationError: 'Technischer Fehler beim Abrufen der Queue-Zeiten',
                weWillEmailYou:
                  'Danke für Ihre Mail. Wir melden uns mit einer Antwort an {{emailAddress}}.',
              },
            },
            callback: {
              sv: {
                openingHours: 'Öppettider: {{hours}}',
                queueSituation: 'Beräknad kötid är {{eqt}}.',
                closed: 'Stängt',
                getOpeningHoursError: 'Kan inte hämta öppettider',
                getQueueSituationError: 'Kan inte hämta kötider',
                weWillCallYou: 'Vi ringer upp dig på {{phoneNumber}}.',
                nonNumericPhoneNumber: 'Telefonnumret kan endast innehålla siffror.',
                nonCanonicalPhoneNumber: 'Ange telefonnumret på formatet +46 70 234 56 78.',
                phoneNumberAlreadyBooked:
                  'Det finns redan en begäran om uppringning till {{phoneNumber}}.',
                somethingWentWrong: 'Något gick fel. Försök igen senare.',
              },
              en: {
                openingHours: 'Opening hours: {{hours}}',
                queueSituation: 'Estimated queue time: {{eqt}} minute/s.',
                closed: 'Closed',
                getOpeningHoursError: 'Technical error fetching opening hours',
                getQueueSituationError: 'Technical error fetching queue information',
                weWillCallYou: 'We will call you at {{phoneNumber}}.',
                nonNumericPhoneNumber: 'Phone number can only contain numbers.',
                nonCanonicalPhoneNumber: 'Invalid phone number format, please try again.',
                phoneNumberAlreadyBooked:
                  'Phone number {{phoneNumber}} already has a scheduled callback.',
                somethingWentWrong: 'Something went wrong, please try again later.',
              },
              fi: {
                openingHours: 'Aukioloajat: {{hours}}',
                queueSituation: 'Arvioitu jonotusaika on {{eqt}} minuutti/a.',
                closed: 'Suljettu',
                getOpeningHoursError: 'Aukioloaikojen haku epäonnistui teknisen virheen takia',
                getQueueSituationError: 'Jonotustietojen haku epäonnistui teknisen virheen takia',
                weWillCallYou: 'Soitamme sinulle numeroon {{phoneNumber}}.',
                nonNumericPhoneNumber: 'Puhelinnumero voi sisältää vain numeroita.',
                nonCanonicalPhoneNumber: 'Virheellinen puhelinnumeron muoto, yritä uudelleen.',
                phoneNumberAlreadyBooked:
                  'Puhelinnumerolla {{phoneNumber}} on jo takaisinsoittopyyntö.',
                somethingWentWrong: 'Tapahtui jokin virhe. Yritä myöhemmin uudelleen.',
              },
              no: {
                openingHours: 'Åpningstider: {{hours}}',
                queueSituation: 'Beregnet køtid: {{eqt}} minutt(er).',
                closed: 'Lukket',
                getOpeningHoursError: 'Kan ikke hente åpningstider',
                getQueueSituationError: 'Kan ikke hente køtider',
                weWillCallYou: 'Vi ringer deg på {{phoneNumber}}.',
                nonNumericPhoneNumber: 'Telefonnummeret kan kun inneholde tall.',
                nonCanonicalPhoneNumber: 'Ugyldig telefonnummerformat, prøv igjen.',
                phoneNumberAlreadyBooked:
                  'Det finnes allerede en forespørsel om oppringing til {{phoneNumber}}.',
                somethingWentWrong: 'Noe gikk galt. Prøv igjen senere.',
              },
              da: {
                openingHours: 'Åbningstider: {{hours}}',
                queueSituation: 'Anslået køtid: {{eqt}} minutte/r.',
                closed: 'Lukket',
                getOpeningHoursError: 'Teknisk fejl ved hentning af åbningstider',
                getQueueSituationError: 'Teknisk fejl ved hentning af køinformation',
                weWillCallYou: 'Vi ringer til dig på {{phoneNumber}}.',
                nonNumericPhoneNumber: 'Telefonnumre må kun indeholde tal.',
                nonCanonicalPhoneNumber: 'Ugyldigt telefonnummer-format, prøv igen.',
                phoneNumberAlreadyBooked:
                  'Der er allerede planlagt et callback for telefonnummeret {{phoneNumber}}.',
                somethingWentWrong: 'Der gik noget galt, prøv igen senere.',
              },
              de: {
                openingHours: 'Öffnungszeiten: {{hours}}',
                queueSituation: 'Geschätzte Queue-Zeit: {{eqt}} Minute/n.',
                closed: 'Geschlossen',
                getOpeningHoursError: 'Technischer Fehler beim Abrufen der Öffnungszeiten',
                getQueueSituationError: 'Technischer Fehler beim Abrufen der Queue-Zeiten',
                weWillCallYou: 'Wir rufen Sie an unter der Nummer {{phoneNumber}}.',
                nonNumericPhoneNumber: 'Die Telefonnummer kann nur Ziffern enthalten.',
                nonCanonicalPhoneNumber:
                  'Ungültiges Telefonnummernformat, versuchen Sie es bitte erneut.',
                phoneNumberAlreadyBooked:
                  'Für Telefonnummer {{phoneNumber}} ist bereits ein Callback geplant.',
                somethingWentWrong:
                  'Etwas ist schiefgelaufen. Versuchen Sie es bitte später erneut.',
              },
            },
            chatContactMethod: {
              sv: {
                openingHours: 'Öppettider: {{hours}}',
                queueSituation: 'Beräknad kötid är {{eqt}}.',
                closed: 'Stängt',
                getOpeningHoursError: 'Kan inte hämta öppettider',
                getQueueSituationError: 'Kan inte hämta kötider',
                chatCannotStart:
                  'Det går inte att starta en chatt här och nu. Har du redan en chatt på gång någon annanstans?',
                chatStarted: 'Chatten har startat.',
              },
              en: {
                openingHours: 'Opening hours: {{hours}}',
                queueSituation: 'Estimated queue time: {{eqt}} minute/s.',
                closed: 'Closed',
                getOpeningHoursError: 'Technical error fetching opening hours',
                getQueueSituationError: 'Technical error fetching queue information',
                chatCannotStart: 'Chat could not be started.',
                chatStarted: 'Chat has started.',
              },
              fi: {
                openingHours: 'Aukioloajat: {{hours}}',
                queueSituation: 'Arvioitu jonotusaika on {{eqt}} minuutti/a.',
                closed: 'Suljettu',
                getOpeningHoursError: 'Aukioloaikojen haku epäonnistui teknisen virheen takia',
                getQueueSituationError: 'Jonotustietojen haku epäonnistui teknisen virheen takia',
                chatCannotStart: 'Chatin käynnistäminen ei onnistunut.',
                chatStarted: 'Chat on käynnistynyt.',
              },
              no: {
                openingHours: 'Åpningstider: {{hours}}',
                queueSituation: 'Beregnet køtid: {{eqt}} minutt(er).',
                closed: 'Lukket',
                getOpeningHoursError: 'Kan ikke hente åpningstider',
                getQueueSituationError: 'Kan ikke hente køtider',
                chatCannotStart: 'Kan ikke starte chatten.',
                chatStarted: 'Chatten har startet.',
              },
              da: {
                openingHours: 'Åbningstider: {{hours}}',
                queueSituation: 'Anslået køtid: {{eqt}} minutte/r.',
                closed: 'Lukket',
                getOpeningHoursError: 'Teknisk fejl ved hentning af åbningstider',
                getQueueSituationError: 'Teknisk fejl ved hentning af køinformation',
                chatCannotStart: 'Chatten kunne ikke startes.',
                chatStarted: 'Chatten er startet.',
              },
              de: {
                openingHours: 'Öffnungszeiten: {{hours}}',
                queueSituation: 'Geschätzte Queue-Zeit: {{eqt}} Minute/n.',
                closed: 'Geschlossen',
                getOpeningHoursError: 'Technischer Fehler beim Abrufen der Öffnungszeiten',
                getQueueSituationError: 'Technischer Fehler beim Abrufen der Queue-Zeiten',
                chatCannotStart: 'Der Chat konnte nicht gestartet werden.',
                chatStarted: 'Der Chat hat begonnen.',
              },
            },
            chatConversation: {
              sv: {
                chatStarting: 'Chatten startas…',
                chatHeader: 'Chatt',
                chatHeaderClosed: 'Chatten är avslutad',
                quitTooltip: 'Avsluta chatten',
                emailSent: 'Chattkonversation kommer skickas till {{emailAddress}}',
                emailError: 'Det gick inte att skicka e-post till dig.',
                errorMessage:
                  'Vi kan tyvärr inte ta emot din chatt just nu, vänligen försök igen senare',
                inputPlaceholder: 'Skriv ditt meddelande här…',
                emailPrompt: 'Du kan få chatten skickad till dig',
                emailLabel: 'Din e-postadress',
                emailPlaceholder: 'E-postadress',
                emailSkip: 'Nej tack',
                emailSubmit: 'Skicka',
                quitChat: 'Avsluta chatten',
                quitChatConfirm: 'Är du säker på att du vill avsluta chatten?',
                quitChatYes: 'Ja',
                quitChatNo: 'Nej',
                videoHeader: 'Video- och delningsmöte',
                videoAccept: 'Acceptera',
                videoDecline: 'Neka',
                videoWasAccepted: 'Möte accepterades',
                videoWasDeclined: 'Möte nekades',
                videoLoadingMessage: 'Laddar möte…',
                videoHelpText:
                  'Om möte inte startar, tryck på knappen nedan för att byta till text',
                videoShowTextChat: 'Visa textchatten',
                chatDisconnected:
                  'Anslutningsproblem. Meddelanden kan bli försenade. Försöker återansluta ...',
                chatReconnected: 'Anslutning återställd.',
                videoMeetingHeader: 'Videomöte',
                sharingMeetingHeader: 'Delningsmöte',
                videoAndSharingMeetingHeader: 'Video- och delningsmöte',
              },
              en: {
                chatStarting: 'Chat is starting…',
                chatHeader: 'Chat',
                chatHeaderClosed: 'Chat is ended',
                quitTooltip: 'End chat',
                emailSent: 'Chat conversation will be mailed to {{emailAddress}}',
                emailError: 'Could not send email.',
                errorMessage: 'Something went wrong',
                inputPlaceholder: 'Write message here…',
                emailPrompt: 'Send chat conversation',
                emailLabel: 'Your email address',
                emailPlaceholder: 'Email address',
                emailSkip: 'No',
                emailSubmit: 'Send',
                quitChat: 'End chat',
                quitChatConfirm: 'Are you sure you want to end chat?',
                quitChatYes: 'Yes',
                quitChatNo: 'No',
                videoHeader: 'Video and sharing meeting',
                videoAccept: 'Accept',
                videoDecline: 'Decline',
                videoWasAccepted: 'Meeting accepted',
                videoWasDeclined: 'Meeting declined',
                videoLoadingMessage: 'Loading meeting…',
                videoHelpText:
                  'If meeting does not start, click button below to switch to text chat',
                videoShowTextChat: 'Show text chat',
                chatDisconnected:
                  'Connection issues. Messages might be delayed. Attempting to reconnect ...',
                chatReconnected: 'Connection restored.',
                videoMeetingHeader: 'Video meeting',
                sharingMeetingHeader: 'Sharing meeting',
                videoAndSharingMeetingHeader: 'Video and sharing meeting',
              },
              fi: {
                chatStarting: 'Chat käynnistyy...',
                chatHeader: 'Chat',
                chatHeaderClosed: 'Chat on päättynyt',
                quitTooltip: 'Lopeta chat',
                emailSent: 'Chat-keskustelu lähetetään sähköpostiosoitteeseen {{emailAddress}}',
                emailError: 'Sähköpostiviestin lähettäminen ei onnistunut.',
                errorMessage: 'Tapahtui jokin virhe',
                inputPlaceholder: 'Kirjoita viesti tähän…',
                emailPrompt: 'Lähetä chat-keskustelu',
                emailLabel: 'Sähköpostiosoitteesi',
                emailPlaceholder: 'Sähköpostiosoite',
                emailSkip: 'No',
                emailSubmit: 'Lähetä',
                quitChat: 'Lopeta chat',
                quitChatConfirm: 'Haluatko varmasti lopettaa chatin?',
                quitChatYes: 'Kyllä',
                quitChatNo: 'Ei',
                videoHeader: 'Videokokous jakotoiminnallisuuksilla',
                videoAccept: 'Hyväksy',
                videoDecline: 'Hylkää',
                videoWasAccepted: 'Kokous hyväksytty',
                videoWasDeclined: 'Kokous hylätty',
                videoLoadingMessage: 'Ladataan kokous…',
                videoHelpText:
                  'Jos video ei käynnisty, vaihda tekstichatiin napsauttamalla alla olevaa painiketta',
                videoShowTextChat: 'Näytä tekstichat',
                chatDisconnected:
                  'Connection issues. Messages might be delayed. Attempting to reconnect ...',
                chatReconnected: 'Connection restored.',
                videoMeetingHeader: 'Videokokous',
                sharingMeetingHeader: 'Kokous jakotoiminnallisuuksilla',
                videoAndSharingMeetingHeader: 'Videokokous jakotoiminnallisuuksilla',
              },
              no: {
                chatStarting: 'Chatten startes …',
                chatHeader: 'Chat',
                chatHeaderClosed: 'Chatten er avsluttet',
                quitTooltip: 'Avslutt chatten',
                emailSent: 'Chatsamtalen sendes på e-post til {{emailAddress}}',
                emailError: 'Kunne ikke sende e-post.',
                errorMessage: 'Noe gikk galt',
                inputPlaceholder: 'Skriv meldingen din her ...',
                emailPrompt: 'Send chatsamtalen',
                emailLabel: 'Din e-postadresse',
                emailPlaceholder: 'E-postadresse',
                emailSkip: 'Nei',
                emailSubmit: 'Send',
                quitChat: 'Avslutt chatten',
                quitChatConfirm: 'Er du sikker du vil avslutte chatten?',
                quitChatYes: 'Ja',
                quitChatNo: 'Nei',
                videoHeader: 'Video- og delingsmøte',
                videoAccept: 'Godta',
                videoDecline: 'Avvis',
                videoWasAccepted: 'Møte godtatt',
                videoWasDeclined: 'Møte avvist',
                videoLoadingMessage: 'Laster inn møte...',
                videoHelpText:
                  'Hvis møtet ikke startes, klikker du på knappen nedenfor og bytter til tekstchat',
                videoShowTextChat: 'Vis tekstchatten',
                chatDisconnected:
                  'Connection issues. Messages might be delayed. Attempting to reconnect ...',
                chatReconnected: 'Connection restored.',
                videoMeetingHeader: 'Videomøte',
                sharingMeetingHeader: 'Delingsmøte',
                videoAndSharingMeetingHeader: 'Video- og delingsmøte',
              },
              da: {
                chatStarting: 'Chatten starter…',
                chatHeader: 'Chat',
                chatHeaderClosed: 'Chatten er afsluttet',
                quitTooltip: 'Afslut chat',
                emailSent: 'Chat-samtalen sendes på e-mail til {{emailAddress}}',
                emailError: 'Kunne ikke sende e-mail.',
                errorMessage: 'Der gik noget galt',
                inputPlaceholder: 'Skriv en meddelelse her...',
                emailPrompt: 'Send chat-samtale',
                emailLabel: 'Din e-mail-adresse',
                emailPlaceholder: 'E-mail-adresse',
                emailSkip: 'Nej',
                emailSubmit: 'Send',
                quitChat: 'Afslut chat',
                quitChatConfirm: 'Er du sikker på, at du vil afslutte chatten?',
                quitChatYes: 'Ja',
                quitChatNo: 'Nej',
                videoHeader: 'Video- og delingsmøde',
                videoAccept: 'Accepter',
                videoDecline: 'Afvis',
                videoWasAccepted: 'Møde accepteret',
                videoWasDeclined: 'Møde afvist',
                videoLoadingMessage: 'Indlæser møde...',
                videoHelpText:
                  'Hvis mødet ikke starter, kan du klikke på knappen nedenfor for at skifte til tekstchat',
                videoShowTextChat: 'Vis tekstchat',
                chatDisconnected:
                  'Connection issues. Messages might be delayed. Attempting to reconnect ...',
                chatReconnected: 'Connection restored.',
                videoMeetingHeader: 'Videomøde',
                sharingMeetingHeader: 'Delingsmøde',
                videoAndSharingMeetingHeader: 'Video- og delingsmøde',
              },
              de: {
                chatStarting: 'Der Chat beginnt…',
                chatHeader: 'Chat',
                chatHeaderClosed: 'Der Chat ist beendet',
                quitTooltip: 'Chat beenden',
                emailSent: 'Das Chat-Gespräch wird gemailt an {{emailAddress}}',
                emailError: 'E-Mail konnte nicht gesendet werden.',
                errorMessage: 'Etwas ist schiefgelaufen',
                inputPlaceholder: 'Hier Nachricht schreiben...',
                emailPrompt: 'Chat-Gespräch senden',
                emailLabel: 'Ihre E-Mail-Adresse',
                emailPlaceholder: 'E-Mail-Adresse',
                emailSkip: 'Nein',
                emailSubmit: 'Senden',
                quitChat: 'Chat beenden',
                quitChatConfirm: 'Sind Sie sicher, dass Sie den Chat beenden möchten Chat?',
                quitChatYes: 'Ja',
                quitChatNo: 'Nein',
                videoHeader: 'Video- und Freigabetreffen',
                videoAccept: 'Akzeptieren',
                videoDecline: 'Ablehnen',
                videoWasAccepted: 'Treffen akzeptiert',
                videoWasDeclined: 'Treffen abgelehnt',
                videoLoadingMessage: 'Treffen wird geladen...',
                videoHelpText:
                  'Wenn die treffen nicht startet, klicken Sie auf die Schaltfläche unten, um zum Text-Chat zu wechseln',
                videoShowTextChat: 'Text-Chat anzeigen',
                chatDisconnected:
                  'Connection issues. Messages might be delayed. Attempting to reconnect ...',
                chatReconnected: 'Connection restored.',
                videoMeetingHeader: 'Video treffen',
                sharingMeetingHeader: 'Freigabetreffen',
                videoAndSharingMeetingHeader: 'Video- und Freigabetreffen',
              },
            },
          },
        },
        {
          // humanyUrl: 'localProduction' means that the config is fetched from local files
          // (rather the configured location in settingsUrl), not from
          // the config.json for the implementation in the humany back-end.
          // When localProduction is flagged, the configuration object localProduction must be
          // present and complete.
          humanyUrl: 'localProduction',
          version: 'v5',
          suppressContactCentreStatus: false,
          chat: {
            enableConversationHistoryTransfer: true,
            enableWritingWhileInQueue: true,
            playChatNoticeSound: false,
          },
          localProduction: {
            fontAwesomeUrl: 'https://wds.domain.ex/font-awesome-4.7.0/css/font-awesome.min.css',
            initialCssUrl: 'https://wds.domain.ex/instances/#INSTANCE#/localChat/initial-css.css',
            widgetsCssUrl: 'https://wds.domain.ex/instances/#INSTANCE#/localChat/widgets.css',
            widgets: {
              'local-chat': {
                settingsUrl: 'https://wds.domain.ex/instances/#INSTANCE#/localChat/local-chat.json',
                chat: {
                  contactDataForm: {
                    title: 'Stängt!',
                    description: 'Chatten är stängd just nu. Öppettider:',
                    components: [
                      {
                        name: 'customerName',
                        type: 'string',
                        component: 'Text',
                        title: 'Ditt namn',
                        required: true,
                      },
                      {
                        name: 'cid',
                        type: 'string',
                        component: 'Text',
                        title: 'Id-nummer',
                      },
                      {
                        name: 'errand',
                        type: 'array',
                        component: 'RadioButtonList',
                        title: 'Ärende',
                        items: [
                          { label: 'Mobil', value: 'A01' },
                          { label: 'Fast', value: 'A02' },
                          { label: 'Annat', value: 'A03' },
                        ],
                      },
                    ],
                    submitText: 'Starta chatten',
                  },
                  contactDataSettings: {
                    entrance: 'knowsv',
                    errand: 'S01',
                  },
                },
              },
            },
          },
          pluginTexts: {
            chatContactMethod: {
              sv: {
                openingHours: 'Öppettider: {{hours}}',
                queueSituation: 'Beräknad kötid är {{eqt}}.',
                closed: 'Stängt',
                getOpeningHoursError: 'Kan inte hämta öppettider',
                getQueueSituationError: 'Kan inte hämta kötider',
                chatCannotStart: 'Det går inte att starta en chatt här och nu.',
                chatStarted: 'Chatten har startat.',
              },
              en: {
                openingHours: 'Opening hours: {{hours}}',
                queueSituation: 'Estimated queue time: {{eqt}} minute/s.',
                closed: 'Closed',
                getOpeningHoursError: 'Technical error fetching opening hours',
                getQueueSituationError: 'Technical error fetching queue information',
                chatCannotStart: 'Chat could not be started.',
                chatStarted: 'Chat has started.',
              },
              fi: {
                openingHours: 'Aukioloajat: {{hours}}',
                queueSituation: 'Arvioitu jonotusaika on {{eqt}} minuutti/a.',
                closed: 'Suljettu',
                getOpeningHoursError: 'Aukioloaikojen haku epäonnistui teknisen virheen takia',
                getQueueSituationError: 'Jonotustietojen haku epäonnistui teknisen virheen takia',
                chatCannotStart: 'Chatin käynnistäminen ei onnistunut.',
                chatStarted: 'Chat on käynnistynyt.',
              },
              no: {
                openingHours: 'Åpningstider: {{hours}}',
                queueSituation: 'Beregnet køtid: {{eqt}} minutt(er).',
                closed: 'Lukket',
                getOpeningHoursError: 'Kan ikke hente åpningstider',
                getQueueSituationError: 'Kan ikke hente køtider',
                chatCannotStart: 'Kan ikke starte chatten.',
                chatStarted: 'Chatten har startet.',
              },
              da: {
                openingHours: 'Åbningstider: {{hours}}',
                queueSituation: 'Anslået køtid: {{eqt}} minutte/r.',
                closed: 'Lukket',
                getOpeningHoursError: 'Teknisk fejl ved hentning af åbningstider',
                getQueueSituationError: 'Teknisk fejl ved hentning af køinformation',
                chatCannotStart: 'Chatten kunne ikke startes.',
                chatStarted: 'Chatten er startet.',
              },
              de: {
                openingHours: 'Öffnungszeiten: {{hours}}',
                queueSituation: 'Geschätzte Queue-Zeit: {{eqt}} Minute/n.',
                closed: 'Geschlossen',
                getOpeningHoursError: 'Technischer Fehler beim Abrufen der Öffnungszeiten',
                getQueueSituationError: 'Technischer Fehler beim Abrufen der Queue-Zeiten',
                chatCannotStart: 'Der Chat konnte nicht gestartet werden.',
                chatStarted: 'Der Chat hat begonnen.',
              },
            },
            chatConversation: {
              sv: {
                chatStarting: 'Chatten startas…',
                chatHeader: 'Chatt',
                chatHeaderClosed: 'Chatten är avslutad',
                quitTooltip: 'Avsluta chatten',
                emailSent: 'Chattkonversation kommer skickas till {{emailAddress}}',
                emailError: 'Det gick inte att skicka e-post till dig.',
                errorMessage: 'Något blev fel',
                inputPlaceholder: 'Skriv ditt meddelande här…',
                emailPrompt: 'Du kan få chatten skickad till dig',
                emailLabel: 'Din e-postadress',
                emailPlaceholder: 'E-postadress',
                emailSkip: 'Nej tack',
                emailSubmit: 'Skicka',
                quitChat: 'Avsluta chatten',
                quitChatConfirm: 'Är du säker på att du vill avsluta chatten?',
                quitChatYes: 'Ja',
                quitChatNo: 'Nej',
                videoHeader: 'Video- och delningsmöte',
                videoAccept: 'Acceptera',
                videoDecline: 'Neka',
                videoWasAccepted: 'Möte accepterades',
                videoWasDeclined: 'Möte nekades',
                videoLoadingMessage: 'Laddar möte…',
                videoHelpText:
                  'Om möte inte startar, tryck på knappen nedan för att byta till text',
                videoShowTextChat: 'Visa textchatten',
                chatDisconnected:
                  'Anslutningsproblem. Meddelanden kan bli försenade. Försöker återansluta ...',
                chatReconnected: 'Anslutning återställd.',
                videoMeetingHeader: 'Videomöte',
                sharingMeetingHeader: 'Delningsmöte',
                videoAndSharingMeetingHeader: 'Video- och delningsmöte',
              },
              en: {
                chatStarting: 'Chat is starting…',
                chatHeader: 'Chat',
                chatHeaderClosed: 'Chat is ended',
                quitTooltip: 'End chat',
                emailSent: 'Chat conversation will be mailed to {{emailAddress}}',
                emailError: 'Could not send email.',
                errorMessage: 'Something went wrong',
                inputPlaceholder: 'Write message here…',
                emailPrompt: 'Send chat conversation',
                emailLabel: 'Your email address',
                emailPlaceholder: 'Email address',
                emailSkip: 'No',
                emailSubmit: 'Send',
                quitChat: 'End chat',
                quitChatConfirm: 'Are you sure you want to end chat?',
                quitChatYes: 'Yes',
                quitChatNo: 'No',
                videoHeader: 'Video and sharing meeting',
                videoAccept: 'Accept',
                videoDecline: 'Decline',
                videoWasAccepted: 'Meeting accepted',
                videoWasDeclined: 'Meeting declined',
                videoLoadingMessage: 'Loading meeting…',
                videoHelpText:
                  'If meeting does not start, click button below to switch to text chat',
                videoShowTextChat: 'Show text chat',
                chatDisconnected:
                  'Connection issues. Messages might be delayed. Attempting to reconnect ...',
                chatReconnected: 'Connection restored.',
                videoMeetingHeader: 'Video meeting',
                sharingMeetingHeader: 'Sharing meeting',
                videoAndSharingMeetingHeader: 'Video and sharing meeting',
              },
              fi: {
                chatStarting: 'Chat käynnistyy...',
                chatHeader: 'Chat',
                chatHeaderClosed: 'Chat on päättynyt',
                quitTooltip: 'Lopeta chat',
                emailSent: 'Chat-keskustelu lähetetään sähköpostiosoitteeseen {{emailAddress}}',
                emailError: 'Sähköpostiviestin lähettäminen ei onnistunut.',
                errorMessage: 'Tapahtui jokin virhe',
                inputPlaceholder: 'Kirjoita viesti tähän…',
                emailPrompt: 'Lähetä chat-keskustelu',
                emailLabel: 'Sähköpostiosoitteesi',
                emailPlaceholder: 'Sähköpostiosoite',
                emailSkip: 'No',
                emailSubmit: 'Lähetä',
                quitChat: 'Lopeta chat',
                quitChatConfirm: 'Haluatko varmasti lopettaa chatin?',
                quitChatYes: 'Kyllä',
                quitChatNo: 'Ei',
                videoHeader: 'Videokokous jakotoiminnallisuuksilla',
                videoAccept: 'Hyväksy',
                videoDecline: 'Hylkää',
                videoWasAccepted: 'Kokous hyväksytty',
                videoWasDeclined: 'Kokous hylätty',
                videoLoadingMessage: 'Ladataan kokous…',
                videoHelpText:
                  'Jos video ei käynnisty, vaihda tekstichatiin napsauttamalla alla olevaa painiketta',
                videoShowTextChat: 'Näytä tekstichat',
                chatDisconnected:
                  'Connection issues. Messages might be delayed. Attempting to reconnect ...',
                chatReconnected: 'Connection restored.',
                videoMeetingHeader: 'Videokokous',
                sharingMeetingHeader: 'Kokous jakotoiminnallisuuksilla',
                videoAndSharingMeetingHeader: 'Videokokous jakotoiminnallisuuksilla',
              },
              no: {
                chatStarting: 'Chatten startes …',
                chatHeader: 'Chat',
                chatHeaderClosed: 'Chatten er avsluttet',
                quitTooltip: 'Avslutt chatten',
                emailSent: 'Chatsamtalen sendes på e-post til {{emailAddress}}',
                emailError: 'Kunne ikke sende e-post.',
                errorMessage: 'Noe gikk galt',
                inputPlaceholder: 'Skriv meldingen din her ...',
                emailPrompt: 'Send chatsamtalen',
                emailLabel: 'Din e-postadresse',
                emailPlaceholder: 'E-postadresse',
                emailSkip: 'Nei',
                emailSubmit: 'Send',
                quitChat: 'Avslutt chatten',
                quitChatConfirm: 'Er du sikker du vil avslutte chatten?',
                quitChatYes: 'Ja',
                quitChatNo: 'Nei',
                videoHeader: 'Video- og delingsmøte',
                videoAccept: 'Godta',
                videoDecline: 'Avvis',
                videoWasAccepted: 'Møte godtatt',
                videoWasDeclined: 'Møte avvist',
                videoLoadingMessage: 'Laster inn møte...',
                videoHelpText:
                  'Hvis møtet ikke startes, klikker du på knappen nedenfor og bytter til tekstchat',
                videoShowTextChat: 'Vis tekstchatten',
                chatDisconnected:
                  'Connection issues. Messages might be delayed. Attempting to reconnect ...',
                chatReconnected: 'Connection restored.',
                videoMeetingHeader: 'Videomøte',
                sharingMeetingHeader: 'Delingsmøte',
                videoAndSharingMeetingHeader: 'Video- og delingsmøte',
              },
              da: {
                chatStarting: 'Chatten starter…',
                chatHeader: 'Chat',
                chatHeaderClosed: 'Chatten er afsluttet',
                quitTooltip: 'Afslut chat',
                emailSent: 'Chat-samtalen sendes på e-mail til {{emailAddress}}',
                emailError: 'Kunne ikke sende e-mail.',
                errorMessage: 'Der gik noget galt',
                inputPlaceholder: 'Skriv en meddelelse her...',
                emailPrompt: 'Send chat-samtale',
                emailLabel: 'Din e-mail-adresse',
                emailPlaceholder: 'E-mail-adresse',
                emailSkip: 'Nej',
                emailSubmit: 'Send',
                quitChat: 'Afslut chat',
                quitChatConfirm: 'Er du sikker på, at du vil afslutte chatten?',
                quitChatYes: 'Ja',
                quitChatNo: 'Nej',
                videoHeader: 'Video- og delingsmøde',
                videoAccept: 'Accepter',
                videoDecline: 'Afvis',
                videoWasAccepted: 'Møde accepteret',
                videoWasDeclined: 'Møde afvist',
                videoLoadingMessage: 'Indlæser møde...',
                videoHelpText:
                  'Hvis mødet ikke starter, kan du klikke på knappen nedenfor for at skifte til tekstchat',
                videoShowTextChat: 'Vis tekstchat',
                chatDisconnected:
                  'Connection issues. Messages might be delayed. Attempting to reconnect ...',
                chatReconnected: 'Connection restored.',
                videoMeetingHeader: 'Videomøde',
                sharingMeetingHeader: 'Delingsmøde',
                videoAndSharingMeetingHeader: 'Video- og delingsmøde',
              },
              de: {
                chatStarting: 'Der Chat beginnt…',
                chatHeader: 'Chat',
                chatHeaderClosed: 'Der Chat ist beendet',
                quitTooltip: 'Chat beenden',
                emailSent: 'Das Chat-Gespräch wird gemailt an {{emailAddress}}',
                emailError: 'E-Mail konnte nicht gesendet werden.',
                errorMessage: 'Etwas ist schiefgelaufen',
                inputPlaceholder: 'Hier Nachricht schreiben...',
                emailPrompt: 'Chat-Gespräch senden',
                emailLabel: 'Ihre E-Mail-Adresse',
                emailPlaceholder: 'E-Mail-Adresse',
                emailSkip: 'Nein',
                emailSubmit: 'Senden',
                quitChat: 'Chat beenden',
                quitChatConfirm: 'Sind Sie sicher, dass Sie den Chat beenden möchten Chat?',
                quitChatYes: 'Ja',
                quitChatNo: 'Nein',
                videoHeader: 'Video- und Freigabetreffen',
                videoAccept: 'Akzeptieren',
                videoDecline: 'Ablehnen',
                videoWasAccepted: 'Treffen akzeptiert',
                videoWasDeclined: 'Treffen abgelehnt',
                videoLoadingMessage: 'Treffen wird geladen...',
                videoHelpText:
                  'Wenn die treffen nicht startet, klicken Sie auf die Schaltfläche unten, um zum Text-Chat zu wechseln',
                videoShowTextChat: 'Text-Chat anzeigen',
                chatDisconnected:
                  'Connection issues. Messages might be delayed. Attempting to reconnect ...',
                chatReconnected: 'Connection restored.',
                videoMeetingHeader: 'Video treffen',
                sharingMeetingHeader: 'Freigabetreffen',
                videoAndSharingMeetingHeader: 'Video- und Freigabetreffen',
              },
            },
          },
        },
      ],
    },
  },

  /* ***************************************
   * COBROWSING
   *************************************** */

  coBrowsing: {
    conf: {
      // List of available cobrowsing engines as seen by the web site visitors.
      cobEngineVisitorList: [{ host: 'cobe.domain.ex' }],
      // List of available cobrowsing engines as seen by the agents.
      cobEngineAgentList: [{ host: 'cobe.domain.ex' }],

      // The TCP port number that web site visitors shall use
      // when connecting to the cobrowsing engines.
      cobVisitorSSLPort: 443,

      // The TCP port number that agents shall use when connecting to the cobrowsing engines.
      cobAgentSSLPort: 444,

      // Default time-out for microservices to cobrowsing engines, milliseconds.
      ajaxTimeout: 10000,

      // Lifetime for cobrowsing session cookies, minutes.
      sessionTime: 120,

      // List of elements to specifically transfer the computed style for.
      // For instance used to transfer styles triggered by a hover event.
      hoverElements: [],

      // The domFilter applies a jQuery selector in the DOM of the mirrored content at the agent,
      // applies additional style to the selected elements, and replaces their html content.
      // This can be used to hide (but still mark position of) e.g. the ACE Reference Chat Client or
      // elements with active content that not display correctly in the agent view.
      //
      // Syntax (example showing how to filter out ACE Reference Chat Client):
      domFilter: [
        {
          query: '.cg-chat-window',
          css: {
            border: '1px dashed #fe9b00',
            background: '#fe9b00',
            opacity: '0.5',
            'font-size': 'large',
          },
          html: 'CallGuide Chat',
        },
      ],

      // If only a certain part of the web site shall allow cobrowsing, set this array of regexp.
      // includedPages: ['.*'],

      // On excluded pages (regexp), the cobrowsing functionality is completely disabled.
      // This overrides includedPages.
      excludedPages: ['chatClient.html', 'chatStandalone.html', 'chatRequest.html'],

      // Prevent or allow agents from sending clicks to visitor browser.
      // Note: A page or an input element can also control if clicks are executed,
      // by using the attribute data-cob-AgentClick='true'|'false'.
      AgentClick: false,

      // Prevent or allow agents from editing inputs in the web page.
      // 'true' means agents can edit, as default
      // 'false' means agents cannot edit and will not see the visitor's input, as default
      // 'read' means agents cannot edit, but can read the visitor's input, as default
      // Note: An element or a page can override the default setting, by setting the attribute
      // data-cob-AgentEdit to any of the three values.
      AgentEdit: 'read',
    },
  },

  /* ***************************************
   * PROACTIVE WEB
   *************************************** */

  proactiveWeb: {
    conf: {
      // Name of the proactive web engine instance to use
      instance: 'instanceTemplate',

      // URL for the proactive web engine server to use
      baseUrl: 'https://pwe.domain.ex/qualify',

      // Default timeout for requests to the proactive web engine
      ajaxTimeout: 30000, // milliseconds

      /*
      automaticOffers: true,
      templates: {
        Chat: 'pwTemplate_chat.mustache',
        Cb: 'pwTemplate_cb.mustache',
        ChatAndCb: 'pwTemplate_chatAndCb.mustache',
        Custom: 'pwTemplate_custom.mustache',
        CustomNoEntrance: 'pwTemplate_customNoEntrance.mustache',
      },
      */
    },
  },

  /* ***************************************
   * CHAT
   *************************************** */

  chat: {
    conf: {
      // Name of Chat Engine instance to use (NOT the Web SDK instance!)
      instance: 'instanceTemplate',

      // URL for the chat engine server to use
      baseUrl: 'https://chat.domain.ex/',

      // Default timeout for requests to the chat engine, milliseconds
      ajaxTimeout: 20000,

      // Preferred clientID. If the page use more than one chat client, which one shall be used when
      // a chat is started by Proactive Web, for instance.
      preferredClientID: 'ACEReferenceChatClient',

      // ACE Reference Chat Client Configuration
      aceChatClientConfig: 'ACEChatConfig_sv.js',

      video: {
        // Onsite video do not have any configuration here.
      },

      survey: {
        // Only links to these hosts are allowed for a Survey in chat client.
        // All other links will be shown as text links.
        // Rules for hosts:
        //   - Host should be text (and not regular expressions)
        //   - Only protocol ('https://') and host ('www.host.com/') part of an URL should be configured
        //   - For safety reasons, Web SDK will add a trailing slash ('/') to host if it is missing
        // Examples: 'https://host.com', 'http://host.com:80/', 'https://152.130.22.11/'
        validHosts: [
          'https://survey.labbn.se/', // Internal Telia test server!
          'https://survey.ccs.teliasonera.com/',
          'https://survey-dn.ace.teliacompany.com',
          'https://survey-dn.callguide.telia.com/',
          'https://survey.callguide.telia.com/',
          'https://survey.ace.teliacompany.com/',
        ],
      },

      knowledgeGuide: {
        // Only links to these hosts are allowed for Knowledge Guide links in chat client.
        // All other links will be shown as text links.
        // Rules for hosts:
        //   - Host should be text (and not regular expressions)
        //   - Only protocol ('https://') and host ('www.host.com/') part of an URL should be configured
        //   - For safety reasons, Web SDK will add a trailing slash ('/') to host if it is missing
        // Examples: 'https://host.com', 'http://host.com:80/', 'https://152.130.22.11/'
        validHosts: ['https://{tenant}.humany.net/'],
      },
    },
  },

  /* ***************************************
   * INSTANCE SPECIFIC CSS and JS
   *************************************** */

  // Customizations of ACE Web SDK can be made by adding instance specific files. These files has
  // to be stored in the same server folder as the instance itself.

  // NOTE: Inclusion of ACE Reference Chat Client files has been moved (to conf.chat and features
  // sections in this configuration file) and should not be defined here!

  instanceSpecific: {
    conf: {
      // CSS files to append at the head element
      styles: [],

      // CSS files to override default styles for ACE Chat, ACE Cobrowsing and ACE Proactive Web.
      // ACE Knowledge Plugin styles can not be overridden with this config property though!
      stylesOverride: [],

      // JavaScript files to append at the body element
      js: [],
    },
  },
};
