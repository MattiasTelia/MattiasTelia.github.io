window.CallGuide.config = {
  // In this template, wds.domain.ex, paths, and nameOfInstance are just placeholders, they have to
  // be replaced by the actual hostname and instance name from the production environment.

  // Path to customer specific instance, probably the path where this file is fetched from
  instanceLocation: 'https://wds.domain.ex/instances/#INSTANCE#/',

  // Path to ACE Web SDK configuration for this instance
  configUrl: 'https://wds.domain.ex/instances/#INSTANCE#/config_services.js',

  // Path to ACE Web SDK modules for visitor clients
  visitorLocation: 'https://wds.domain.ex/#VERSION#/visitor/js/modules/',

  // Path to ACE Web SDK agent cobrowsing client
  agentLocation: 'https://wds.domain.ex/#VERSION#/agent/',

  // Name of Web SDK instance to use (NOT the Chat Engine instance!)
  instance: 'nameOfInstance',

  // ACE Web SDK version
  version: 'x.y.z',
};
