/*! For license information please see ace-1061.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[1061],{61061:(e,l,a)=>{a.r(l),a.d(l,{default:()=>s});var t=a(31085),n=a(15428),i=a(3468),o=a(87744),r=a(27389);const s=({className:e})=>{const{languagePickerHeader:l,languages:a=[],widgetName:n,allowLanguages:i=!1}=(0,o.Bi)();return a.length&&i?(0,t.jsx)("div",{className:(0,r.JS)(e,"humany-settings"),children:a.length&&(0,t.jsx)(d,{className:"humany-language-list",header:l,items:a,renderItem:e=>(0,t.jsx)("li",{"data-language":e.code,children:(0,t.jsx)(u,{text:e.languageName,href:`/${e.widgetName}`,selected:n===e.widgetName,ariaLabel:e.languageName})},e.code)})}):null},d=(0,i.A)(o.kk)`
  ${o._R}

  > div {
    ${e=>{var l;return(0,o.jc)(e)("> h1",n.AH`
          font-size: ${null==(l=e.theme.fonts)?void 0:l.normal};
          line-height: 1.2em;
          font-weight: bold;
        `)}}
  }

  > ul > li {
    overflow: visible;
    font-size: ${e=>{var l;return null==(l=e.theme.fonts)?void 0:l.normal}};
  }
`,u=(0,i.A)(o.Yq)`
  display: inline-block;

  ${e=>{var l,a;return e.selected?n.AH`
          color: ${null==(l=e.theme.colors)?void 0:l.primary};
          font-weight: bold;
        `:n.AH`
          color: ${null==(a=e.theme.colors)?void 0:a.text};
          font-weight: 300;
        `}}

  @media (hover: hover) {
    &:hover {
      text-decoration: underline;
    }
  }
  &:focus-visible {
    ${o.x_};
  }
`}}]);