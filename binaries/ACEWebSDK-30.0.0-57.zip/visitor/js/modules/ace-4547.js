/*! For license information please see ace-4547.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[4547],{24547:(e,t,r)=>{r.r(t),r.d(t,{default:()=>S});var a=r(31085),n=r(15428),l=r(3468),i=r(87744),o=r(93922),s=r(27389),u=r(14041);const c=({inputHasFocus:e,searchContainerRef:t,showTag:r,showGuideCategory:n,position:l})=>{const{activeFilterBadges:o,deleteFilterBadgeAriaLabel:s=""}=(0,i.Bi)(),c=(0,i.wA)(),{name:h,params:f}=(0,i.PR)(),[m,p]=(0,u.useState)(!1),v=(0,u.useCallback)((e=>{const{key:t}=e;-1===["ArrowLeft","ArrowRight"].indexOf(t)&&p(!1)}),[]);(0,i.ML)("keydown",v,window),(0,i.ML)("click",v,window);const{guideCategory:y,tag:b,tooltip:x}=o||{},C=e=>{const t=e.querySelectorAll(".humany-filter-badge > a");return{badges:t,index:Array.from(t).findIndex((e=>document.activeElement===e))}},k=(0,u.useCallback)(((e,t,r)=>{e.preventDefault(),c("quick-filter:remove",{types:[t],ids:[r]})}),[c]),w=(e,r)=>{if(!t)return;const{badges:a,index:n}=C(t);if(a.length){let t=null;"left"===e?-1===n?t=a.item(a.length-1):n>0&&(t=a.item(n-1)):"right"===e&&(n===a.length-1?r&&r.focus():a.item(n+1)&&(t=a.item(n+1))),t&&(t.focus(),p(!0))}};(0,i._N)("ArrowLeft",(0,u.useCallback)((()=>{if(!t)return;const{index:r}=C(t);if(e||r>-1){const e=t.querySelector('[data-type="search"]');(e&&null!==e.selectionStart&&e.selectionStart<=0||r>-1)&&w("left",e)}}),[e,t])),(0,i._N)("ArrowRight",(0,u.useCallback)((()=>{if(!t)return;const{index:e}=C(t);if(e>-1){const r=t.querySelector('[data-type="search"]');e>-1&&w("right",r)}}),[t])),(0,i._N)("Backspace",(0,u.useCallback)((e=>{if(!t)return;let a=[];const{index:l}=C(t),i=t.querySelector('[data-type="search"]');if(l>-1)0===l?n?a=["guideCategory"]:r&&(a=["tag"]):1===l&&(a=["tag"]);else{const e=document.activeElement===i;i&&null!==i.selectionStart&&i.selectionStart<=0&&e&&(null!=o&&o.tag.length?a=["tag"]:null!=o&&o.guideCategory&&(a=["guideCategory"]))}if(a.length>0){let t;if(e.preventDefault(),a.includes("tag")){const e=null==o?void 0:o.tag.at(-1);t=null==e?void 0:e.id}c("quick-filter:remove",{types:a,ids:[t]})}}),[t,o,r,n,c]));const $=(0,u.useCallback)((e=>"guideCategory"===e&&y&&n?(0,a.jsx)(g,{text:`@${y.title}`,routeName:h,filterType:"guideCategory",handleClick:k,deleteAriaLabel:s,params:{...f,guideCategory:void 0}}):"tag"===e&&null!=b&&b.length&&r?b.map((e=>{const t=b.reduce(((t,r)=>(r.id!==e.id&&t.push(r.id),t)),[]);return(0,a.jsx)(g,{className:"humany-filter-badge",text:`#${e.title}`,routeName:h,filterType:"tag",handleClick:t=>k(t,"tag",e.id),deleteAriaLabel:s,params:{...f,tag:t}},e.id)})):null),[y,b,h,f,n,r,m,k]);return y||b?(0,a.jsxs)(d,{className:"humany-filter-badges",position:l,children:[y&&x?(0,a.jsx)(i.m_,{content:(0,a.jsx)(a.Fragment,{children:x}),sticky:!1,children:$("guideCategory")}):$("guideCategory"),b&&$("tag")]}):null},d=l.A.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;

  ${e=>{var t,r;return"inside"===e.position?n.AH`
          &:not(:first-child) {
            margin: 0 0 0 ${null==(t=e.theme.sizes)?void 0:t.normal};
          }
        `:n.AH`
          margin: ${null==(r=e.theme.sizes)?void 0:r.small} 0 0 0;
          span:first-child {
            margin-left: 0;
          }
        `}}
`,g=(0,l.A)((({text:e,className:t,filterType:r,handleClick:n,deleteAriaLabel:l="",...o})=>{const c=(0,u.useRef)(),[d,g]=(0,u.useState)(document.activeElement===c.current);return(0,a.jsxs)(i.EY,{className:(0,s.JS)(t,"humany-filter-badge",d?"humany-filter-badge-focused":""),onKeyDown:e=>{"Enter"===e.key&&n(e,r)},children:[e,(0,a.jsx)(i.N_,{...o,ref:c,tabIndex:0,onFocus:()=>{g(!0)},onBlur:()=>{g(!1)},role:"button","aria-label":l.replace("{{item}}",e),onClick:e=>n(e,r),children:(0,a.jsx)(i.s$,{size:13,symbol:{type:"Svg",content:"close"}})})]})}))`
  display: flex;
  align-items: center;
  padding: ${e=>{var t,r;return`${null==(t=e.theme.sizes)?void 0:t.small} calc(${null==(r=e.theme.sizes)?void 0:r.normal}/2) `}};
  background-color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
  border-radius: ${e=>e.theme.borderRadius};
  font-weight: 300;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
  font-style: italic;
  color: #ffffff;
  text-decoration: none;
  white-space: nowrap;

  margin: calc(${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}} / 2);

  &.humany-filter-badge-focused:focus-within {
    ${i.ns}
    background-color: transparent;

    svg {
      path {
        stroke: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
      }
    }
    a {
      outline: none;
    }
  }

  svg {
    width: 17px;
    height: 11px;
    margin: 1px 0 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
    path {
      stroke: #ffffff;
      stroke-width: 2px;
    }
    order: 1;
  }
`,h=(e,t)=>!t||!e||e.toLowerCase().indexOf(t.toLowerCase())>-1,f=(e,t)=>e.filter((e=>(e.items&&e.items.length&&(e.items=f(e.items,t)),t(e)))),m=e=>{let t=[];return e.forEach((e=>{t.push(e),Array.isArray(e.items)&&(t=t.concat(m(e.items)))})),t},p=e=>{const t=Array.from((null==e?void 0:e.getElementsByTagName("A"))||[]).filter((e=>null===e.getAttribute("disabled")));return{anchors:t,focusedIndex:t.findIndex((e=>document.activeElement===e))}},v=e=>{if(!e)return;const t=(e=>e?e.querySelector('[data-type="search"], input[type="search"]'):null)(e);t&&t.focus()},y=({filterPhrase:e,items:t,filterType:r,filterContainer:n,searchContainer:l,inputHasFocus:o})=>{const[c,d]=(0,u.useState)(t||[]),[g,y]=(0,u.useState)(null),x=(0,i.wA)(),{activeFilterBadges:C,quickFilters:w}=(0,i.Bi)(),$="object"==typeof w&&!!w.autoSelect||"boolean"==typeof w&&!!w;(0,u.useEffect)((()=>{d(((e=[],t,r)=>{if(!r)return e;const a=(0,s.Go)(e);if("tag"===t)return a.filter((e=>h(e.title,r)));const n=((e,t)=>{const r=m(e).filter((e=>h(e.title,t))).map((e=>e.id));let a=[];return r.forEach((t=>{const r=(0,s.dR)(t,e);a=a.concat(r)})),a})(a,r);return f(a,(e=>n.indexOf(e.id)>-1))})(t,r,e))}),[e,r,t]),(0,u.useEffect)((()=>{var e;if(n){const{anchors:t}=p(n),r=null==(e=t[0])?void 0:e.getAttribute("data-id");r&&y(r)}}),[c,n]);const A=(0,u.useCallback)(((e,t)=>{let r=((null==C?void 0:C.tag)||[]).map((e=>e.id));"tag"===t&&e.id&&(r=r.includes(e.id)?r.filter((t=>t!==e.id)):[...r,e.id]);const a={category:null!=C&&C.guideCategory?C.guideCategory.id:void 0,tagIds:r};"guideCategory"===t&&(a.category=e.id),x("quick-filter:add",a)}),[C,x]);return(0,i.ML)("keydown",(e=>{var t;const{key:a}=e;if(!n||"ArrowDown"!==a&&"ArrowUp"!==a&&"Enter"!==a)return;const{anchors:i,focusedIndex:s}=p(n);var u;if("Enter"!==a)o?(e.preventDefault(),"ArrowDown"===a?null==(u=i[0])||u.focus():(()=>{var e;null==(e=i[i.length-1])||e.focus()})()):s>-1&&(e.preventDefault(),"ArrowDown"===a?i.length>s+1?(()=>{var e;null==(e=i[s+1])||e.focus()})():v(l):s-1<0?v(l):(()=>{var e;null==(e=i[s-1])||e.focus()})());else if(o&&$){const e=null==(t=i[0])?void 0:t.getAttribute("data-id");e&&A({id:e},r)}}),window),(0,a.jsx)(i.YQ,{tree:c,renderEmpty:!1,ulProps:{role:"listbox"},liProps:{role:"option"},...(j=r,"guideCategory"===j?{renderItem:(t,r)=>(0,a.jsx)(k,{autoSelect:$&&o&&t.id===g,disabled:!h(t.title,e),tabIndex:h(t.title,e)?0:-1,onKeyDown:e=>{"Enter"===e.key&&A(t,j)},"data-level":r,onClick:()=>{A(t,j)},"data-id":t.id,children:(0,a.jsx)(b,{title:t.title,phrase:e,matches:h(t.title,e)})})}:{renderLi:!0,renderItem:t=>(0,a.jsx)(k,{autoSelect:$&&o&&t.id===g,onKeyDown:e=>{"Enter"===e.key&&A(t,j)},onClick:()=>{A(t,j)},"data-id":t.id,children:(0,a.jsx)(b,{symbol:"#",title:t.title,phrase:e,matches:h(t.title,e)})})})});var j},b=({title:e,phrase:t,matches:r,symbol:n=""})=>{const[l,o,s]=(()=>{if(!r||!t)return[e];const a=e.toLowerCase().indexOf(t.toLowerCase());return[e.substr(0,a),e.slice(a,a+t.length),e.substr(a+t.length)]})();return(0,a.jsxs)(i.EY,{children:[n,l,o?(0,a.jsx)("strong",{children:o}):null,s||null]})},x=n.AH`
  opacity: 0.5;
  pointer-events: none;
`,C=e=>{var t,r;return n.AH`
  background-color: ${null==(t=e.theme.colors)?void 0:t.text};
  color: #ffffff;
  outline: none;

  span:first-child {
    border-color: ${null==(r=e.theme.colors)?void 0:r.text};
  }
`},k=(0,l.A)(i.N_)`
  display: block;
  text-decoration: none;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};

  ${e=>e.disabled&&x}
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  background-color: transparent;

  span {
    display: block;
    ${e=>{var t,r,a,n;return e["data-level"]?`padding: calc(${null==(t=e.theme.sizes)?void 0:t.normal} / 2) ${null==(r=e.theme.sizes)?void 0:r.normal};`:`padding: calc(${null==(a=e.theme.sizes)?void 0:a.normal} / 2) ${null==(n=e.theme.sizes)?void 0:n.medium};  `}}
    ${e=>e["data-level"]&&"border-left: 2px solid"}
  }

  span:first-child {
    border-color: #e7e7e7;
  }

  ${e=>{var t;return e["data-level"]&&`padding: 0 calc(${null==(t=e.theme.sizes)?void 0:t.medium} * ${e["data-level"]});`}}

  ${e=>e.autoSelect&&C}

  &:hover,
  &:focus {
    ${C}
  }
`,w=({phrase:e="",inputHasFocus:t,searchContainerRef:r})=>{const{quickFilter:n={open:!1,loading:!1,symbol:"",type:"",items:[]},activeFilterBadges:l,noMatchesLabel:o="No matching items"}=(0,i.Bi)(),[c,d]=(0,i.Ll)(!0),g=(0,i.NF)(),{events:h}=g.get("$widget"),f=(0,u.useRef)(),m=(0,u.useCallback)((e=>(e&&e.addEventListener("keydown",(()=>{p(e).focusedIndex>-1&&h.subscribeOnce("router:changed",(()=>{v(r)}))}),!0),f.current=e,e)),[r]),{items:b=[],symbol:x,type:C,open:k,loading:w}=n,E=(0,u.useMemo)((()=>{const e=((null==l?void 0:l.tag)||[]).map((e=>e.id));return b.filter((t=>!e.includes(t.id)))}),[b,l]);if(!k||!x)return null;const S=e.slice(e.indexOf(x)+1);return(0,a.jsxs)($,{ref:m,"data-loading":w,className:(0,s.JS)("humany-quick-filter-dropdown",["guideCategory"===C,"humany-quick-filter-guide-categories"],["tag"===C,"humany-quick-filter-tags"]),children:[(0,a.jsx)(A,{className:"humany-quick-filter-dropdown-inner",css:c,ref:d,children:E.length>0?(0,a.jsx)(y,{filterType:C,items:E,filterPhrase:S,filterContainer:d.current,searchContainer:r,inputHasFocus:t}):(0,a.jsx)(j,{children:o})}),(0,a.jsx)(i.aH,{loading:w})]})},$=l.A.div`
  ${e=>(0,i.jo)(e)};
  position: absolute;
  top: calc(100% + ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}});
  left: 0;
  right: 0;
  z-index: 1;
  overflow: hidden;
`,A=l.A.div`
  max-height: 300px;
  overflow: auto;
  padding: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}} 0;
  ${e=>e.css}
  ul {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  li div {
    ${e=>{var t;return`margin: ${null==(t=e.theme.sizes)?void 0:t.normal} 0;`}}
  }
`,j=l.A.p`
  margin: 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
`,E=(e,t)=>{if(e&&!t||!e&&t)return!0;if(e&&t)if(Array.isArray(e)||Array.isArray(t)){if(a=t,(r=e).length!==a.length||!r.every(((e,t)=>e===a[t])))return!0}else if(e.id!==t.id)return!0;var r,a;return!1},S=({className:e,...t})=>{const{showSearchButton:r,showClearButton:n,role:l="search",autoFocus:d,placeholder:g,searchButtonLabel:h,searchButtonText:f,clearButtonLabel:m,ariaLabel:p,route:v="search",incremental:y=!0,showChildren:b=!1,quickFilter:x,quickFilters:C,filterBadges:k}=(0,i.Bi)(),{params:$}=(0,i.PR)(),[A,j]=(0,u.useState)(!1),[S,N]=(0,u.useState)($.phrase||""),[L,R]=(0,u.useState)({guideCategory:!1,tag:!1}),D=(0,i.NF)(),I=(0,i.Py)(),_=(0,i.wA)(),{position:H="inside"}="object"==typeof k?k:{};(0,u.useEffect)((()=>{const{guideCategory:e,tag:t}=$,r="object"==typeof k?!!k.guideCategory:!!k,a="object"==typeof k?!!k.tag:!!k;R({guideCategory:r&&!!e,tag:a&&!!t})}),[k,$]),(0,i.Gq)("router:changed",(()=>{if(x){const{open:e,symbol:t}=x;if(e){if(t){const e=S.replace(S.slice(S.indexOf(t)),"");N(e)}_("quick-filter:close")}}}),[x,S,N,_]);const[T,O,P]=((e,t={},r=!0)=>{const a=(0,i.wA)(),{quickFilters:n=!1,quickFilter:l={open:!1},activeFilterBadges:o,filterBadges:s=!1,incremental:c=600}=(0,i.Bi)(),d=(0,i.d7)(e,"boolean"==typeof c?600:c),g=(0,i.ZC)(d),h=(0,i.ZC)(o),f=(0,u.useRef)(null),m=(0,u.useCallback)(((e="")=>{var t;if(s){const r=E(null==o?void 0:o.guideCategory,null==h?void 0:h.guideCategory)||E(null==o?void 0:o.tag,null==h?void 0:h.tag);return a("search",{value:e,filtersChanged:r,filters:{tagIds:((null==o?void 0:o.tag)||[]).map((e=>e.id)),guideCategoryId:(null==(t=null==o?void 0:o.guideCategory)?void 0:t.id)||null}})}return a("search",{value:e})}),[a,o]),p=(0,u.useCallback)((e=>{a("clear",{navigateToHome:e})}),[a]),v=e=>n?e.replace(/([@#].*)/g,""):e,y=(0,u.useCallback)((t=>{if(l.open&&t.preventDefault)return void t.preventDefault();const r=document.activeElement,a=!(!f.current||"function"!=typeof f.current.contains)&&f.current.contains(r),n=v(e);"boolean"==typeof t&&t||n.length&&a||null!=o&&o.guideCategory||null!=o&&o.tag.length&&a?m(n):p(a)}),[f,e,l,p,o,m]);return(0,u.useEffect)((()=>{const e=E(null==o?void 0:o.guideCategory,null==h?void 0:h.guideCategory)||E(null==o?void 0:o.tag,null==h?void 0:h.tag),a=d&&v(d),n=g&&v(g);typeof n<"u"&&n!==a&&a!==t.phrase&&r&&!l.open&&y(e)}),[d,l.open,o,y]),(0,u.useEffect)((()=>{if(e&&n){const t="boolean"==typeof n&&!!n||"object"==typeof n&&!!n.guideCategory,r="boolean"==typeof n&&!!n||"object"==typeof n&&!!n.tag;t&&e.indexOf("@")===e.length-1&&a("quick-filter:open",{type:"guideCategory",symbol:"@"}),r&&e.indexOf("#")===e.length-1&&a("quick-filter:open",{type:"tag",symbol:"#"})}l.open&&-1===e.indexOf("@")&&-1===e.indexOf("#")&&a("quick-filter:close")}),[e]),[y,p,f]})(S,$,!!y);(0,u.useEffect)((()=>{N($.phrase||"")}),[$.phrase]);const M=(0,u.useCallback)((e=>{N(e)}),[N]),G=(0,u.useCallback)((()=>{_("quick-filter:close").then((()=>O(!0)))}),[_,O]),K=(0,u.useCallback)((()=>{var e,t;d&&!A&&(null==(t=null==(e=P.current)?void 0:e.getElementsByTagName("input")[0])||t.focus())}),[d,A,P]),J=(0,u.useCallback)((()=>{D.getAsync("router").then((e=>{const t=e.getInitialRoute(),r=e.getRouteData();(null==t?void 0:t.name)===r.name&&(null==t?void 0:t.name)!==v?N(""):O(!0)}))}),[D,N,O]),Y=e=>e!==H?null:L.guideCategory||L.tag?(0,a.jsx)(c,{position:e,inputHasFocus:A,showGuideCategory:L.guideCategory,showTag:L.tag,searchContainerRef:P.current}):void 0;(0,i.KW)(K);const X=n&&(L.guideCategory||L.tag||S),Z=C?(0,i.v7)({role:"combobox","aria-autocomplete":"list",autoComplete:"off","aria-haspopup":"listbox"}):{};return(0,a.jsxs)(z,{...t,ref:P,role:l,className:(0,s.JS)(e,"humany-search"),"data-has-phrase":!!S,"data-has-focus":A,"data-has-search-symbol":r?"true":"false",children:[(0,a.jsxs)(F,{action:".",onSubmit:e=>{var t,r;e.preventDefault(),null==(r=null==(t=P.current)?void 0:t.getElementsByTagName("input")[0])||r.blur()},"data-has-focus":A,children:[r&&(0,a.jsxs)(q,{"aria-label":h,type:"submit",title:h,disabled:!S,onClick:T,"data-has-phrase":!!S,"data-has-focus":A,children:[(0,a.jsx)(i.s$,{size:32,symbol:{type:"Svg",content:"search"}}),f]}),Y("inside"),(0,a.jsx)(i.pd,{crossOrigin:void 0,type:"search","aria-label":p,...Z,placeholder:L.guideCategory||L.tag?"":g,onFocusChange:j,onEscape:G,onEnter:T,onChange:M,value:S}),X&&(0,a.jsx)(B,{"aria-label":m,type:"reset",hasFocus:A,title:m,onClick:J,children:(0,a.jsx)(i.s$,{size:27,symbol:{type:"Svg",content:"clear"}})}),b&&!X&&I.map((e=>(0,a.jsx)(o.uA,{id:e.id,branch:"default"},e.id))),(0,a.jsx)(w,{inputHasFocus:A,phrase:S,searchContainerRef:P.current})]}),Y("below")]})},z=l.A.div`
  ${i.jo};
  width: 100%;
  padding: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.large}};

  input {
    background-color: transparent;
    border: none;
    outline: none;
    min-width: 25%;
    flex: 1;
    font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
    font-weight: 300;
    font-style: italic;
    padding: 1em 0;
    color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
    -webkit-appearance: none;

    ${e=>{var t;return"true"===e["data-has-search-symbol"]&&`text-indent: ${null==(t=e.theme.sizes)?void 0:t.normal};`}}

    ::placeholder {
      color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
    }
    /* removes the 'X' from IE */
    &[type='search']::-ms-clear {
      display: none;
      width: 0;
      height: 0;
    }
    &[type='search']::-ms-reveal {
      display: none;
      width: 0;
      height: 0;
    }

    /* removes the 'X' from Chrome */
    &[type='search']::-webkit-search-decoration,
    &[type='search']::-webkit-search-cancel-button,
    &[type='search']::-webkit-search-results-button,
    &[type='search']::-webkit-search-results-decoration {
      display: none;
    }

    &:focus {
      outline: none;
    }
  }

  button {
    background: transparent;
    border: none;
    padding: 0;
    display: inline-flex;
    align-items: center;
    font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.large}};
    transition: color 200ms ease-out;
    color: ${e=>{var t;return e["data-has-focus"]||e["data-has-phrase"]?null==(t=e.theme.colors)?void 0:t.primary:"#000000"}};
    cursor: pointer;
    > svg {
      height: 100%;
    }
  }
`,F=l.A.form`
  display: flex;
  flex-wrap: nowrap;
  align-items: center;
  border: ${e=>e.theme.inputBorder};
  border-radius: ${e=>e.theme.borderRadius};
  background-color: #ffffff;
  position: relative;
  padding: 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};

  ${e=>{var t,r;return e["data-has-focus"]&&n.AH`
      ${null!=(t=e.theme.accessibility)&&t.isTabbing?(0,i.ns)(e):`\n        border-color: ${null==(r=e.theme.colors)?void 0:r.primary};\n        outline: none;\n        input {\n          outline: none;\n        }\n      `}
    `}};
`,q=(0,l.A)(i.$n)`
  padding: 0;
  height: 2em;

  svg {
    circle,
    line {
      stroke: ${e=>{var t;return e["data-has-focus"]?null==(t=e.theme.colors)?void 0:t.primary:"#000000"}};
    }
  }
`,B=(0,l.A)(i.$n)`
  &:focus-visible svg {
    ${i.ns}
  }

  svg {
    vertical-align: top;

    circle,
    line,
    path {
      stroke: ${e=>{var t,r;return e.hasFocus?null==(t=e.theme.colors)?void 0:t.primary:null==(r=e.theme.colors)?void 0:r.text}};
    }
  }
`}}]);