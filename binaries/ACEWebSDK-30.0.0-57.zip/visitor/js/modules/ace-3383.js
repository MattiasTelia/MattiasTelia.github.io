/*! For license information please see ace-3383.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[3383],{23383:(e,t,l)=>{l.r(t),l.d(t,{default:()=>c});var r=l(31085),a=l(15428),s=l(3468),i=l(75866),o=l(87744),n=l(27389);const d=(e,t,l)=>e&&l?(0,r.jsx)(v,{symbol:l,size:18}):t?(0,r.jsx)(v,{symbol:t,size:18}):null,c=({className:e,...t})=>{const{route:l="search",items:a=[],header:s,loading:c=!1,style:v="badge",showMatchCount:$=!1,showIcons:b=!1,static:x=!1,fallbackOnInitialRoute:f=!1,itemAriaLabel:y}=(0,o.Bi)(),w=(0,o.NF)(),{params:A}=(0,o.PR)();if(!a.length&&(!c||x))return(0,o.Xn)(w,{...t,className:(0,n.JS)(e,"humany-tag-list")});const k="badge"===v?m:h;return(0,r.jsx)(u,{...t,"data-loading":!x&&c,className:(0,n.JS)(e,"humany-tag-list"),header:!x&&c?"":s,items:a,type:v,renderItem:e=>{const{id:t,title:a,defaultIcon:s,activeIcon:o,matches:n}=e,c=(A.tag?A.tag.split(","):[]).includes(e.id)||!A.tag&&"0"===e.id,u=y&&y.replace("{{title}}",a).replace("{{matches}}",`${n}`);return(0,r.jsx)(g,{notAllowed:(x&&!n&&"pill"===v).toString(),"data-tag":t,children:(0,r.jsxs)(k,{...(0,i.Cr)(e,l,f,"tag"),role:"button","aria-pressed":c,"aria-label":u,disabled:x&&!n,selected:c,text:a,children:[b&&d(c,s,o),$&&(0,r.jsx)(p,{children:`(${n})`})]})},t)},children:!x&&(0,r.jsx)(o.aH,{loading:c})})},u=(0,s.A)(o.kk)`
  ${o.jo}
  ${o._R}
  ${o.MH}
  justify-content: flex-start;
  padding: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.large}};
  ul {
    display: flex;
    flex-wrap: wrap;
    ${e=>"pill"===e.type&&a.AH`
        justify-content: center;
      `}

    li {
      margin: 0 ${e=>{var t,l;return`${null==(t=e.theme.sizes)?void 0:t.small} ${null==(l=e.theme.sizes)?void 0:l.small}`}} 0;
    }
  }
`,m=(0,s.A)(o.Yq)`
  padding: 8px 15px;
  background-color: ${e=>{var t,l;return e.selected?null==(t=e.theme.colors)?void 0:t.text:null==(l=e.theme.colors)?void 0:l.primary}};
  border-radius: ${e=>e.theme.borderRadius};
  font-weight: 300;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
  display: flex;
  align-items: center;
  color: #ffffff;

  &:focus-visible {
    ${o.ns}
    padding: 6px 15px;
    background-color: transparent;
  }

  @media (hover: hover) {
    &:hover {
      background-color: ${e=>{var t,l;return e.selected?null==(t=e.theme.colors)?void 0:t.primary:null==(l=e.theme.colors)?void 0:l.text}};
    }
  }
`,h=(0,s.A)(o.Yq)`
  border: 1px solid
    ${e=>{var t;return e.selected?null==(t=e.theme.colors)?void 0:t.text:"transparent"}};
  line-height: 2em;
  border-radius: 1em;
  padding: 0 0.5em;
  display: flex;
  align-items: center;
  font-weight: ${e=>e.selected?"normal":300};
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};

  &:disabled {
    color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.textLight}};
  }

  &:focus-visible {
    ${o.ns}
    border-radius: 1em;
  }

  @media (hover: hover) {
    &:hover {
      border: 1px solid ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
    }
  }

  ${e=>e.disabled&&a.AH`
      opacity: 0.5;
    `}
`,p=(0,s.A)(o.EY)`
  order: 2;
  margin-left: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
`,v=(0,s.A)(o.s$)`
  margin-right: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}};
  ${e=>"Uri"===e.symbol.type?`\n        width: ${e.size}px;\n        height: ${e.size}px;\n      `:"FontAwesome"===e.symbol.type?`\n        font-size: ${e.size}px;\n      `:void 0}
`,g=s.A.li`
  ${e=>"true"===e.notAllowed&&a.AH`
      cursor: not-allowed;
    `}
`}}]);