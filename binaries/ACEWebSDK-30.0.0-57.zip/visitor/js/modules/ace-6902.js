/*! For license information please see ace-6902.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[6902],{56902:(e,i,t)=>{t.r(i),t.d(i,{default:()=>m});var s=t(31085),a=t(3468),d=t(87744),o=t(27389),l=t(14041),n=t(82694);const m=({id:e,header:i,items:t,symbol:a,className:d,...n})=>{const m=(0,l.useMemo)((()=>({id:e,title:i,symbol:a,defaultHeaderOptions:{visible:!0},notifications:t.map((e=>({id:e.id.toString(),title:e.title,body:e.body,modified:e.modified,expandable:!0})))})),[i,t]);return m?(0,s.jsx)(r,{className:(0,o.JS)("humany-bot-notification-list",d),showHeader:!0,notificationList:m,loading:!1,...n}):null},r=(0,a.A)(d.qb)`
  ${n.m}
  min-width: 10em;

  span {
    color: ${e=>{var i;return null==(i=e.theme.colors)?void 0:i.text}};
  }
`},82694:(e,i,t)=>{t.d(i,{m:()=>a});var s=t(15428);const a=e=>{var i,t;return s.AH`
  margin: ${null==(i=e.theme.sizes)?void 0:i.medium} 0;
  padding: 0 ${null==(t=e.theme.sizes)?void 0:t.medium};
`}}}]);