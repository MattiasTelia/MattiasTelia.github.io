/*! For license information please see ace-7974.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[7974],{47974:(e,t,a)=>{a.r(t),a.d(t,{default:()=>C});var i=a(31085),r=a(87744),l=a(27389),n=a(14041),d=a(75866),s=a(15428),o=a(3468);const c=(0,o.A)(r.B8)`
  ${r.p_}
  ul {
    display: none;
  }

  a {
    padding: ${e=>{var t,a,i;return`${null==(t=e.theme.sizes)?void 0:t.medium} ${null==(a=e.theme.sizes)?void 0:a.medium} ${null==(i=e.theme.sizes)?void 0:i.medium} ${25*e["data-level"]+25}px`}};
  }
`,m=(0,o.A)(r.N_)`
  display: flex;
  align-items: center;
  padding: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}};
  position: relative;

  i,
  span {
    color: ${e=>{var t,a;return e.selected?null==(t=e.theme.colors)?void 0:t.primary:null==(a=e.theme.colors)?void 0:a.text}};
  }
  span {
    ${e=>e.selected&&"font-weight: bold;"}
  }
  span:not(:last-child) {
    margin: 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}} 0 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  &:focus-visible {
    ${r.ns};
  }

  @media (hover: hover) {
    &:hover {
      background-color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.accent}};
    }
  }
`,u=(0,o.A)(r.s$)`
  margin-right: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}};
`,h=(0,o.A)(u)`
  margin-right: 0;

  line {
    stroke: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
  }
`,g=(0,o.A)(r.D7)`
  max-width: 70%;
`,p=(0,o.A)(r.D7)`
  flex-shrink: 0;
`,v=o.A.div`
  flex: 1;
  text-align: right;
  button {
    padding: ${e=>{var t,a;return`${null==(t=e.theme.sizes)?void 0:t.small} ${null==(a=e.theme.sizes)?void 0:a.normal}`}};

    &:focus-visible {
      ${r.ns};
    }
  }
`,y=o.A.li`
  ${e=>{if(e["data-matches"]<=0&&"0"!==e["data-guide-category"])return s.AH`
        display: none;
      `}}

  ${e=>{if(e["data-expanded"])return(0,s.AH)({"&&":{"> ul":{display:"block"}}})}}
    &:not(:last-child) {
    border-bottom: ${e=>e.theme.border};
  }
`,b={ItemList:(0,o.A)(r.kk)`
  ${r._R}
  display:block;
  min-height: 0;
  min-width: 0;
  ${e=>e["data-loading"]&&r.jo}
  ${r.MH}

  > ul {
    ${r.jo}
    ${e=>e["data-loading"]&&"display: none;"}

    li {
      margin: 0;
      ul {
        border-top: ${e=>e.theme.border};
      }
    }
  }

  li {
    &:first-child > a {
      border-radius: ${e=>`${e.theme.borderRadius} ${e.theme.borderRadius} 0 0`};
    }

    &:last-child:not(:first-child) > a {
      border-radius: ${e=>`0 0 ${e.theme.borderRadius} ${e.theme.borderRadius}`};
    }
  }

  span {
    line-height: 2em;
    display: inline-block;
  }
  i {
    font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.large}};
    min-height: 1em;
    min-width: 1em;
    line-height: 1em;
    display: inline-block;
    vertical-align: bottom;
  }
`,Link:m,List:c,Label:g,Matches:p,ListItem:y,SymbolBadge:u,CaretContainer:v,Caret:h},$=({category:e,guideCategory:t,parent:a,caret:l,expanded:n,onClick:s,onCaretClick:o})=>{const{id:c,title:m,symbol:u,items:h,matches:g,activeSymbol:p}=e,{showMatchCount:v=!0,categoryAriaLabel:y="",activeCategoryAriaLabel:$="",route:x="search",fallbackOnInitialRoute:C=!1,caretAriaLabel:f=""}=(0,r.Bi)(),[k,j]=(0,r.tZ)(),A=(0,r.wA)(),w=(h||[]).reduce(((e,t)=>!!(t.matches&&t.matches>0)||e),!1),L=t===c&&!o,_=a&&"0"!==a.id?`${a.title} - ${m}`:m,z=`${L?$:y}${v?` (${g})`:""}`;return(0,i.jsxs)(b.Link,{onClick:s,...(0,d.Cr)(e,x,C,"category",a),className:"humany-guide-category-tree-link","aria-label":z.replace("{{category}}",_),"aria-current":L,ref:j,selected:L,children:[(L||k)&&p?(0,i.jsx)(b.SymbolBadge,{symbol:p}):u&&(0,i.jsx)(b.SymbolBadge,{symbol:u}),(0,i.jsx)(b.Label,{children:m}),v&&(0,i.jsxs)(b.Matches,{children:["(",g,")"]}),(w||o)&&l&&(0,i.jsx)(b.CaretContainer,{children:(0,i.jsx)(r.$n,{"aria-label":f.replace("{{category}}",_),"aria-expanded":n,onClick:e=>{o?o(e):(e.preventDefault(),A("expand",c))},children:(0,i.jsx)(b.Caret,{size:12,symbol:{type:"Svg",content:`caret-${l}`},"aria-hidden":"true"})})})]})},x=({categories:e,parent:t,level:a,tree:n,guideCategory:d})=>{const{expandedCategories:s=[]}=(0,r.Bi)();return(0,i.jsx)(b.List,{"data-level":a,items:e,className:(0,l.JS)("humany-guide-category-tree","humany-sub-level"),renderItem:e=>{const{id:r,matches:l,items:o,title:c}=e,m=s.indexOf(r)>-1;return(0,i.jsxs)(b.ListItem,{"data-matches":l||0,"data-guide-category":r,"data-expanded":m,"aria-expanded":m,children:[(0,i.jsx)($,{category:e,guideCategory:d,parent:t,expanded:m,caret:m?"down":"right"}),o&&!!o.length&&(0,i.jsx)(x,{categories:o,parent:{id:r,title:c},level:a+1,guideCategory:d,tree:n})]},r)}})},C=({className:e,...t})=>{const a=(0,r.PR)(),d=(0,r.NF)(),{tree:s=[],loading:o=!1,mode:c="large"}=(0,r.Bi)(),[m,u]=(0,n.useState)(!1),{guideCategory:h}=a.params;(0,n.useEffect)((()=>{u(!1)}),[h]);const g=(0,n.useMemo)((()=>{if("compact"===c&&!m){const e=s[0];return e?[e]:[]}return s}),[c,h,m,s]);if(!g.length&&!o)return(0,r.Xn)(d,{...t,className:(0,l.JS)(e,"humany-guide-category-tree")});const p=e=>{e.preventDefault(),u(!m)};return(0,i.jsx)(b.ItemList,{...t,"data-loading":o,className:(0,l.JS)(e,"humany-guide-category-tree","humany-top-level"),items:g,renderItem:e=>{const{id:t,title:a,items:r,matches:l}=e;return(0,i.jsxs)(b.ListItem,{"data-matches":l||0,"data-guide-category":t,"data-expanded":!0,"aria-expanded":!0,children:[(0,i.jsx)($,{category:e,guideCategory:h,onCaretClick:"compact"===c?p:void 0,caret:"compact"===c?m?"up":"down":void 0,expanded:m,onClick:"compact"!==c||m?void 0:p}),r&&!!r.length&&("compact"===c&&m||"large"===c)&&(0,i.jsx)(x,{categories:r,parent:{id:t,title:a},level:0,guideCategory:h,tree:s})]},t)},children:(0,i.jsx)(r.aH,{loading:o})})}}}]);