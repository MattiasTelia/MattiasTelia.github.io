/*! For license information please see ace-1383.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[1383],{71383:(e,a,i)=>{i.r(a),i.d(a,{default:()=>b});var t=i(31085),l=i(15428),r=i(3468),o=i(87744),n=i(93922),s=i(27389),d=i(14041),c=i(27811);const u=()=>{const{sorting:e,sortingHeader:a="",sortingCloseButtonAriaLabel:i="",alphabeticAscending:l="",alphabeticDescending:r="",popularityDescending:n="",modifiedAscending:u="",modifiedDescending:b="",publishedAscending:h="",publishedDescending:v=""}=(0,o.Bi)(),k=(0,d.useMemo)((()=>[{key:"popularity",order:"descending",label:n},{key:"alphabetic",order:"ascending",label:l},{key:"alphabetic",order:"descending",label:r},{key:"modified",order:"descending",label:b},{key:"modified",order:"ascending",label:u},{key:"published",order:"ascending",label:h},{key:"published",order:"descending",label:v}]),[l,r,n,u,b,h,v]),{name:f,params:y}=(0,o.PR)();if(!e||!e.picker||"none"===e.picker)return null;const{default:x,picker:$}=e,w=(0,t.jsx)(g,{tabIndex:0,title:a,children:(0,t.jsx)(m,{symbol:{type:"Svg",content:"sorting"},size:18})}),L=({key:e,label:a,order:i})=>{const l=`${e}-${i}`;return(0,t.jsx)("li",{"data-sorting":l,children:(0,t.jsx)(p,{tabIndex:0,text:a,routeName:f,selected:y.sorting===l||!y.sorting&&l===x,"aria-label":a,params:(0,s.$6)({...y,sorting:l})})},l)};return(0,t.jsxs)("div",{className:"humany-guide-list-sorting",children:[$===c.uq.DROPDOWN&&(0,t.jsx)(o.Q5,{header:a,items:k,trigger:w,closeButtonAriaLabel:i,renderItem:L}),$===c.uq.DRAWER&&(0,t.jsx)(o.g7,{animation:{type:o.gw.SlideInBottom},header:a,items:k,trigger:w,closeButtonAriaLabel:i,renderItem:L})]})},g=(0,r.A)(o.$n)`
  &:focus-visible {
    ${o.ns}
    padding: ${e=>{var a;return null==(a=e.theme.sizes)?void 0:a.small}};
    outline-offset: -2px;
  }
`,m=(0,r.A)(o.s$)`
  stroke: ${e=>{var a;return null==(a=e.theme.colors)?void 0:a.text}};
  && {
    margin: 0;
  }
`,p=(0,r.A)(o.Yq)`
  color: ${e=>{var a,i;return e.selected?null==(a=e.theme.colors)?void 0:a.primary:null==(i=e.theme.colors)?void 0:i.text}};
  ${e=>e.selected&&"font-weight: bold;"}

  outline:none;
  &:focus-visible {
    ${o.x_}
    text-decoration: underline;
  }
`,b=({className:e,...a})=>{const i=(0,o.NF)(),{routes:l,pageSize:r=5,columns:c=null,showFavoriteToggle:g=!1,localPaging:m=!1,guides:p=[],localPageSize:b=r,loading:k,header:f,accordion:y,pagerLabel:x,sorting:$,tags:w,addFavoriteTooltip:L,removeFavoriteCancelLabel:C,removeFavoriteConfirmLabel:j,removeFavoriteHeader:A,removeFavoriteLabel:F,removeFavoriteTooltip:N,metadata:_,metadataModifiedLabel:H,metadataPublishedLabel:I,metadataByLabel:P,matchFilters:R,searchResultsEmptyLabel:B}=(0,o.Bi)(),{page:D="browse",guide:T="guide"}=l||{},z=(0,o.PR)(),{name:M,params:{phrase:S,tag:q,guideCategory:E=0,uriName:O="",take:J=r,guide:Q,sorting:W,accordion:X}}=z,Y=(0,o.Py)(),G=(0,o.wA)(),{name:K}=(0,o.wO)(),U=(0,d.useCallback)((e=>{y&&e&&(e.focus(),e.blur())}),[y]),V={guide:(0,d.useCallback)((({id:e,title:a})=>(0,s.$6)({guideCategory:E,phrase:S,tag:q,sorting:W,take:m?void 0:+J,guide:e,uriName:a?(0,s.J1)(a):void 0,accordion:y?K:void 0})),[E,y,S,q,J,$,W,r,m,b,K]),page:(0,d.useCallback)((()=>(0,s.$6)({phrase:S,guideCategory:E,uriName:O,tag:q,sorting:W,take:m?+b+ +r:+J+ +r})),[E,S,q,$,W,J,r,O,m,b])},Z=(0,d.useCallback)(((e,a,i,l)=>{const{id:r,title:s}=e;return y&&Q===r&&K===X?(0,t.jsx)(o.gQ,{id:r,title:s,route:T,children:Y.map((e=>(0,t.jsx)(n.uA,{ref:U,id:e.id,branch:"default",ariaLabel:s,tabIndex:0,accordion:y},e.id)))},r):l?l(e,a,i,l):null}),[y,Y,V,Q,K,X]),ee=(0,d.useCallback)(((e,a)=>{if(y)G("expand",a.id);else{const{events:e}=i.get("$widget");e.dispatch("tracking:guide-list-item-clicked",{guide:a})}}),[y,G]),ae=(0,d.useMemo)((()=>!!(null!=R&&R.search&&S||null!=R&&R.guideCategory&&E||null!=R&&R.tag&&q)),[R,S,E,q]);if(!k&&!p.length&&!ae)return(0,o.Xn)(i,{...a,className:(0,s.JS)(e,"humany-guide-list")});const ie=$&&$.picker&&"none"!==$.picker,te=(0,t.jsxs)(v,{className:"humany-paragraph",children:[(0,t.jsx)(o.o5,{variant:"h1",children:f}),(0,t.jsx)(u,{})]});return(0,t.jsx)(h,{...a,className:e,"data-loading":k,"aria-live":null!=R&&R.search?"polite":null,"data-columns":c,expandable:!!y,header:!ie&&f,customHeader:ie&&te,items:p,pageLabel:x,pageRole:D===M?"button":"link",pageCaret:D===M?"down":"right",paramMappers:V,renderItem:Z,dispatch:G,onItemClick:ee,localPaging:m,showTags:w,showFavoriteToggle:g,searchResultsEmptyLabel:B,addFavoriteTooltip:L,removeFavoriteCancelLabel:C,removeFavoriteConfirmLabel:j,removeFavoriteHeader:A,removeFavoriteLabel:F,removeFavoriteTooltip:N,metadata:{..._,modifiedLabel:H,publishedLabel:I,byLabel:P},routing:{guide:T,page:D},"data-testid":"guide-list",children:(0,t.jsx)(o.aH,{loading:k})})},h=(0,r.A)(o.tz)`
  ${o.jo}
  ${o.MH}
  position: relative;

  ${e=>{var a;return"number"==typeof e["data-columns"]&&l.AH`
      > ul {
        display: grid;
        grid-auto-flow: column;
        grid-template-columns: repeat(${e["data-columns"]}, 1fr);
        grid-template-rows: ${`repeat(${Math.ceil(e.items.length/e["data-columns"])}, auto)`};
        grid-column-gap: calc(${e.theme.gap} + (${null==(a=e.theme.sizes)?void 0:a.large} * 2));
      }
    `}}
`,v=r.A.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  overflow: hidden;

  ${e=>(0,o.jc)(e)("> h1",l.AH`
        white-space: pre-wrap;
      `)}
`}}]);