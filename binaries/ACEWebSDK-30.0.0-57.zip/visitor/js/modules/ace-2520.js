/*! For license information please see ace-2520.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[2520],{52520:(e,t,a)=>{a.r(t),a.d(t,{default:()=>h});var n=a(31085),s=a(15428),c=a(3468),m=a(87744),o=a(27389),l=a(77783);a(14041),a(91872),a(27811);const r=(0,c.A)(m.Ed)`
  ${m.Bh}

  ${e=>{var t;return(0,m.jc)(e)("h1",s.AH`
        font-weight: normal;
        font-size: ${null==(t=e.theme.fonts)?void 0:t.medium};
      `)}}
`,h=e=>{const{className:t,renderDefault:a=(()=>{}),body:{form:s},confirmation:c,htmlParseInstruction:m,disabled:h}=e;return c?(0,n.jsx)(r,{className:(0,o.JS)(t,"humany-contact-method-confirmation","humany-contact-method-email"),html:c,htmlParseInstruction:m}):s&&!h?(0,n.jsx)(l.F,{...e,className:(0,o.JS)(t,"humany-contact-method-email")}):a()}}}]);