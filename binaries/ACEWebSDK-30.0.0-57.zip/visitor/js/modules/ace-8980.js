/*! For license information please see ace-8980.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[8980],{98980:(e,t,n)=>{n.r(t),n.d(t,{default:()=>c});var i=n(31085),l=n(79867),a=n(15428),o=n(3468),r=n(87744),s=n(27389);const c=({className:e,...t})=>{const{widget:n,route:a,mode:o="large",iconSize:c="large",symbol:m,descriptionLabel:k,label:x,textAlign:$}=(0,r.Bi)(),f=(0,l.NF)(),{events:w}=f.get("$widget"),b=$||("large"===o?"center":"right"),y="large"===c?"64":"48",j={apiNotificationPriorityBy:"contacts"};if("compact"===o)return(0,i.jsxs)(d,{...t,className:(0,s.JS)(e,"humany-contact-link","humany-contact-link-compact"),onClick:()=>{w.dispatch("tracking:contact-link-clicked",{})},textAlign:b,children:[k&&(0,i.jsx)(r.EY,{children:k}),a?(0,i.jsx)(r.N_,{routeName:a,children:x}):(0,i.jsx)(r.vz,{"aria-haspopup":"dialog",role:"button",activationOptions:j,widgetName:n,children:x})]});const A=(0,i.jsxs)(i.Fragment,{children:[m?(0,i.jsx)(r.s$,{symbol:m}):(0,i.jsx)(p,{width:y,viewBox:"0 0 63 37",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,i.jsx)("path",{d:"M1 1H62M1 1L24.7579 15.6328M1 1V36M62 1V36M62 1L38.8842 15.5402M1 36H62M1 36L24.7579 15.6328M62 36L38.8842 15.5402M38.8842 15.5402L37.0898 16.6689C33.8642 18.6979 29.7658 18.7172 26.5212 16.7188L24.7579 15.6328",stroke:"#990AE3"})}),x&&(0,i.jsx)(v,{children:x}),k&&(0,i.jsx)(g,{children:k})]});return a?(0,i.jsx)(u,{...t,className:(0,s.JS)(e,"humany-contact-link","humany-contact-link-large"),onClick:()=>{w.dispatch("tracking:contact-link-clicked",{})},routeName:a,children:A}):(0,i.jsx)(h,{...t,"aria-haspopup":"dialog",role:"button",className:(0,s.JS)(e,"humany-contact-link","humany-contact-link-large"),onClick:()=>{w.dispatch("tracking:contact-link-clicked",{})},textAlign:b,widgetName:n,activationOptions:j,children:A})},d=o.A.div`
  text-align: ${e=>e.textAlign};
  font-weight: 300;

  span,
  a {
    display: inline-block;
    font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
  }

  span {
    margin: 0 ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.small}} 0 0;
  }
  a {
    text-decoration: underline;
    color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
    &:focus-visible {
      ${r.bn}
      padding: ${e=>{var t,n;return`calc(${null==(t=e.theme.sizes)?void 0:t.small} / 2) ${null==(n=e.theme.sizes)?void 0:n.small}`}};
    }
  }
`,m=e=>{var t,n,i,l;return a.AH`
  ${(0,r.jo)(e)}
  padding: ${null==(t=e.theme.sizes)?void 0:t.large};
  text-align: center;
  cursor: pointer;
  text-decoration: none;
  i {
    font-size: ${null==(n=e.theme.fonts)?void 0:n.huge};
    min-width: 1em;
    min-height: 1em;
    color: ${null==(i=e.theme.colors)?void 0:i.primary};
  }
  span {
    color: ${null==(l=e.theme.colors)?void 0:l.text};
  }
  &:focus-visible {
    ${(0,r.ns)(e)};
  }
`},h=(0,o.A)(r.vz)`
  ${m}
  text-align: ${e=>e.textAlign};
`,u=(0,o.A)(r.N_)`
  ${m}
`,g=(0,o.A)(r.EY)`
  line-height: 1.6em;
  font-weight: 300;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.normal}};
`,v=(0,o.A)(r.EY)`
  display: block;
  font-size: ${e=>{var t;return null==(t=e.theme.fonts)?void 0:t.medium}};
  margin: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}} 0;
`,p=o.A.svg`
  align-self: center;

  path {
    vector-effect: non-scaling-stroke;
    stroke: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.primary}};
  }
`}}]);