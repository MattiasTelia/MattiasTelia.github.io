/*! For license information please see ace-7929.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[7929,9182],{9182:(t,e,n)=>{n.r(e),n.d(e,{default:()=>m});var o=n(31085),a=n(3468),i=n(20499),d=n(11330),r=n(87744),c=n(91872),s=n(27389),l=n(14041),u=n(31529);n(59476),n(94701);const m=({contactMethodId:t,guideId:e,groupId:n,className:a})=>{var d,m,b,y,h;const[p,v]=(0,l.useState)(),g=(0,r.NF)(),k=(0,r.wA)(),I=(0,l.useRef)(!0),w=(0,r.LM)();(0,l.useEffect)((()=>{const{events:e}=g.get("$widget"),o=e.subscribe("bot-provider:form-submitted",(async(t,e)=>{var o;if((null==(o=e.form.meta)?void 0:o.groupId)!==n||e.id!==p.id)return;w&&(e.form.meta||(e.form.meta={}),e.form.meta.conversation=w);const a=await g.getAsync("contactMethods"),i={...p,body:{...p.body,form:e.form}},{errors:d,valid:r,errorTypes:s}=await a.validate(i);if(!r){const t=new c.ok(p.body.form);return v(void 0),t.setValidationErrors(d),i.body={...i.body,form:t.get()},void v({...i})}const l=await a.submit(i);i.confirmation=l,v(i)})),a=e.subscribe("bot-provider:evaluate",(async(e,o)=>{if(String(o.id)!==String(t))return;const a=await(await g.getAsync("contactMethods")).evaluate(p);let i={...p,body:{...p.body,form:a}};const d=(0,u.u)(i,{submit:"Skicka",errors:{},meta:{groupId:n}});i={...i,body:d},v(i)}));return()=>{o(),a()}}),[g,p,v,w]);const C=(t,e,n=null)=>{if(t["ui:component"]&&"Date"===t["ui:component"])return Object.assign(t,{"ui:bot":!0,"ui:entrance":e}),t;for(const n in t)if("object"==typeof t[n]&&null!==t[n]){const o=C(t[n],e,t);if(void 0!==o)return o}},M=(0,l.useCallback)((async t=>{const o=await(await i.DataClient.getInstance(g)).fetch(i.DataType.ContactMethod,{contactMethodId:t,guideId:e},{noCache:!0,isBot:!0}),a=(0,u.u)(o,{submit:"Skicka",errors:{},meta:{groupId:n}});if(o.body=a,o.body.guideId=e,!I.current)return null;v(o)}),[I]);return(0,l.useEffect)((()=>(M(t),()=>{I.current=!1})),[t,M]),p?("ace.callback"===p.clientName&&null!=(d=p.body)&&d.entrance&&C(p,null==(m=p.body)?void 0:m.entrance),(0,o.jsx)(f,{...p,body:{...p.body,form:p.body.form?{...p.body.form,data:null==(b=p.body.form)?void 0:b.data,layout:{...p.body.form.layout},meta:null==(y=p.body.form)?void 0:y.meta,schema:null==(h=p.body.form)?void 0:h.schema}:void 0,guideId:p.body.guideId},inline:!0,expanded:!0,dispatch:k,className:(0,s.JS)("humany-bot-contact-method",a)})):null},f=(0,a.A)(d.ContactMethod)`
  padding: ${t=>{var e;return null==(e=t.theme.sizes)?void 0:e.normal}} ${t=>{var e;return null==(e=t.theme.sizes)?void 0:e.medium}};
`},47929:(t,e,n)=>{n.r(e),n.d(e,{default:()=>s});var o=n(31085),a=n(3468),i=n(11330),d=n(87744),r=n(14041),c=n(9182);n(20499),n(91872),n(27389),n(31529),n(59476),n(94701);const s=({actions:t,entryId:e,groupId:n})=>{const a=(0,d.wA)(),i=(0,d.NF)(),[c,s]=(0,r.useState)([]),[f,b]=(0,r.useState)([]);return(0,r.useEffect)((()=>{i.getAsync("contactMethods").then((n=>{if(!n)return;const o=t.map((async t=>{var o;if(null==(o=t.data)||!o.clientName)return null;const a=await n.handleAdapters(t.data);return{...a,...t.data,description:t.data.description?t.data.description:a.description,onClick:(n,o)=>{if("function"==typeof a.onClick&&a.onClick(n,o),!n.defaultPrevented)if(o.inline&&!o.expanded)b([...f,o.id]);else{const{events:n}=i.get("$widget");n.dispatch("provider:open-contact-method",{entryId:e,contactMethod:o,actionKey:t.actionKey}),n.dispatch("tracking:contact-method-list-item-clicked",o)}}}}));Promise.all(o).then((t=>{s(t.filter((t=>!!t)))}))}))}),[t,i,e,f]),c.length?(0,o.jsx)(l,{className:"humany-bot-contact-list",contactMethods:c,dispatch:a,itemRenderer:(t,e)=>(f.includes(t.id)||t.expanded)&&t.inline||"custom.link"===t.clientName?(0,o.jsx)(u,{contactMethodId:t.id,groupId:n,guideId:t.body.guideId}):(0,o.jsx)(m,{...t,...e})}):null},l=(0,a.A)(i.ContactList)`
  > ul > li {
    a {
      display: flex;
      align-items: center;
      outline-offset: -2px;
    }

    &:not(:last-child) {
      ${t=>t.theme.border&&`border-bottom: ${t.theme.border};`}
    }
  }
`,u=(0,a.A)(c.default)`
  i {
    margin: 0 ${t=>{var e;return null==(e=t.theme.sizes)?void 0:e.medium}} 0 0;
    display: flex;
    justify-content: center;
    align-items: center;
  }
`,m=(0,a.A)(i.ContactMethod)`
  padding: ${t=>{var e;return null==(e=t.theme.sizes)?void 0:e.medium}};
  i {
    margin: 0 ${t=>{var e;return null==(e=t.theme.sizes)?void 0:e.medium}} 0 0;
    display: flex;
    justify-content: center;
    align-items: center;
  }
`}}]);