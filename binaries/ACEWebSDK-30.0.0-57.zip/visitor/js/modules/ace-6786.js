/*! For license information please see ace-6786.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[6786],{56786:(e,r,n)=>{n.r(r),n.d(r,{default:()=>g});var s=n(31085),t=n(15428),i=n(3400),l=n(93922),a=n(79867),o=n(3468);const d=({header:e="",link:r="",suggestionHeader:n="",suggestion:t=""})=>(0,s.jsxs)(u,{children:[(0,s.jsx)(c,{children:(0,s.jsx)(a.o5,{variant:"h2",children:"404"})}),(0,s.jsxs)(h,{children:[(0,s.jsx)(a.o5,{variant:"h3",children:e}),(0,s.jsx)(a.Yq,{routeName:"index","aria-label":r,text:r})]}),(0,s.jsxs)(m,{children:[(0,s.jsx)("span",{children:n}),(0,s.jsx)("ul",{children:(0,s.jsx)("li",{children:t})})]})]}),u=o.A.div`
  ${e=>(0,a.jo)(e)}
  display: flex;
  flex-wrap: wrap;
  flex-direction: row;
  justify-content: flex-start;
  padding: ${e=>{var r;return null==(r=e.theme.sizes)?void 0:r.medium}};
`,c=o.A.div`
  ${e=>{var r;return(0,a.jc)(e)("h2",t.AH`
        padding: 0;
        margin: 0;
        color: gray;
        font-size: ${null==(r=e.theme.fonts)?void 0:r.huge};
      `)}}
`,h=o.A.div`
  margin-left: ${e=>{var r;return null==(r=e.theme.sizes)?void 0:r.medium}};

  ${e=>{var r;return(0,a.jc)(e)("h3",t.AH`
        text-transform: uppercase;
        font-size: ${null==(r=e.theme.fonts)?void 0:r.normal};
      `)}}

  a {
    color: ${e=>{var r;return null==(r=e.theme.colors)?void 0:r.link}};
    font-size: ${e=>{var r;return null==(r=e.theme.fonts)?void 0:r.small}};
  }
`,m=o.A.div`
  margin-top: ${e=>{var r;return null==(r=e.theme.sizes)?void 0:r.medium}};
  min-width: 100%;

  span {
    font-weight: bold;
  }
`,g=()=>{const{header:e,linkLabel:r,suggestionHeader:n,suggestionLabel:t,showSearch:o}=(0,a.Bi)(),u=(0,a.NF)(),c=(0,i.u)();return(0,s.jsxs)(s.Fragment,{children:[o&&(0,s.jsx)(l.wE,{builder:e=>u.get("settings").then((r=>{var n;const s=Object.keys(r.components).reduce(((e,n)=>"search"===r.components[n].type?r.components[n].properties:e),{}),t=e.createNode("search",{detached:!0});return t.writeLayout({size:"full"}),t.writeProperties({"css-margin-bottom":(null==(n=null==c?void 0:c.sizes)?void 0:n.normal)||"15px",...s}),t}))}),(0,s.jsx)(d,{header:e,link:r,suggestionHeader:n,suggestion:t})]})}}}]);