/*! For license information please see ace-1810.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[1810],{11810:(e,n,t)=>{t.r(n),t.d(n,{default:()=>f});var a=t(31085),i=t(15428),s=t(3468),l=t(33296),r=t(93922),d=t(79867),o=t(27389),c=t(14041),u=t(29033);const m=(0,c.forwardRef)((({children:e,className:n,renderState:t,animation:i,...s},r)=>((0,c.useEffect)((()=>{if("open"===t){const e=document.querySelector(`[data-node-id='${s.id}']`);e&&e.focus()}})),t?(0,a.jsx)(d.zF,{mountOnEnter:t!==l.WidgetRenderState.hidden,timeout:200,in:t===l.WidgetRenderState.open,transitions:i,unmountOnExit:t===l.WidgetRenderState.closed,children:(t,i)=>(0,a.jsx)(h,{...s,tabIndex:"-1",animationCss:i,"data-state":t,ref:r,className:(0,o.JS)("humany-animated-area",n),children:e})}):null))),h=(0,s.A)(d.xA)`
  ${r.$l}
  ${e=>!!e.animationCss&&e.animationCss}
  ${e=>!!e.scrollableCss&&e.scrollableCss}
  text-size-adjust: 100%;
  input::-ms-clear {
    display: none;
  }
  :focus-visible {
    outline: none !important;
  }
  ${e=>e.hidden&&"exited"===e["data-state"]&&i.AH`
      visibility: collapse;
      pointer-events: none;
    `};
`,f=({className:e,...n})=>{const{name:t}=(0,d.wO)(),i=(0,d.Xp)(),s=(0,d.NT)(),h=(0,d.Bi)(),f=(0,d.Py)(),$=(0,d.NF)(),{gap:v="0"}=s,{columns:y=1,animation:j="none",scrollable:A=!1,mode:S=u.A.Static,trigger:w={},fullScreen:C,header:_,...N}=h,{size:k=24,symbol:z,label:R,ariaLabel:W,...E}=w,[O,P]=(0,d.Ll)(A),J=(0,c.useCallback)((e=>{const{events:n}=$.get("$widget");return n.dispatch("widget:area-rendered",{name:t,properties:h,element:e}),P.current=e,e}),[h,i]);if(!f.length)return(0,d.Xn)($,{...n,className:(0,o.JS)(e,"humany-area")});const X={...n,className:(0,o.JS)(e,"humany-area",`humany-area-${t}`),scrollableCss:O,...N,columns:y,gap:v,renderState:i,animation:j,hidden:i===l.WidgetRenderState.hidden,ref:J},D="none"!==j?(0,a.jsx)(d.gU.Provider,{value:y,children:(0,a.jsx)(m,{...X,children:f.map((e=>(0,a.jsx)(r.uA,{id:e.id,branch:"default"},e.id)))})}):i===l.WidgetRenderState.closed?null:(0,a.jsx)(d.gU.Provider,{value:y,children:(0,a.jsx)(b,{...X,children:f.map((e=>(0,a.jsx)(r.uA,{id:e.id,branch:"default"},e.id)))})});if(S===u.A.Static)return D;const F=(0,a.jsxs)(p,{className:"humany-area-trigger",title:W,...(0,d.Cg)(E),children:[R&&(0,a.jsx)(g,{children:R}),z&&(0,a.jsx)(x,{symbol:z,size:k})]});if(S===u.A.Dropdown)return(0,a.jsx)(d.ms,{trigger:F,children:D});if(S===u.A.Drawer){const e=Object.values(d.gw).includes(j)&&{type:j}||void 0;return(0,a.jsx)(d._s,{header:_,animation:e,fullScreen:C,trigger:F,children:D})}return S===u.A.Modal&&o.Vy.warn("modal area not implemented"),null},p=(0,s.A)(d.$n)`
  display: flex;
  align-items: inherit;
  align-self: center;
  width: fit-content;
  height: fit-content;
  ${d.PX}

  ${e=>e.theme.fonts&&`\n    font-family: ${e.theme.fonts.type};\n    font-size: ${e.theme.fonts.normal};\n  `}

  &:focus-visible {
    ${d.x_};
  }
`,g=(0,s.A)(d.EY)`
  margin: 0 ${e=>{var n;return null==(n=e.theme.sizes)?void 0:n.small}} 0 0;
  color: ${e=>{var n;return null==(n=e.theme.colors)?void 0:n.text}};
`,x=(0,s.A)(d.s$)`
  path {
    fill: ${e=>{var n;return null==(n=e.theme.colors)?void 0:n.text}};
  }
`,b=(0,s.A)(d.xA)`
  ${r.$l}
  ${e=>!!e.scrollableCss&&e.scrollableCss}
  text-size-adjust: 100%;
  input::-ms-clear {
    display: none;
  }
  ${e=>e.hidden&&i.AH`
      visibility: collapse;
      pointer-events: none;
    `};
`}}]);