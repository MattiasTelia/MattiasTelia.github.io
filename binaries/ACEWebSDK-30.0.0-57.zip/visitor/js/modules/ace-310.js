/*! For license information please see ace-310.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[310],{10310:(e,a,t)=>{t.r(a),t.d(a,{default:()=>u});var i=t(31085),r=t(15428),l=t(3468),d=t(87744),o=t(93922),g=t(27389),s=t(14041);const u=({className:e,...a})=>{const t=(0,d.NF)(),r=(0,d.PR)(),l=(0,d.Py)(),{pageSize:u=10,columns:m=null,routes:p,lists:h=[],loading:y=!1,accordion:b=!1}=(0,d.Bi)(),{guide:k="guide"}=p||{},{name:w,params:{phrase:$,tag:f,guideCategory:v=0,uriName:x="",take:C=u,guide:N,accordion:_}}=r,j=(0,s.useCallback)(((e,{id:a,title:t})=>(0,g.$6)({phrase:$,guideCategory:v,tag:f,take:+C,uriName:t?(0,g.J1)(t):void 0,accordion:e.toString(),guide:a})),[v,$,f,C,u]),S=(0,s.useCallback)(((e,a)=>(0,g.$6)({phrase:$,guideCategory:a,tag:f,take:0===e?+C+ +u:void 0,uriName:x,accordion:_,guide:N})),[v,$,f,C,u,x,_,N]),A=(0,s.useCallback)(((e,a,t,r)=>{const{id:g,title:s}=e;return b&&N===g?(0,i.jsx)(d.gQ,{id:g,title:s,route:k,children:l.map((e=>(0,i.jsx)(o.uA,{id:e.id,branch:"default",accordion:b},e.id)))},g):r?r(e,a,t,r):null}),[b,l,N]);return h.length||y?(0,i.jsxs)(n,{...a,className:(0,g.JS)(e,"humany-guide-category-browser"),"data-category-columns":m,"data-loading":y,children:[h.map((({id:e,guides:a,title:t,symbol:r,pager:l,paging:d},o)=>a&&a.length>0?(0,i.jsx)(c,{className:"humany-guide-category-browser-list","data-testid":"guide-list",items:a,header:t,pageLabel:d?l:void 0,pageRole:0===o?"button":"link",pageCaret:0===o?"down":"right",symbol:o>0?r:void 0,index:o,"data-category-columns":m,expandable:b,renderItem:o.toString()===_?A:void 0,paramMappers:{guide:e=>j(o,e),page:()=>S(o,e)},routing:{guide:k,page:w}},e):null)),(0,i.jsx)(d.aH,{loading:y})]}):(0,d.Xn)(t,{...a,className:(0,g.JS)(e,"humany-guide-category-browser")})},n=l.A.div`
  ${d.MH}
  display: grid;
  margin: 0 auto;
  display: grid;
  width: 100%;
  grid-template-columns: ${e=>null===e["data-category-columns"]?"repeat(2, 1fr)":`repeat(${e["data-category-columns"]}, 1fr)`};
  grid-gap: ${e=>e.theme.gap};
`,c=(0,l.A)(d.tz)`
  ${d.jo}
  overflow: auto;
  justify-content: flex-start;

  ${e=>{var a;return 0===e.index&&null===e["data-category-columns"]&&r.AH`
      grid-column: span 2;

      > a {
        margin: 0;
      }

      > ul {
        display: grid;
        grid-auto-flow: column;
        grid-template-columns: repeat(2, 1fr);
        grid-template-rows: repeat(${Math.ceil(e.items.length/2)}, auto);
        grid-column-gap: ${`calc(${e.theme.gap} + (${null==(a=e.theme.sizes)?void 0:a.large} * 2))`};
      }
    `}}
`}}]);