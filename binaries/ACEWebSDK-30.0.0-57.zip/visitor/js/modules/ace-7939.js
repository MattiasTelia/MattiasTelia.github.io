/*! For license information please see ace-7939.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[7939],{37939:(e,l,s)=>{s.r(l),s.d(l,{default:()=>n});var t=s(31085),a=s(3468),i=s(79867);const n=({className:e,...l})=>{const s=(0,i.wA)(),{ariaLabel:a=""}=(0,i.Bi)();return(0,t.jsx)(c,{...l,className:e,children:(0,t.jsx)(r,{onClick:()=>s("close"),"aria-label":a,children:(0,t.jsx)(o,{size:12,symbol:{type:"Svg",content:"close"}})})})},c=a.A.div`
  display: flex;
  justify-content: flex-end;
  align-items: flex-start;
`,r=(0,a.A)(i.$n)`
  &:focus-visible {
    ${i.ns}
    padding: ${e=>{var l,s;return`calc(${null==(l=e.theme.sizes)?void 0:l.small} / 2) ${null==(s=e.theme.sizes)?void 0:s.small}`}};
    line,
    path {
      stroke: ${e=>{var l,s;return null==(s=null==(l=e.theme.accessibility)?void 0:l.colors)?void 0:s.inactiveText}};
    }
  }
`,o=(0,a.A)(i.s$)`
  line,
  path {
    stroke: ${e=>{var l;return null==(l=e.theme.colors)?void 0:l.text}};
  }
`}}]);