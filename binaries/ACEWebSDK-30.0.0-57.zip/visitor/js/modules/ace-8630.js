/*! For license information please see ace-8630.js.LICENSE.txt */
"use strict";(self.webpackChunk_telia_ace_web_sdk=self.webpackChunk_telia_ace_web_sdk||[]).push([[8630],{48630:(e,t,i)=>{i.r(t),i.d(t,{default:()=>F});var l=i(31085),r=i(14041),o=i(3468),n=i(87744),s=i(27389),a=i(15428),d=i(75866),c=i(79867);const m=(e,t)=>{const i=e.length;if(i<=4)return i;if(i%3==0)return 3;if(i%4==0)return 4;const l=e.indexOf(t);if(5===i)return l<=2?3:2;if(7===i)return l<=3?4:3;const r=i%4;return 3===r||2===r?l+r>=i?r:4:i-l<=5?i-l>=3?3:2:4},u=({item:e,categories:t,guideCategory:i,currentRoute:o,itemMode:s,autoFocus:a=!1})=>{const{id:u,title:f,symbol:g,activeSymbol:p,description:v}=e,{route:b="browse",categoryAriaLabel:x="",direction:w="vertical",activeCategoryAriaLabel:z="",fallbackOnInitialRoute:A=!1,selectedCategoryTrail:k}=(0,n.Bi)(),j=(0,c.NF)(),{events:F}=j.get("$widget"),[H,S]=(0,n.tZ)(),T=(0,r.useCallback)((e=>{a&&e&&e.focus()}),[a]),{columns:C,type:L,description:N=!0}=s,E=i===u,_=N&&"tiles"===L&&v;return(0,l.jsx)(h,{ref:S,"data-column-span":C?1:12/m(t,e),"data-guide-category":u,"data-selected":E,"data-item-type":L,children:(0,l.jsxs)(y,{...(0,d.Cr)(e,b,A,"category",void 0,k),...o===b?{"aria-pressed":E}:{},"aria-label":(E?z:x).replace("{{category}}",f),onKeyDown:e=>{var t;(" "===e.key||"Enter"===e.key)&&(e.preventDefault(),null==(t=e.target)||t.click())},title:f,ref:T,selected:E,"aria-current":E,direction:w,"aria-describedby":_?`${u}-description`:"",role:o===b?"button":"link","data-item-type":L,onClick:()=>{F.dispatch("tracking:guide-category-list-item-clicked",e)},children:[(e=>{const t="circles"===L?{backgroundSize:"50%"}:{};return e?(0,l.jsx)(n.s$,{title:f,elementStyle:t,symbol:e}):"circles"===L?(0,l.jsx)("i",{}):null})((i===u||H)&&p?p:g),(0,l.jsx)(n.oR,{children:f}),_&&(0,l.jsx)($,{id:`${u}-description`,children:v})]})})},h=o.A.li`
  ${e=>{var t;return e["data-selected"]&&`border-color: ${null==(t=e.theme.colors)?void 0:t.primary};`}}
  grid-column: ${e=>`span ${e["data-column-span"]}`};
  transition: all 0.3s ease-in-out;
  position: relative;

  div > a {
    text-decoration: none;
  }

  ${e=>("badges"===e["data-item-type"]||"tiles"===e["data-item-type"])&&a.AH`
      ${(0,n.jo)(e)}
      &::after {
        content: '';
        position: absolute;
        z-index: -1;
        width: 100%;
        height: 100%;
        opacity: 0;
        border-radius: 5px;
        box-shadow: ${e.theme.boxShadow};
        transition: opacity 0.3s ease-in-out;
      }
    `}

  &:hover {
    transform: scale(1.05, 1.05);
  }

  &:hover::after {
    opacity: 1;
  }
`,f=e=>{var t,i,l,r,o,n,s;return a.AH`
  display: block;
  padding: ${null==(t=e.theme.sizes)?void 0:t.large} 20px;
  span,
  i {
    text-align: center;
  }
  i {
    font-size: ${null==(i=e.theme.fonts)?void 0:i.huge};
    margin: ${"horizontal"===e.direction?`0 ${null==(l=e.theme.sizes)?void 0:l.medium} 0 ${null==(r=e.theme.sizes)?void 0:r.normal}`:`0 ${null==(o=e.theme.sizes)?void 0:o.small} 0 0`};
    min-height: 1em;
    min-width: 1em;
  }
  ${"horizontal"===e.direction?a.AH`
        display: flex;
        align-items: center;
        span {
          margin: ${`0 ${null==(n=e.theme.sizes)?void 0:n.normal} 0 0`};
        }
      `:a.AH`
        span,
        i {
          display: block;
          &:not(:last-child) {
            margin: 0 0 ${null==(s=e.theme.sizes)?void 0:s.normal};
          }
        }
      `}
`},g=e=>{var t,i,l,r,o,n;return a.AH`
  display: flex;
  align-items: center;
  height: 100%;
  padding: ${`${1.5*((null==(t=e.theme.sizes)?void 0:t.cardinal)||0)}px ${null==(i=e.theme.sizes)?void 0:i.normal}`};
  outline-offset: -2px;

  span {
    font-weight: 300;
    font-size: ${null==(l=e.theme.fonts)?void 0:l.normal};
    &:nth-child(3) {
      margin: ${`0 0 0 ${null==(r=e.theme.sizes)?void 0:r.small}`};
    }
  }
  i {
    font-size: ${null==(o=e.theme.fonts)?void 0:o.medium};
    margin: 0 ${null==(n=e.theme.sizes)?void 0:n.small} 0 0;
    min-height: 1em;
    min-width: 1em;
  }
`},p=e=>{var t,i,l,r,o,n,s,d,c;return a.AH`
  display: flex;
  align-items: center;
  padding: ${`0 ${null==(t=e.theme.sizes)?void 0:t.normal}`};
  outline-offset: -2px;
  background-color: ${e.selected?null==(i=e.theme.colors)?void 0:i.primary:"#FFF"};
  border-radius: 1em;
  border: 1px solid ${null==(l=e.theme.colors)?void 0:l.text};
  box-shadow: none;
  height: 2em;
  overflow: hidden;
  border: 1px solid
    ${e.selected?null==(r=e.theme.colors)?void 0:r.primary:null==(o=e.theme.colors)?void 0:o.text};

  span {
    font-weight: 300;
    font-size: ${null==(n=e.theme.fonts)?void 0:n.normal};
    overflow: hidden;
    text-overflow: ellipsis;
    &:nth-child(3) {
      margin: ${`0 0 0 ${null==(s=e.theme.sizes)?void 0:s.small}`};
    }
  }
  i {
    font-size: ${null==(d=e.theme.fonts)?void 0:d.medium};
    margin: 0 ${null==(c=e.theme.sizes)?void 0:c.small} 0 0;
    min-height: 1em;
    min-width: 1em;
  }
`},v=e=>{var t,i,l,r,o,n,s,d,c;return a.AH`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  margin-left: ${null==(t=e.theme.sizes)?void 0:t.small};
  margin-right: ${null==(i=e.theme.sizes)?void 0:i.small};

  i {
    background-color: ${e.selected?null==(l=e.theme.colors)?void 0:l.primary:"#FFF"};
    color: ${e.selected?"#FFFFFF":null==(r=e.theme.colors)?void 0:r.text};
    font-size: ${null==(o=e.theme.fonts)?void 0:o.large};
    display: inline;
    border: 1px solid
      ${e.selected?null==(n=e.theme.colors)?void 0:n.primary:null==(s=e.theme.colors)?void 0:s.text};
    border-radius: 50%;
    height: 3em;
    width: 3em;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  span {
    margin-top: ${null==(d=e.theme.sizes)?void 0:d.normal};
    text-align: center;
    width: 5.5em;
    font-weight: normal;
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: ${null==(c=e.theme.fonts)?void 0:c.normal};
  }
`},y=(0,o.A)(n.N_)`
  color: ${e=>{var t;return null==(t=e.theme.colors)?void 0:t.text}};
  ${e=>{var t;return e.selected&&"circles"!==e["data-item-type"]&&a.AH`
      background-color: ${null==(t=e.theme.colors)?void 0:t.primary};
      span,
      i {
        color: #ffffff;
      }
    `}};
  ${e=>(e=>{switch(e){case"tiles":return f;case"badges":return g;case"pills":return p;case"circles":return v;default:return}})(e["data-item-type"])};

  &:focus-visible {
    ${n.ns}
    ${e=>e.selected&&"border-color: #FFFFFF"};
    ${e=>{var t,i;return e.selected&&"circles"!==e["data-item-type"]&&`color: ${null==(i=null==(t=e.theme.accessibility)?void 0:t.colors)?void 0:i.activeText}`}};
  }
`,$=(0,o.A)(n.D7)`
  font-weight: 300;
  line-height: 1.6em;
`,b=e=>a.AH`
  display: grid;
  grid-template-columns: ${`repeat(${e["data-columns"]}, 1fr)`};
  grid-gap: ${e.theme.gap};
  justify-content: center;
  li {
    margin: 0;
  }

  a {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;

    span {
      white-space: pre-wrap;
    }
  }
`,x=e=>{var t,i;return a.AH`
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  li,
  li:last-child {
    overflow: hidden;
    text-align: center;
    ${(null==(t=e.theme.sizes)?void 0:t.cardinal)&&a.AH`
      margin: ${2*(null==(i=e.theme.sizes)?void 0:i.cardinal)}px;
    `};
    margin-bottom: 0;
  }
`},w=e=>{var t,i,l;return a.AH`
  display: flex;
  justify-content: center;
  align-items: flex-start;
  flex-wrap: nowrap;
  padding: ${null==(t=e.theme.sizes)?void 0:t.normal} 0;
  ${e["data-scrollable"]&&a.AH`
    justify-content: flex-start;
  `}

  li, li:last-child {
    flex-grow: 0;
    min-width: auto;
  }
  li:first-child {
    padding-left: ${null==(i=e.theme.sizes)?void 0:i.normal};
  }
  li:last-child {
    padding-right: ${null==(l=e.theme.sizes)?void 0:l.normal};
  }
`},z=a.AH`
  overflow: hidden;
  overflow-x: auto;
  scroll-behavior: smooth;
  &::-webkit-scrollbar {
    display: none;
  }
  -ms-overflow-style: none;
  scrollbar-width: none;
`,A=(0,o.A)(n.$n)`
  position: absolute;
  ${e=>{var t;return e.offsetTop?a.AH`
          top: ${`calc(${e.offsetTop} - 1.4em + ${null==(t=e.theme.sizes)?void 0:t.normal})`};
        `:a.AH`
          top: 0;
          bottom: 0;
          margin-top: auto;
          margin-bottom: auto;
        `}}
  color: white;
  left: ${e=>{var t;return"left"===e.direction?(null==(t=e.theme.sizes)?void 0:t.normal)||"10px":"auto"}};
  right: ${e=>{var t;return"left"===e.direction?"auto":(null==(t=e.theme.sizes)?void 0:t.normal)||"10px"}};
  background-color: rgba(0, 0, 0, 0.6);
  height: 2.8em;
  width: 2.8em;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;

  line {
    stroke: white;
  }

  &:hover {
    transform: scale(1.05, 1.05);
  }
`,k=(0,o.A)(n.kk)`
  ${n._R}
  ${n.MH}

  margin-bottom: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.medium}};
  &:last-child {
    margin-bottom: 0;
  }

  ${e=>{var t;return e["data-scrollable"]&&a.AH`
      display: flex;
      position: relative;
      justify-self: center;
      padding: 0;
      margin: 0 -${null==(t=e.theme.sizes)?void 0:t.normal};
    `}}

  ul {
    margin: 0 auto;
    ${e=>(e=>{switch(e){case"tiles":return b;case"circles":return w;case"badges":case"pills":return x;default:return}})(e["data-item-type"])}
    ${e=>e["data-scrollable"]&&z}
  }
`,j=({className:e,level:t=0,categories:i=[],mode:o,scrollable:a,...d})=>{const c=(0,n.PR)(),{levels:m=1,selectedCategoryTrail:h=[],loading:f=!1}=(0,n.Bi)(),[g,p]=(0,r.useState)(),[v,y]=(0,r.useState)(null),[$,b]=(0,r.useState)(),[x,w]=(0,r.useState)({left:!1,right:!1}),[z,j]=(0,r.useState)(""),[F,H]=(0,r.useState)(!1);(0,r.useEffect)((()=>{if(g&&v&&a){const e=new ResizeObserver(((e,t)=>{var i;const l=v.children[0];l&&j(.5*(null==(i=l.getElementsByTagName("i")[0])?void 0:i.offsetHeight)+"px"||"");const r=Array.from(v.children).find((e=>"true"===e.getAttribute("data-selected")));T((null==r?void 0:r.getAttribute("data-guide-category"))||void 0,!0)}));let t;const i=e=>{clearTimeout(t),t=setTimeout((()=>{F||C(v.scrollLeft)}),200)};return v.addEventListener("scroll",i),e.observe(v),()=>{e.disconnect(),v.removeEventListener("scroll",i)}}}),[g]);const S=(0,r.useCallback)((e=>{if(e){p(e);const t=e.getElementsByTagName("ul")[0];t&&y(t)}}),[]),T=(e,t=!1)=>{v&&a&&(H(!0),setTimeout((()=>H(!1)),300),e&&Array.from(v.children).some(((i,l)=>{const r=i.getAttribute("data-guide-category")===e;if(r){const e=i.offsetLeft,{scrollLeft:r,offsetWidth:o}=v;(e<r||e+i.offsetWidth>r+o||t)&&(v.scrollLeft=e,C(l>0?e:0))}return r}))||(v.scrollLeft=0,C(0)))},C=e=>{if(v&&g){const t=v.scrollWidth-g.offsetWidth,i={left:!0,right:!0};if(t<=0)return w({left:!1,right:!1});e<=0&&(i.left=!1),e>=t&&(i.right=!1),w(i)}};(0,r.useEffect)((()=>{const e=h[t]?h[t].id:void 0;b(e),e&&T(e)}),[h]);const L=e=>!(h[t]?h[t].id:void 0)&&0===e&&t>0,{name:N}=c;return i.length?(E=i,_=o,(0,r.createElement)(k,{...d,className:(0,s.JS)(e,"humany-guide-category-list"),key:"category-list-level-0","data-loading":f,"data-item-type":_.type,"data-columns":_.columns||12,"data-scrollable":a,items:E,ref:S,renderItem:(e,t)=>(0,l.jsx)(u,{item:e,categories:E,autoFocus:L(t),currentRoute:N,guideCategory:$||"",itemMode:_},e.id)},(0,l.jsx)(n.aH,{loading:f}),a&&["left","right"].map((e=>x[e]?(0,l.jsx)(A,{tabIndex:-1,direction:e,offsetTop:z,"aria-hidden":"true",onClick:()=>(e=>{if(v){const t=v.getElementsByTagName("li");if(t.length){const i=2*t[0].clientWidth,l="right"===e?v.scrollLeft+i:v.scrollLeft-i;v.scrollLeft=l,H(!0),setTimeout((()=>H(!1)),300),C(l)}}})(e),children:(0,l.jsx)(n.s$,{size:23,symbol:{type:"Svg",content:`caret-${e}`}})},`category-list-pager-${e}`):null)))):null;var E,_},F=({className:e,...t})=>{const{categories:i=[],levels:o=1,columns:a,badgeSize:d="large",mode:c,showDescriptions:m,loading:u=!1}=(0,n.Bi)(),h=(0,n.NF)();if(!i.length&&!u||1===i.length&&1===o)return(0,n.Xn)(h,{...t,className:(0,s.JS)(e,"humany-guide-category-list")});const f=(i,l)=>{if(!i||"number"==typeof o&&l+1>o)return null;const n=(e=>{if(c){if(Array.isArray(c)){if(!e)return c[0];const t=c.length;return e<t?c[e]:c[t-1]}if("object"==typeof c)return c}return{columns:a,type:"large"===d?"tiles":"badges",description:m}})(l),u=!("circles"!==n.type||!n.scrollable),h=1===o?(0,s.JS)(e,"humany-guide-category-list"):"humany-guide-category-list-level";return(0,r.createElement)(j,{...1===o?t:{},className:h,key:`category-list-level-${l}`,mode:n,scrollable:u,categories:i,level:l})};return 1===o?f(i,0):(0,l.jsx)(H,{...t,className:(0,s.JS)(e,"humany-guide-category-list"),children:i.map(((e,t)=>f(e,t)))})},H=o.A.div`
  ${e=>(0,n.jo)(e)};
  overflow: hidden;
  padding: ${e=>{var t;return null==(t=e.theme.sizes)?void 0:t.normal}};
`}}]);